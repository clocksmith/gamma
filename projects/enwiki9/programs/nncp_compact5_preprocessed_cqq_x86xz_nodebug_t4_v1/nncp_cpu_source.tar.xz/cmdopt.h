 






















#ifndef CMDOPT_H
#define CMDOPT_H

#include "cutils.h"

typedef struct CMDOption CMDOption;

#define CMD_HAS_ARG (1 << 0)

typedef struct {
    const char *opt;
    int flags;
    const char *desc;
    const char *arg_desc;
} CMDOptDesc;

void __attribute__((noreturn, format(printf, 1, 2))) cmd_error(const char *fmt, ...);
CMDOption *cmdopt_init(const char *prog_name);
void cmdopt_add_desc(CMDOption *s, const CMDOptDesc *desc);
int cmdopt_parse(CMDOption *s, int argc, const char **argv);
void cmdopt_free(CMDOption *s);

void cmdopt_show_desc(const CMDOptDesc *desc);
const char *cmdopt_get(CMDOption *s, const char *opt);
BOOL cmdopt_has(CMDOption *s, const char *opt);
int cmdopt_get_int(CMDOption *s, const char *opt, int def_val);
float cmdopt_get_float(CMDOption *s, const char *opt, float def_val);
int cmdopt_get_count(CMDOption *s, const char *opt);

#endif  
