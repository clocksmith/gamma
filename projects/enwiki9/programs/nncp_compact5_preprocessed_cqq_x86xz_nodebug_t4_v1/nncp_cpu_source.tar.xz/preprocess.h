 






















int word_encode(const char *in_filename, const char *out_filename,
                const char *word_filename, int n_words, int min_word_freq,
                const char *debug_dict_filename, BOOL sort_by_freq,
                int verbose);
void word_decode(const char *in_filename, const char *out_filename,
                 const char *word_filename);
