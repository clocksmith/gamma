"""Deterministic packaging of unchanged synthetic receipts and artifacts."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ZIP, INDEX, SUMMARY = [HERE / name for name in ("evidence.zip", "evidence-index.json", "summary.json")]
assert not any(path.exists() for path in (ZIP, INDEX, SUMMARY))
ATTEMPT = HERE / "attempt_01"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), bytes=len(data), sha256=digest(data))


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


before = json.loads((ATTEMPT / "source-bindings-before.json").read_text())
sources = [dict(path=str(Path(row["path"]).relative_to(ROOT)), bytes=row["bytes"], sha256=row["sha256"])
           for row in before]
assert all(identity(ROOT / row["path"]) == row for row in sources)
originals = [HERE / name for name in ("run.py", "retain.py", "preflight.json")]
originals.extend(path for path in ATTEMPT.rglob("*") if path.is_file())
originals.sort(key=lambda path: str(path.relative_to(HERE)))
rows = []
with zipfile.ZipFile(ZIP, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in originals:
        data = path.read_bytes()
        member = str(path.relative_to(HERE))
        entry = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        entry.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        rows.append(dict(member=member, original_path=str(path), project_path=str(path.relative_to(ROOT)),
                         bytes=len(data), sha256=digest(data)))
with zipfile.ZipFile(ZIP) as archive:
    assert archive.namelist() == [row["member"] for row in rows]
    for row in rows:
        data = archive.read(row["member"])
        assert len(data) == row["bytes"] and digest(data) == row["sha256"]
        assert Path(row["original_path"]).read_bytes() == data
write(INDEX, dict(schema="gamma.enwiki9.synthetic-zip-index.v1", archive=identity(ZIP), files=rows,
    files_count=len(rows), original_bytes=sum(row["bytes"] for row in rows), original_root=str(HERE),
    archive_member_root=".", original_receipts_unmodified=True, archive_verified_against_every_original=True,
    format="ZIP Deflate9, sorted paths, fixed1980 timestamps, regular0644 entries; no directory entries"))


def reference(path):
    row = next(row for row in rows if row["original_path"] == str(path))
    return dict(archive_member=row["member"], original_path=row["original_path"], bytes=row["bytes"], sha256=row["sha256"])


execution = json.loads((ATTEMPT / "execution.json").read_text())
assert execution["returncode"] == 0 and execution["sources_unchanged"] and execution["scratch_bound_pass"]
fixture_root = next((ATTEMPT / "tmp").glob("literal_first_gate_*"))
fixtures, phases = {}, []
for name in ("favorable", "fallback"):
    gold = fixture_root / "results" / ("gold_" + name)
    stage = json.loads((gold / "stage-decision.json").read_text())
    assert stage["correctness_pass"] and stage["native_phases"] == 9
    assert stage["costs"]["strict_d_improvement"] == (name == "favorable")
    arms = []
    for row in stage["arms"]:
        arm = row["arm"]["id"]
        arms.append(dict(arm=arm, archive_bytes=row["archive_bytes"], accounting=row["accounting"],
            exact_inverse=row["exact_inverse"], deterministic_repeat=row["deterministic_repeat"],
            raw_encoder_repeat_proved=row["raw_encoder_repeat_proved"], repeat_scope=row["repeat_scope"],
            selected_rules=row["selected_rules"], calls=row["calls"], repeated_argument_references=row["repeated_argument_references"],
            result=reference(gold / (arm + ".result.json")), archive=reference(gold / (arm + ".d2g")),
            inverse=reference(gold / (arm + ".raw")), repeat=reference(gold / (arm + ".repeat.d2g")), frames=row["frames"]))
    fixtures[name] = dict(raw=reference(fixture_root / "inputs" / name / "raw.bin"),
        retained_plain_fixture=reference(fixture_root / "inputs" / name / "P.d2g"),
        archive_bytes=stage["costs"]["archive_bytes"], strict_d_improvement=stage["costs"]["strict_d_improvement"],
        fallback_equality_authorizes_confirmation=False, synthetic_comparison_only=True,
        stage=reference(gold / "stage-decision.json"), index=reference(gold / "artifacts.json"), arms=arms)
    for phase in stage["commands"]:
        phase_name = phase["phase"]
        wrapper = json.loads((gold / (phase_name + ".stdout")).read_text())
        phases.append(dict(fixture=name, phase=phase_name,
            execution=reference(gold / (phase_name + ".execution.json")), stdout=reference(gold / (phase_name + ".stdout")),
            stderr=reference(gold / (phase_name + ".stderr")), user_cpu_seconds=phase["user_cpu_seconds"],
            system_cpu_seconds=phase["system_cpu_seconds"], elapsed_seconds=phase["elapsed_seconds"],
            reported_peak_rss_kib=wrapper["peak_process_rss_kib"]))
summary = dict(schema="gamma.enwiki9.literal-first-gate-unit.v1", source=sources, tests_passed=16,
    actual_cli_phases=len(phases), failed_test_attempts=0, fault_injection_outputs_preserved=True,
    synthetic_only=True, corpus_bytes_opened=0, objective_credit_bytes=0, complete_package_bytes=None,
    full_corpus_score_bytes=None, resource_qualified=False, timing_authority="shared-host diagnostic",
    archive=identity(ZIP), index=identity(INDEX), indexed_original_files=len(rows),
    indexed_original_bytes=sum(row["bytes"] for row in rows), preserved_original_root=str(HERE), originals_remain_locally=True,
    unpack_verify="Read evidence-index.json; extract ZIP into a new directory. For each files row, compare extracted member bytes and SHA256. original_path is the unchanged original receipt location, not a required extraction destination. Receipt contents and absolute paths were preserved.",
    zip_publication_scope="Publish evidence.zip, evidence-index.json and summary.json; expanded original evidence remains local.",
    recipe=reference(fixture_root / "recipe.json"), execution=reference(ATTEMPT / "execution.json"),
    regression=reference(ATTEMPT / "regression.log"), wrapper_execution=execution, fixtures=fixtures, phases=phases,
    comparison_codec_source_inventory=stage["costs"]["package_source"], known_comparison_source_bytes=stage["costs"]["known_source_bytes"],
    phase_cpu_seconds=sum(row["user_cpu_seconds"] + row["system_cpu_seconds"] for row in phases),
    phase_wall_seconds=sum(row["elapsed_seconds"] for row in phases), phase_peak_rss_kib=max(row["reported_peak_rss_kib"] for row in phases),
    report_projection=dict(encoder_only=["mode", "search_spec", "repeat_scope", "raw_encoder_repeat_proved"],
                           frame_encoder_only=["search"], all_other_fields_require_independent_decoder_identity=True,
                           full_repeat_encoder_report_identity=True),
    verification_scope=["P/K exact unchanged plain archive identity and D exact fallback identity",
        "all repeats independently encode decoded raw, including K/D discovery",
        "K/D decoder-common raw/program/output/boundary/archive hashes and complete reports",
        "K/D same proposal pool and first-round complete-cost measurements",
        "each accepted replacement strictly reduces the previous whole-frame cost",
        "strict D archive improvement required; fallback equality grants no confirmation eligibility",
        "joint Deflate payload and framing sum to every archive; pre-Deflate representation costs remain separate",
        "frozen source/runtime/search/baseline checks; no positive cost table after failed final authentication"],
    limitations=["Synthetic main authority is mocked; authentication unit cases cover closure/runtime/baseline binding.",
        "Fault tests replay retained synthetic CLI outputs; actual18 child phases are listed individually.",
        "Known comparison source bytes are not complete distribution/license/accepted-option package bytes.",
        "Favorable synthetic improvement is not actual-population improvement or authorization to launch confirmation."])
write(SUMMARY, summary)
print(json.dumps(dict(archive=identity(ZIP), index=identity(INDEX), summary=identity(SUMMARY),
                      original_files=len(rows), original_bytes=sum(row["bytes"] for row in rows),
                      fixture_archive_bytes={name: value["archive_bytes"] for name, value in fixtures.items()}), sort_keys=True))
