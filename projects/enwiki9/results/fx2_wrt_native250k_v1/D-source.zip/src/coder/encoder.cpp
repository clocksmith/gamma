#include "encoder.h"
#include "../gamma-wrt.h"
#ifdef GAMMA_EXPERT_RELEASE
#include "../gamma-expert-release.h"
#endif

Encoder::Encoder(std::ofstream* os, Predictor* p) : os_(os), x1_(0),
    x2_(0xffffffff), p_(p) {}

void Encoder::WriteByte(unsigned int byte) {
  out_.push_back(byte);
}

unsigned int Encoder::Discretize(float p) {
  return 1 + 65534 * p;
}

void Encoder::Encode(int bit) {
  unsigned int p = Discretize(p_->Predict());
#ifdef GAMMA_EXPERT_RELEASE
  p = gamma_expert_release::predict(p);
#endif
  const int forced = gamma_wrt::forced();
  if (forced >= 0) {
    if (bit != forced) gamma_wrt::fail();
    gamma_wrt::observe(bit,p,forced);
    p_->Perceive(bit);
    return;
  }
  const unsigned int xmid = x1_ + ((x2_ - x1_) >> 16) * p +
      (((x2_ - x1_) & 0xffff) * p >> 16);
  if (bit) {
    x2_ = xmid;
  } else {
    x1_ = xmid + 1;
  }

#ifdef GAMMA_EXPERT_RELEASE
  gamma_expert_release::observe(bit);
#endif
  gamma_wrt::observe(bit,p,forced);
  p_->Perceive(bit);

  while (((x1_^x2_) & 0xff000000) == 0) {
    WriteByte(x2_ >> 24);
    x1_ <<= 8;
    x2_ = (x2_ << 8) + 255;
  }
}

void Encoder::Flush() {
  while (((x1_^x2_) & 0xff000000) == 0) {
    WriteByte(x2_ >> 24);
    x1_ <<= 8;
    x2_ = (x2_ << 8) + 255;
  }
  WriteByte(x2_ >> 24);

  auto* data = reinterpret_cast<const char*>(out_.data());
  os_->write(data, out_.size());
}

