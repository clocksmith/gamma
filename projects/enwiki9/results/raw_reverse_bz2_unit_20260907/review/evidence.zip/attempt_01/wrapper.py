"""Retain independent bounded synthetic tests and original compact evidence."""
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ATTEMPT = HERE / sys.argv[1]
ATTEMPT.mkdir()
TMP = ATTEMPT / 'tmp'
TMP.mkdir()
PATHS = ['tools/raw_reverse_bz2_v1.py', 'tests/test_raw_reverse_bz2_v1.py',
         'programs/baseline_bz2/program.py', 'operations/provenance/raw_reverse_bz2_v1_plan.json']


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


before = [identity(ROOT / name) for name in PATHS]
for name in PATHS:
    target = ATTEMPT / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
shutil.copyfile(Path(__file__), ATTEMPT / 'wrapper.py')
write(ATTEMPT / 'sources-before.json', before)
caps = dict(cpus=[3], memory_address_bytes=536870912, cpu_seconds=60,
            wall_seconds=90, file_bytes=33554432, scratch_bytes=33554432)
argv = [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests',
        '-p', 'test_raw_reverse_bz2_v1.py', '-v']
env = dict(os.environ, TMPDIR=str(TMP), PYTHONDONTWRITEBYTECODE='1')
write(ATTEMPT / 'invocation.json', dict(argv=argv, cwd=str(ROOT), TMPDIR=str(TMP),
    caps=caps, sources=before, wrapper=identity(Path(__file__)), corpus_bytes_opened=0))


def limits():
    os.sched_setaffinity(0, {3})
    resource.setrlimit(resource.RLIMIT_AS, (caps['memory_address_bytes'],) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (caps['cpu_seconds'],) * 2)
    resource.setrlimit(resource.RLIMIT_FSIZE, (caps['file_bytes'],) * 2)


started, stopped, reason = time.monotonic(), False, None
with (ATTEMPT / 'regression.log').open('xb') as log:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                             preexec_fn=limits, start_new_session=True)
    while True:
        pid, status, usage = os.wait4(child.pid, os.WNOHANG)
        if pid:
            break
        scratch = sum(path.stat().st_size for path in TMP.rglob('*') if path.is_file())
        if time.monotonic() - started >= caps['wall_seconds'] or scratch > caps['scratch_bytes']:
            stopped = True
            reason = 'wall' if time.monotonic() - started >= caps['wall_seconds'] else 'scratch'
            os.killpg(child.pid, signal.SIGKILL)
            pid, status, usage = os.wait4(child.pid, 0)
            break
        time.sleep(.05)
    child.returncode = os.waitstatus_to_exitcode(status)
elapsed = time.monotonic() - started
after = [identity(ROOT / name) for name in PATHS]
write(ATTEMPT / 'sources-after.json', after)
scratch = sum(path.stat().st_size for path in TMP.rglob('*') if path.is_file())
execution = dict(argv=argv, returncode=child.returncode, stopped=stopped, stop_reason=reason,
    elapsed_seconds=elapsed, user_cpu_seconds=usage.ru_utime, system_cpu_seconds=usage.ru_stime,
    peak_process_rss_kib=usage.ru_maxrss, caps=caps, scratch_bytes=scratch,
    scratch_bound_pass=scratch <= caps['scratch_bytes'], sources_unchanged=before == after,
    scope='independent synthetic review with separate actual codec CLI phases',
    timing_authority='shared-host diagnostic', corpus_bytes_opened=0,
    complete_package_bytes=None, full_corpus_score_bytes=None)
write(ATTEMPT / 'execution.json', execution)
rows = [identity(path) for path in sorted(ATTEMPT.rglob('*')) if path.is_file()]
write(ATTEMPT / 'inventory.json', dict(files=rows, bytes=sum(row['bytes'] for row in rows)))
print(json.dumps(execution, sort_keys=True))
if child.returncode or before != after or scratch > caps['scratch_bytes']:
    raise SystemExit(1)

archive_path, index_path, summary_path = [HERE / name for name in ('evidence.zip', 'evidence-index.json', 'summary.json')]
assert not any(path.exists() for path in (archive_path, index_path, summary_path))
originals = [HERE / 'run.py', HERE / 'preflight.json']
for attempt in sorted(HERE.glob('attempt_*')):
    originals.extend(path for path in attempt.rglob('*') if path.is_file())
originals.sort(key=lambda path: str(path.relative_to(HERE)))
index = []
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in originals:
        data = path.read_bytes()
        member = str(path.relative_to(HERE))
        info = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
        info.create_system, info.external_attr = 3, 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        index.append(dict(member=member, original_path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.namelist() == [row['member'] for row in index]
    for row in index:
        data = archive.read(row['member'])
        assert data == Path(row['original_path']).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
write(index_path, dict(archive=identity(archive_path), files=index, original_root=str(HERE),
    files_count=len(index), indexed_bytes=sum(row['bytes'] for row in index), originals_unmodified=True,
    all_member_hashes_verified=True, format='sorted ZIP Deflate9; fixed1980 timestamps; regular0644 entries'))
fixture = next(TMP.glob('raw_reverse_independent_*'))
summary = dict(schema='gamma.enwiki9.raw-reverse-bz2-independent-unit.v1', tests_passed=9,
    reviewed_sources=before, source_unchanged=True, execution=execution, archive=identity(archive_path),
    index=identity(index_path), original_files=len(index), original_bytes=sum(row['bytes'] for row in index),
    kernel=json.loads((fixture / 'kernel.json').read_text()),
    archive_cap=json.loads((fixture / 'archive-cap.json').read_text()),
    evidence_member_root=str(fixture.relative_to(HERE)), exact_inverse=True, deterministic_raw_repeats=True,
    parent_bookkeeping_byte_identity=True, decoder_common_report_identity=True,
    complete_frame_cost_checks=True, independent_baseline_payload_comparison=True,
    remaining_concrete_blockers=[], corpus_bytes_opened=0, complete_package_bytes=None,
    full_corpus_score_bytes=None, objective_credit_bytes=0,
    ownership='Independent test source and retained synthetic evidence only; codec source not edited.',
    unpack_verify='Extract ZIP into a new directory and verify every member against evidence-index bytes/sha256. Original absolute paths are preserved; receipts were not rewritten.',
    publication_files=[str(path.relative_to(ROOT)) for path in (archive_path, index_path, summary_path)])
write(summary_path, summary)
print(json.dumps(dict(summary=identity(summary_path), archive=identity(archive_path), index=identity(index_path)), sort_keys=True))
