"""Source-bound, bounded independent synthetic review with compact retention."""
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ATTEMPT = HERE / sys.argv[1]
ATTEMPT.mkdir()
TMP = ATTEMPT / "tmp"
TMP.mkdir()
PATHS = ["tools/causal_bucket_v2.py", "tools/dualstream_grammar_v1.py",
         "tests/test_causal_bucket_review_v1.py", "operations/provenance/causal_bucket_v1_plan.json"]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


before = [identity(ROOT / name) for name in PATHS]
for name in PATHS:
    path = ATTEMPT / "sources" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, path)
shutil.copyfile(Path(__file__), ATTEMPT / "wrapper.py")
write(ATTEMPT / "sources-before.json", before)
caps = dict(cpus=[3], memory_address_bytes=536870912, cpu_seconds=60, wall_seconds=90,
            file_bytes=33554432, scratch_bytes=33554432)
argv = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_causal_bucket_review_v1.py", "-v"]
env = dict(os.environ, TMPDIR=str(TMP), PYTHONDONTWRITEBYTECODE="1")
write(ATTEMPT / "invocation.json", dict(argv=argv, cwd=str(ROOT), TMPDIR=str(TMP), caps=caps,
    source_before=before, wrapper=identity(Path(__file__)), corpus_bytes_opened=0))


def limits():
    os.sched_setaffinity(0, {3})
    resource.setrlimit(resource.RLIMIT_AS, (caps["memory_address_bytes"],) * 2)
    resource.setrlimit(resource.RLIMIT_CPU, (caps["cpu_seconds"],) * 2)
    resource.setrlimit(resource.RLIMIT_FSIZE, (caps["file_bytes"],) * 2)


start, timeout = time.monotonic(), False
with (ATTEMPT / "regression.log").open("xb") as log:
    child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                             preexec_fn=limits, start_new_session=True)
    while True:
        pid, status, usage = os.wait4(child.pid, os.WNOHANG)
        if pid:
            break
        if time.monotonic() - start >= caps["wall_seconds"]:
            timeout = True
            os.killpg(child.pid, signal.SIGKILL)
            pid, status, usage = os.wait4(child.pid, 0)
            break
        time.sleep(0.05)
    child.returncode = os.waitstatus_to_exitcode(status)
elapsed = time.monotonic() - start
after = [identity(ROOT / name) for name in PATHS]
scratch = sum(path.stat().st_size for path in TMP.rglob("*") if path.is_file())
write(ATTEMPT / "sources-after.json", after)
execution = dict(argv=argv, returncode=child.returncode, timeout=timeout, elapsed_seconds=elapsed,
    user_cpu_seconds=usage.ru_utime, system_cpu_seconds=usage.ru_stime, peak_process_rss_kib=usage.ru_maxrss,
    caps=caps, scratch_bytes=scratch, scratch_bound_pass=scratch <= caps["scratch_bytes"],
    sources_unchanged=before == after, corpus_bytes_opened=0, scope="independent synthetic library review",
    timing_authority="shared-host diagnostic", complete_package_bytes=None, full_corpus_score_bytes=None)
write(ATTEMPT / "execution.json", execution)
attempt_files = [identity(path) for path in sorted(ATTEMPT.rglob("*")) if path.is_file()]
write(ATTEMPT / "inventory.json", dict(files=attempt_files, bytes=sum(row["bytes"] for row in attempt_files)))
if child.returncode or before != after or scratch > caps["scratch_bytes"]:
    print(json.dumps(execution, sort_keys=True))
    raise SystemExit(1)

archive_path, index_path, summary_path = [HERE / name for name in ("evidence.zip", "evidence-index.json", "summary.json")]
assert not any(path.exists() for path in (archive_path, index_path, summary_path))
originals = [HERE / "run.py", HERE / "preflight.json"]
for attempt in sorted(HERE.glob("attempt_*")):
    originals.extend(path for path in attempt.rglob("*") if path.is_file())
originals.sort(key=lambda path: str(path.relative_to(HERE)))
index = []
with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in originals:
        data = path.read_bytes()
        member = str(path.relative_to(HERE))
        info = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
        info.create_system, info.external_attr = 3, 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        index.append(dict(member=member, original_path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.namelist() == [row["member"] for row in index]
    for row in index:
        data = archive.read(row["member"])
        assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
        assert data == Path(row["original_path"]).read_bytes()
write(index_path, dict(archive=identity(archive_path), files=index, original_root=str(HERE),
    files_count=len(index), indexed_bytes=sum(row["bytes"] for row in index), originals_unmodified=True,
    all_member_hashes_verified=True, format="sorted ZIP Deflate9; fixed1980 timestamps; regular0644 entries"))
fixture = next(TMP.glob("causal_bucket_independent_*"))
summary = dict(schema="gamma.enwiki9.causal-bucket-independent-unit.v1", tests_passed=7,
    reviewed_sources=before, source_unchanged=True, execution=execution, archive=identity(archive_path), index=identity(index_path),
    original_files=len(index), original_bytes=sum(row["bytes"] for row in index),
    exhaustive=json.loads((fixture / "exhaustive.json").read_text()),
    endpoint_discriminator=json.loads((fixture / "endpoint-collision.json").read_text()),
    archive_cap=json.loads((fixture / "archive-cap.json").read_text()),
    synthetic_archives=json.loads((fixture / "roundtrips.json").read_text()),
    evidence_member_root=str(fixture.relative_to(HERE)), exact_inverse=True, deterministic_raw_repeats=True,
    decoder_common_report_identity=True, complete_frame_cost_checks=True, remaining_concrete_blockers=[],
    ownership="Independent review only; codec and sealed legacy source were not edited by reviewer.",
    scope="Synthetic only; exhaustive inverse and selected/fallback/mixed complete archive checks, no CLI/corpus/model run.",
    corpus_bytes_opened=0, complete_package_bytes=None, full_corpus_score_bytes=None, objective_credit_bytes=0,
    unpack_verify="Extract ZIP into a new directory and verify every member against evidence-index bytes/sha256. original_path preserves the unchanged original location; no receipt paths were rewritten.",
    publication_files=[str(path.relative_to(ROOT)) for path in (archive_path, index_path, summary_path)])
write(summary_path, summary)
print(json.dumps(dict(summary=identity(summary_path), archive=identity(archive_path), index=identity(index_path),
                      execution=execution, original_files=len(index)), sort_keys=True))
