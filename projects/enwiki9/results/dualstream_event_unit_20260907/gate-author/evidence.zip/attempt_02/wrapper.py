"""Retain exact author sources, run one bounded synthetic suite, retain outcome."""
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
ATTEMPT = HERE / sys.argv[1]
ATTEMPT.mkdir()
SCRATCH = ATTEMPT / "tmp"
SCRATCH.mkdir()
PATHS = ["tools/dualstream_event_gate_v1.py", "tests/test_dualstream_event_gate_v1.py",
         "tools/dualstream_event_codec_v1.py", "tools/dualstream_event_coder_v1.py",
         "tools/dualstream_grammar_gate_v1.py", "tools/dualstream_grammar_v1.py",
         "tools/dualstream_grammar_argtokens_v2.py", "tools/dualstream_grammar_reserialize_v1.py",
         "tools/dualstream_grammar_decode_dispatch_v1.py", "tests/test_dualstream_event_codec_v1.py",
         "tests/test_dualstream_event_coder_v1.py", "operations/provenance/dualstream_event_v1_plan.json"]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


before = []
for name in PATHS:
    path = ROOT / name
    before.append(identity(path))
    copied = ATTEMPT / "sources" / name
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, copied)
write(ATTEMPT / "source-bindings-before.json", before)
argv = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_dualstream_event_gate_v1.py", "-v"]
environment = dict(os.environ, TMPDIR=str(SCRATCH), PYTHONDONTWRITEBYTECODE="1")
caps = dict(cpu=[2], address_bytes=536870912, cpu_seconds=60, wall_seconds=90, file_bytes=33554432,
            cpu_hard_seconds=120, scratch_bytes=33554432, diagnostic_timing=True)
shutil.copyfile(Path(__file__), ATTEMPT / "wrapper.py")
write(ATTEMPT / "command-before.json", dict(argv=argv, cwd=str(ROOT), caps=caps, TMPDIR=str(SCRATCH),
                                           corpus_bytes_opened=0, wrapper=identity(Path(__file__))))


def limits():
    os.sched_setaffinity(0, {2})
    resource.setrlimit(resource.RLIMIT_AS, (caps["address_bytes"],) * 2)
    signal.signal(signal.SIGXCPU, signal.SIG_DFL)
    resource.setrlimit(resource.RLIMIT_CPU, (caps["cpu_seconds"], caps["cpu_hard_seconds"]))
    resource.setrlimit(resource.RLIMIT_FSIZE, (caps["file_bytes"],) * 2)


start = time.monotonic()
timed_out = False
with (ATTEMPT / "regression.log").open("xb") as log:
    child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT,
                             preexec_fn=limits, start_new_session=True)
    while True:
        pid, status, usage = os.wait4(child.pid, os.WNOHANG)
        if pid:
            break
        if time.monotonic() - start >= caps["wall_seconds"]:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            pid, status, usage = os.wait4(child.pid, 0)
            break
        time.sleep(0.05)
    child.returncode = os.waitstatus_to_exitcode(status)
elapsed = time.monotonic() - start
after = [identity(ROOT / name) for name in PATHS]
write(ATTEMPT / "source-bindings-after.json", after)
scratch_bytes = sum(path.stat().st_size for path in SCRATCH.rglob("*") if path.is_file())
receipt = dict(argv=argv, cwd=str(ROOT), returncode=child.returncode, timeout=timed_out,
               elapsed_seconds=elapsed, user_cpu_seconds=usage.ru_utime, system_cpu_seconds=usage.ru_stime,
               peak_process_rss_kib=usage.ru_maxrss, caps=caps, scratch_bytes=scratch_bytes,
               scratch_bound_pass=scratch_bytes <= caps["scratch_bytes"], sources_unchanged=before == after,
               scope="synthetic only; actual phases recorded in gold stage-decision; fault tests reuse retained outputs", corpus_bytes_opened=0,
               complete_package_bytes=None, full_corpus_score_bytes=None)
write(ATTEMPT / "execution.json", receipt)
files = [identity(path) for path in sorted(ATTEMPT.rglob("*")) if path.is_file()]
write(ATTEMPT / "inventory.json", dict(files=files, indexed_bytes=sum(row["bytes"] for row in files)))
print(json.dumps(receipt, sort_keys=True))
sys.exit(0 if child.returncode == 0 and before == after and receipt["scratch_bound_pass"] else 1)
