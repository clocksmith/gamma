"""Package original synthetic evidence without changing receipt contents."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ZIP = HERE / "evidence.zip"
INDEX = HERE / "evidence-index.json"
SUMMARY = HERE / "summary.json"
assert not any(path.exists() for path in (ZIP, INDEX, SUMMARY))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)), bytes=len(data), sha256=sha(data))


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


originals = [HERE / name for name in ("run.py", "run_attempt01.py", "retain.py", "preflight.json")]
for name in ("attempt_01", "attempt_02"):
    originals.extend(path for path in (HERE / name).rglob("*") if path.is_file())
originals.sort(key=lambda path: str(path.relative_to(HERE)))
rows = []
with zipfile.ZipFile(ZIP, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in originals:
        data = path.read_bytes()
        member = str(path.relative_to(HERE))
        entry = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        entry.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        rows.append(dict(member=member, original_path=str(path), project_path=str(path.relative_to(ROOT)),
                         bytes=len(data), sha256=sha(data)))
with zipfile.ZipFile(ZIP) as archive:
    assert archive.namelist() == [row["member"] for row in rows]
    for row in rows:
        data = archive.read(row["member"])
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
        assert Path(row["original_path"]).read_bytes() == data
write(INDEX, dict(schema="gamma.enwiki9.synthetic-zip-index.v1", archive=identity(ZIP), files=rows,
                  files_count=len(rows), original_bytes=sum(row["bytes"] for row in rows),
                  original_root=str(HERE), archive_member_root=".", original_receipts_unmodified=True,
                  archive_verified_against_every_original=True,
                  format="ZIP Deflate9, sorted paths, fixed1980 timestamps, regular0644 entries; no directory entries"))


def reference(path):
    row = next(row for row in rows if row["original_path"] == str(path))
    return dict(archive_member=row["member"], original_path=row["original_path"], bytes=row["bytes"], sha256=row["sha256"])


attempt = HERE / "attempt_02"
execution = json.loads((attempt / "execution.json").read_text())
gold = next((attempt / "tmp").glob("*/results/gold"))
stage = json.loads((gold / "stage-decision.json").read_text())
before = json.loads((attempt / "source-bindings-before.json").read_text())
assert stage["native_phases"] == 15 and stage["correctness_pass"] and execution["returncode"] == 0
sources = [dict(path=str(Path(row["path"]).relative_to(ROOT)), bytes=row["bytes"], sha256=row["sha256"])
           for row in before]
assert all(identity(ROOT / row["path"]) == row for row in sources)
phases = []
for phase in stage["commands"]:
    name = phase["phase"]
    wrapper = json.loads((gold / (name + ".stdout")).read_text())
    phases.append(dict(phase=name, execution=reference(gold / (name + ".execution.json")),
        stdout=reference(gold / (name + ".stdout")), stderr=reference(gold / (name + ".stderr")),
        user_cpu_seconds=phase["user_cpu_seconds"], system_cpu_seconds=phase["system_cpu_seconds"],
        elapsed_seconds=phase["elapsed_seconds"], reported_peak_rss_kib=wrapper["peak_process_rss_kib"]))
arms = []
for row in stage["arms"]:
    name = row["arm"]["id"]
    frames = row["frames"]
    arms.append(dict(arm=name, archive_bytes=row["archive_bytes"], accounting=row["accounting"],
        exact_inverse=row["exact_inverse"], deterministic_repeat=row["deterministic_repeat"],
        raw_encoder_repeat_proved=row["raw_encoder_repeat_proved"], repeat_scope=row["repeat_scope"],
        diagonal_archive_identity=row["diagonal_archive_identity"], repeated_argument_references=row["repeated_argument_references"],
        result=reference(gold / (name + ".result.json")), archive=reference(gold / (name + ".d2g")),
        inverse=reference(gold / (name + ".raw")), repeat=reference(gold / (name + ".repeat.d2g")),
        frames=frames))
failed = json.loads((HERE / "attempt_01/execution.json").read_text())
summary = dict(schema="gamma.enwiki9.event-gate-unit.v1", source=sources, tests_passed=16, actual_cli_phases=15,
    synthetic_only=True, corpus_bytes_opened=0, objective_credit_bytes=0, complete_package_bytes=None,
    full_corpus_score_bytes=None, resource_qualified=False, timing_authority="shared-host diagnostic",
    archive=identity(ZIP), index=identity(INDEX), indexed_original_files=len(rows),
    indexed_original_bytes=sum(row["bytes"] for row in rows),
    preserved_original_root=str(HERE), originals_remain_locally=True,
    unpack_verify="Read evidence-index.json; extract ZIP into a new directory. For each files row, hash the extracted member and compare bytes/sha256. original_path is the unchanged original receipt location, not a required extraction destination. No receipt contents or absolute paths were rewritten.",
    zip_publication_scope="Publish evidence.zip, evidence-index.json and summary.json; original expanded trees remain local.",
    recipe=reference(next((attempt / "tmp").glob("*/synthetic-recipe.json"))),
    gold_stage=reference(gold / "stage-decision.json"), gold_index=reference(gold / "artifacts.json"),
    execution=reference(attempt / "execution.json"), regression=reference(attempt / "regression.log"),
    wrapper_execution=execution, phases=phases, arms=arms, archive_bytes=stage["costs"]["archive_bytes"],
    required_source_inventory=stage["costs"]["package_source"], known_source_bytes=stage["costs"]["known_source_bytes"],
    phase_cpu_seconds=sum(row["user_cpu_seconds"] + row["system_cpu_seconds"] for row in phases),
    phase_wall_seconds=sum(row["elapsed_seconds"] for row in phases),
    phase_peak_rss_kib=max(row["reported_peak_rss_kib"] for row in phases),
    failure_preserved=dict(execution=reference(HERE / "attempt_01/execution.json"),
        regression=reference(HERE / "attempt_01/regression.log"), original_wrapper=reference(HERE / "run_attempt01.py"),
        returncode=failed["returncode"], actual_cli_phases=0, tests_executed=0,
        reason="Inherited RLIMIT_CPU hard60 prevented run_phase from setting its declared120 child cap; preexec_fn failed before any codec phase.",
        repair="Wrapper uses soft60/hard120 with default SIGXCPU; parent stops at soft60 while child can set the declared120 bound. Measured gate/test sources remained unchanged.",
        receipt_scope_note="attempt_01 execution.scope names the intended15-phase suite; actual0 phases are recorded by its failed gold stage and this summary."),
    verification_scope=["P/B exact retained diagonal archive identity", "R decoded-raw encoding repeat",
        "G/X fixed-program repeat and common encode/decode/repeat synchronization reports",
        "B/G/X same graph and repeated binding count", "G/X same interpreter boundary state and categorical event counts",
        "every complete archive cost and frame/payload/header attribution closes", "no positive costs table on failed final authentication",
        "missing source/frontends/runtime/model/reference and report-corruption rejection fixtures"],
    limitations=["Synthetic main integration mocks external canonical authority; pure auth tests cover closure and selected/runtime binding.",
        "Failed-output fixtures reuse retained synthetic phase outputs; only gold15 phases execute actual codecs.",
        "Aggregate fixture plan1200 is not a launched canonical corpus job; outer test controller enforces90wall and60CPU soft stop.",
        "Known source bytes are not a complete distribution/license/accepted-option package or full-corpus score."])
write(SUMMARY, summary)
print(json.dumps(dict(archive=identity(ZIP), index=identity(INDEX), summary=identity(SUMMARY),
                      original_files=len(rows), original_bytes=sum(row["bytes"] for row in rows)), sort_keys=True))
