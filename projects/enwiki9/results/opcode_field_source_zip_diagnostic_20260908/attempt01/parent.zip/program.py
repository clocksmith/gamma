import lzma;exec(lzma.decompress(open(__file__[:-10]+'p','rb').read(),2))
