import {
  axialDistance,
  buildTrainingDeck,
  createRng,
  locallyEligibleFacilityIds,
  publicMandateAwards,
  simulateTrainingRun,
  TRAINING_DOMAINS
} from "../../web/src/engine.js";
import {
  applyAgiDeclarationScenario,
  finalizeAgiDeclarationScenario,
  markScenarioClaim,
  markScenarioDeclaration,
  validateAgiDeclarationScenario
} from "../scenarios/agi-declaration-window.js";
import { CoreEconomyMatch } from "./core-economy-match.js";
import { effectiveRulesVariant } from "./rules-variant.js";
import {
  renderSimulationCopy,
  simulationCopy
} from "../content/simulation-copy.js";
import { throwIfAborted } from "../cancellation.js";

export const SELECTED_RULES_COVERAGE = simulationCopy.coverage.selectedRules;
const ACTION_RESOLUTIONS_PER_PLAYER = 12;
const decisionLabel = (key, values = {}) =>
  renderSimulationCopy(simulationCopy.decisions[key], values);

const CUSTOMER_REQUIREMENTS = [2, 4, 6, 8, 10];
const POLITICAL_CATEGORIES = new Set(["media", "government", "capital"]);
const RESOURCE_BY_CATEGORY = {
  cloud: "compute",
  chip: "compute",
  capital: "runway",
  consumer: "runway",
  research: "compute"
};

function clone(value) {
  return structuredClone(value);
}

function shuffled(values, seed) {
  const result = [...values];
  const rng = createRng(seed);
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(rng() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

function increment(target, key, amount = 1) {
  target[key] = (target[key] || 0) + amount;
}

function edgeKey(left, right) {
  return [left, right].sort().join("::");
}

export function immediateTradePacketCeiling(playerCount, {
  counteroffers = false,
  thirdPartyClaims = false
} = {}) {
  if (!Number.isInteger(playerCount) || playerCount < 2) {
    throw new RangeError("Immediate-trade packet ceiling requires at least two players.");
  }
  if (counteroffers || thirdPartyClaims) {
    throw new RangeError("The simplified trade contract forbids counteroffers and claims.");
  }
  const packetsPerResolution = 2;
  return ACTION_RESOLUTIONS_PER_PLAYER * playerCount * packetsPerResolution;
}

export class SelectedRulesMatch extends CoreEconomyMatch {
  constructor({
    config,
    factions,
    profiles,
    backends = [],
    models = [],
    reasoningEfforts = [],
    headlines,
    projects,
    tactics,
    mandates,
    objectives,
    seed,
    playerCount = 4,
    recordReplay = false,
    projection = "rich",
    rulesVariant = {},
    mandateMode = "variable",
    simulateNegotiation = false,
    scenario = null,
    decisionContext = null,
    onProgress = null,
    signal
  }) {
    super({
      config,
      factions,
      profiles,
      backends,
      models,
      reasoningEfforts,
      seed,
      playerCount,
      recordReplay,
      projection,
      decisionContext
    });
    this.scope = SELECTED_RULES_COVERAGE;
    this.factions = factions;
    this.headlineDocument = headlines;
    this.projectDocument = projects;
    this.tacticDocument = tactics;
    this.mandateDocument = mandates;
    this.objectiveDocument = objectives;
    this.rulesVariant = effectiveRulesVariant(config, rulesVariant);
    const coalition = this.players.find(
      (player) => player.factionId === "coalition_lab"
    );
    if (coalition && Number.isFinite(this.rulesVariant.coalitionStartingRunway)) {
      coalition.runway = this.rulesVariant.coalitionStartingRunway;
    }
    const imperial = this.players.find(
      (player) => player.factionId === "imperial_research_lab"
    );
    if (imperial && Number.isFinite(this.rulesVariant.imperialStartingCompute)) {
      imperial.compute = this.rulesVariant.imperialStartingCompute;
    }
    const vertical = this.players.find(
      (player) => player.factionId === "vertical_empire"
    );
    if (vertical && Number.isFinite(this.rulesVariant.verticalStartingCompute)) {
      vertical.compute = this.rulesVariant.verticalStartingCompute;
    }
    const foundry = this.players.find((player) => player.factionId === "foundry");
    if (foundry) {
      foundry.compute = this.rulesVariant.foundryStartingCompute;
    }
    const safety = this.players.find((player) => player.factionId === "safety_laboratory");
    if (safety && Number.isFinite(this.rulesVariant.safetyStartingTrust)) {
      safety.trust = this.rulesVariant.safetyStartingTrust;
    }
    if (!["variable", "fixed"].includes(mandateMode)) {
      throw new TypeError(`Unknown Mandate mode: ${mandateMode}.`);
    }
    this.mandateMode = mandateMode;
    this.simulateNegotiation = Boolean(simulateNegotiation);
    this.scenario = validateAgiDeclarationScenario(scenario, playerCount);
    this.onProgress = typeof onProgress === "function" ? onProgress : null;
    this.signal = signal;
    this.negotiationPromises = [];
    this.relationships = new Map();
    this.systemicRisk = 0;
    this.decisionSerial = 0;
    this.activeImmediateTradeSeat = null;
    this.immediateTradeDecisionWindows = new Set();
    this.immediateTradePackets = 0;
    this.immediateTradePacketCeiling = immediateTradePacketCeiling(playerCount, {
      counteroffers: this.rulesVariant.immediateTradeCounteroffers,
      thirdPartyClaims: this.rulesVariant.immediateTradeThirdPartyClaims
    });
    this.contractSerial = 0;
    this.contracts = [];
    this.megaClusters = [];
    this.fusionBuiltBy = null;
    this.trainingDrawPile = buildTrainingDeck(config, `${seed}:training-deck`);
    this.trainingDiscard = [];
    this.trainingShuffle = 0;
    this.tacticDrawPile = this.rulesVariant.tacticsEnabled
      ? shuffled(
        this.tacticDocument.tactics.flatMap((card) =>
          Array.from(
            { length: this.tacticDocument.copiesPerCard || 1 },
            () => card.id
          )
        ),
        `${seed}:tactics`
      )
      : [];
    this.tacticDiscard = [];
    this.scrutinyChoicesEnabled = false;
    this.pendingScrutinyOverflow = [];
    this.roundInitialized = false;
    this.firstAgiSeat = null;

    this.matchMetrics = {
      headlines: {},
      headlineOutcomes: {},
      mandates: {},
      projects: {},
      tactics: {},
      systemicRiskCreated: 0,
      declarations: 0,
      agiResolution: null,
      declarationReadiness: [],
      agiFunnel: this.players.map((player) => ({
        seat: player.seat,
        coreRequirementsMet: null,
        legalDeclarationWindow: null,
        claimRegistered: null,
        emergenceTriggered: null,
        declared: null
      })),
      powerTrades: [],
      negotiations: [],
      round4Start: null,
      futureTimeline: [],
      productionSnapshots: [],
      projectProduction: []
    };
    this.activeHeadline = null;
    this.regime = {};
    this.roundMandate = null;
    this.headlineDecks = Object.fromEntries(
      this.config.rounds.map(({ number: round }) => [
        round,
        shuffled(
          this.headlineDocument.headlines.filter((card) => this.headlineAvailable(card, round)),
          `${seed}:headlines:${round}`
        ).slice(0, 3)
      ])
    );
    this.mandateDeck = Object.fromEntries(
      this.config.rounds.map(({ number: round }) => [
        round,
        mandateMode === "fixed"
          ? this.mandateDocument.mandates.find((card) => card.era === round)
          : shuffled(
            this.mandateDocument.mandates.filter((card) => card.era === round),
            `${seed}:mandates:${round}`
          )[0]
      ])
    );

    for (const player of this.players) {
      const deployedAgents = Math.max(
        1,
        Math.min(config.playerSupply.agents, this.rulesVariant.startingAgentsDeployed)
      );
      const startingDistrict = player.pieces[0].tileId;
      player.pieces = Array.from({ length: deployedAgents }, (_, index) => ({
        id: `s${player.seat}-agent-${index + 1}`, kind: "agent", tileId: startingDistrict
      }));
      player.agentsInSupply = config.playerSupply.agents - deployedAgents;
      player.tactics = [];
      player.tacticPlayedCycleKey = null;
      player.objectiveId = null;
      player.jointVentures = [];
      player.megaClusters = [];
      player.agiDeclared = false;
      player.agiClaimed = false;
      player.latestProductionSnapshot = null;
      player.factionAbilityUsed = {};
      player.tacticModifiers = {};
      player.history = {
        deployRounds: [],
        cumulativeScrutiny: player.scrutiny,
        jointVenturePartners: [],
        fusionBuilt: false,
        declarations: 0
      };
      player.roundMetrics = {};
      player.metrics.headlines = {};
      player.metrics.projects = {};
      player.metrics.tactics = {};
      player.metrics.mandatesWon = {};
      player.metrics.objectiveCompleted = false;
      player.metrics.systemicRiskHits = 0;
      player.metrics.generatorChoices = {};
      player.metrics.generatorScrutiny = {};
      player.metrics.powerBought = 0;
      player.metrics.powerSold = 0;
      player.metrics.powerTradeRunway = 0;
      player.metrics.shovelsIncome = 0;
      player.metrics.factionAbilityValues = {};
      player.metrics.mandateEvents = [];
      player.dealFlowRunwayCredits = [];
      player.metrics.dealFlowConversion = {
        creditsGranted: 0,
        creditsSpent: 0,
        causallyNecessaryCreditsSpent: 0,
        conversionEligibleCreditsSpent: 0,
        nonConversionCreditsSpent: 0,
        mandateAttributed: 0,
        events: []
      };
      player.metrics.promisesMade = 0;
      player.metrics.promisesFulfilled = 0;
      player.metrics.promisesBroken = 0;
      player.metrics.selectionAvailability = {
        resolvableNow: 0,
        tradeRequired: 0
      };
      player.metrics.requiredTradeOffers = 0;
      player.metrics.requiredTradeAcceptances = 0;
      player.metrics.requiredTradeFailures = 0;
      player.metrics.blockedAfterCommitment = 0;
      player.mandateAwards = [];
      this.synchronizePublicMandate(player, "setup");
    }
    this.replay = [];
    this.publicHistory = [];
    this.recordEvent("match_started", null, simulationCopy.events.selectedMatchStarted);
  }

  isFactionAbilityPaused(player, abilityId) {
    return !this.hasFactionAbility(player, abilityId) ||
      this.rulesVariant.pausedFactionAbilities.some((entry) =>
      entry?.factionId === player.factionId && entry?.abilityId === abilityId
    );
  }

  hasFactionAbility(player, abilityId) {
    const factionList = Array.isArray(this.factions)
      ? this.factions
      : this.factions.factions;
    const faction = factionList.find((candidate) =>
      candidate.id === player.factionId
    );
    const ability = faction?.abilities.find((candidate) => candidate.id === abilityId);
    return Boolean(
      ability &&
      this.round >= ability.round &&
      (ability.persistsAfterUnlock || this.round === ability.round)
    );
  }

  addResource(player, key, amount) {
    super.addResource(player, key, amount);
    if (
      (key === "capability" || key === "trust") &&
      !this.deferredPublicMandateSeats?.has(player.seat)
    ) {
      this.synchronizePublicMandate(player, `${key}_threshold`);
    }
  }

  beginRunwayConversionContext(player, decision, kind = "action") {
    this.runwayConversionContexts ||= [];
    this.runwayConversionContexts.push({
      player,
      actionId: decision.actionId,
      decisionId: decision.decisionId,
      kind,
      events: []
    });
  }

  endRunwayConversionContext(player) {
    const context = this.runwayConversionContexts?.at(-1);
    if (context?.player === player) this.runwayConversionContexts.pop();
  }

  grantDealFlowRunway(player, details = {}) {
    const before = player.runway;
    this.addResource(player, "runway", 1);
    const granted = player.runway - before;
    if (!granted) return 0;
    const credit = {
      id: `deal-flow-r${this.round}-c${this.cycle}-s${player.seat}-` +
        `${player.metrics.dealFlowConversion.creditsGranted + 1}`,
      round: this.round,
      cycle: this.cycle,
      remaining: granted,
      ...clone(details)
    };
    player.dealFlowRunwayCredits.push(credit);
    player.metrics.dealFlowConversion.creditsGranted += granted;
    return granted;
  }

  spendRunway(player, amount, details = {}) {
    const before = player.runway;
    const spent = Math.min(before, Math.max(0, Number(amount) || 0));
    if (!spent) return 0;
    const taggedBefore = player.dealFlowRunwayCredits.reduce(
      (sum, credit) => sum + credit.remaining,
      0
    );
    const untaggedBefore = Math.max(0, before - taggedBefore);
    let taggedSpent = Math.min(taggedBefore, Math.max(0, spent - untaggedBefore));
    let remainingTaggedSpend = taggedSpent;
    for (const credit of player.dealFlowRunwayCredits) {
      if (!remainingTaggedSpend) break;
      const consumed = Math.min(credit.remaining, remainingTaggedSpend);
      credit.remaining -= consumed;
      remainingTaggedSpend -= consumed;
    }
    player.runway -= spent;
    if (!taggedSpent) return spent;

    const context = [...(this.runwayConversionContexts || [])]
      .reverse()
      .find((candidate) => candidate.player === player);
    const conversionEligible = Boolean(details.conversionEligible && context);
    const event = {
      round: this.round,
      cycle: this.cycle,
      cause: details.cause || "runway_spend",
      actionId: context?.actionId || null,
      decisionId: context?.decisionId || null,
      contextKind: context?.kind || null,
      runwaySpent: spent,
      dealFlowCreditsSpent: taggedSpent,
      causallyNecessaryCreditsSpent: conversionEligible ? taggedSpent : 0,
      conversionEligible,
      mandateAttributed: 0
    };
    player.metrics.dealFlowConversion.creditsSpent += taggedSpent;
    if (conversionEligible) {
      player.metrics.dealFlowConversion.causallyNecessaryCreditsSpent += taggedSpent;
      player.metrics.dealFlowConversion.conversionEligibleCreditsSpent += taggedSpent;
      context.events.push(event);
    } else {
      player.metrics.dealFlowConversion.nonConversionCreditsSpent += taggedSpent;
    }
    player.metrics.dealFlowConversion.events.push(event);
    return spent;
  }

  markAgiFunnel(player, stage, timing, details = {}) {
    const entry = this.matchMetrics.agiFunnel[player.seat];
    if (!entry || entry[stage]) return;
    entry[stage] = {
      round: this.round,
      cycle: this.cycle,
      timing,
      ...clone(details)
    };
  }

  recordAgiCoreRequirements(player, timing) {
    if (this.declarationReadiness(player).ready) {
      this.markAgiFunnel(player, "coreRequirementsMet", timing, this.declarationReadiness(player));
    }
  }

  currentAgiRequirements() {
    return { ...this.rulesVariant.agiAchievement };
  }

  recordFactionAbility(player, abilityId, values = {}) {
    const entry = player.metrics.factionAbilityValues[abilityId] || {
      uses: 0
    };
    entry.uses += values.uses ?? 1;
    for (const [key, value] of Object.entries(values)) {
      if (key === "uses") continue;
      // Ability telemetry mixes additive measurements with descriptive fields
      // such as Allocation Window's payment resource. Never coerce strings
      // into repeated numeric aggregates ("runwayrunway").
      if (typeof value === "number") {
        entry[key] = (Number(entry[key]) || 0) + value;
      } else if (entry[key] === undefined) {
        entry[key] = value;
      } else if (entry[key] !== value) {
        entry[key] = [...new Set([].concat(entry[key], value))];
      }
    }
    player.metrics.factionAbilityValues[abilityId] = entry;
  }

  addScrutiny(player, amount) {
    if (!this.scrutinyChoicesEnabled) {
      const before = player.metrics.scrutinyAdded;
      super.addScrutiny(player, amount);
      player.history.cumulativeScrutiny += player.metrics.scrutinyAdded - before;
      return;
    }
    const before = player.metrics.scrutinyAdded;
    const added = Math.min(
      Math.max(0, amount),
      this.config.playerSupply.scrutinyCubes - player.scrutiny
    );
    player.scrutiny += added;
    player.metrics.scrutinyAdded += added;
    const overflow = Math.max(0, amount - added);
    if (overflow) {
      this.pendingScrutinyOverflow.push({
        seat: player.seat,
        count: overflow,
        round: this.round,
        cycle: this.cycle
      });
    }
    player.history.cumulativeScrutiny += player.metrics.scrutinyAdded - before;
  }

  async settlePendingScrutinyOverflow(policies, stage = "scrutiny_overflow") {
    void policies;
    while (this.pendingScrutinyOverflow.length) {
      const pending = this.pendingScrutinyOverflow.shift();
      const player = this.players[pending.seat];
      for (let index = 0; index < pending.count; index += 1) {
        this.applyAutomaticPenalty(player, stage);
      }
    }
  }

  prepareTrainingDrawPile() {
    if (!this.trainingDrawPile.length && this.trainingDiscard.length) {
      const remainder = shuffled(
        this.trainingDiscard,
        `${this.seed}:training-reshuffle:${this.trainingShuffle}`
      );
      this.trainingShuffle += 1;
      this.trainingDrawPile.push(...remainder);
      this.trainingDiscard = [];
    }
    return this.trainingDrawPile;
  }

  resolveTrainingRun(seat, player, parameters) {
    this.prepareTrainingDrawPile();
    let deck = this.trainingDrawPile.map((card) => ({ ...card }));
    let result = simulateTrainingRun(
      this.config,
      `${this.seed}:r${this.round}:c${this.cycle}:s${seat}:training`,
      {
        deck,
        stopAt: parameters.stopAt,

        bankBonus: Number(parameters.destinationCategory === "research"),
        crashRetain: this.hasFactionAbility(player, "crash_retention") ? 1 : 0,
        scientificMethod: this.scientificMethodAvailable(player),
        domainGain: 1
      }
    );
    if (result.deckExhausted && this.trainingDiscard.length) {
      const remainder = shuffled(
        this.trainingDiscard,
        `${this.seed}:training-reshuffle:${this.trainingShuffle}`
      );
      this.trainingShuffle += 1;
      deck = [...deck, ...remainder];
      result = simulateTrainingRun(
        this.config,
        `${this.seed}:r${this.round}:c${this.cycle}:s${seat}:training`,
        {
          deck,
          stopAt: parameters.stopAt,

          bankBonus: Number(parameters.destinationCategory === "research"),
        crashRetain: this.hasFactionAbility(player, "crash_retention") ? 1 : 0,
        scientificMethod: this.scientificMethodAvailable(player),
        domainGain: 1
        }
      );
      this.trainingDrawPile.push(...remainder);
      this.trainingDiscard = [];
    }
    const deckSnapshot = deck.map((card) => ({ ...card }));
    this.trainingDiscard.push(
      ...this.trainingDrawPile.splice(0, result.cardsDrawn)
    );
    return { ...result, deckSnapshot };
  }

  drawTrainingCard() {
    this.prepareTrainingDrawPile();
    if (!this.trainingDrawPile.length) return null;
    return this.trainingDrawPile.shift();
  }

  scientificMethodAvailable(player) {
    return this.hasFactionAbility(player, "scientific_method") && player.runway >= 1;
  }

  async resolveTrainingRunWithPolicies(policies, seat, parameters) {
    const player = this.players[seat];
    const ordinaryDomains = new Set();
    const revealedCards = [];
    const revealed = [];
    let provisionalCapability = 0;
    let trust = 0;
    let scrutiny = 0;
    let outcome = "banked";
    let protection = null;
    let crashProtectable = false;

    while (true) {
      const card = this.drawTrainingCard();
      if (!card) {
        outcome = "deck-exhausted-banked";
        break;
      }
      revealedCards.push(card);
      revealed.push(card.type);
      let duplicate = false;

      if (card.kind === "domain") {
        duplicate = ordinaryDomains.has(card.type);
        if (!duplicate) {
          ordinaryDomains.add(card.type);
          provisionalCapability += 1;
        }
      } else if (card.type === "curated_corpus") {
        const missing = TRAINING_DOMAINS.filter((domain) => !ordinaryDomains.has(domain));
        if (!missing.length) duplicate = true;
        else {
          const choice = await this.choose(
            policies,
            seat,
            "training_curated_domain",
            missing.map((domain) => ({
              decisionId: `training_curated_${domain}`,
              label: decisionLabel("trainingCuratedDomain", { domain }),
              actionId: "research",
              parameters: { domain }
            }))
          );
          ordinaryDomains.add(choice.parameters.domain);
          provisionalCapability += 1;
        }
      } else if (card.type === "benchmark_leak") {
        provisionalCapability += 2;
        scrutiny += 1;
      } else if (card.type === "human_evaluation") {
        trust += 1;
        outcome = "human-evaluation-banked";
        break;
      }

      if (duplicate) {
        crashProtectable = true;
        const choices = [];
        if (crashProtectable && this.scientificMethodAvailable(player)) {
          choices.push({
            decisionId: "training_protect_scientific_method",
            label: decisionLabel("trainingProtectScientificMethod", {
              cost: 1
            }),
            actionId: "research",
            parameters: { protection: "scientific_method" }
          });
        }
        if (
          this.rulesVariant.tacticsEnabled &&
          player.tactics.includes("emergency_pause") &&
          player.tacticPlayedCycleKey !== `${this.round}:${this.cycle}`
        ) {
          choices.push({
            decisionId: "training_emergency_pause",
            label: decisionLabel("trainingEmergencyPause"),
            actionId: "research",
            parameters: { protection: "emergency_pause" }
          });
        }
        choices.push({
          decisionId: "training_accept_crash",
          label: decisionLabel("trainingAcceptCrash"),
          actionId: "research",
          parameters: { protection: null }
        });
        const choice = choices.length === 1
          ? choices[0]
          : await this.choose(policies, seat, "training_duplicate", choices);
        protection = choice.parameters.protection;
        if (protection === "emergency_pause") {
          provisionalCapability = 0;
          outcome = "emergency-pause";
          this.consumeTactic(player, "emergency_pause");
          player.tacticPlayedCycleKey = `${this.round}:${this.cycle}`;
        } else if (protection) {
          outcome = `${protection}-banked`;
        } else {
          provisionalCapability = Math.min(provisionalCapability, this.hasFactionAbility(player, "crash_retention") ? 1 : 0);
          scrutiny += 1;
          outcome = "crashed";
        }
        break;
      }

      const choice = await this.choose(policies, seat, "training_continue", [
        {
          decisionId: "training_bank",
          label: decisionLabel("trainingBank", { capability: provisionalCapability }),
          actionId: "research",
          parameters: { continue: false }
        },
        {
          decisionId: "training_continue",
          label: decisionLabel("trainingContinue", { capability: provisionalCapability }),
          actionId: "research",
          parameters: { continue: true }
        }
      ]);
      if (!choice.parameters.continue) {
        outcome = "banked";
        break;
      }
    }

    this.trainingDiscard.push(...revealedCards);
    return {
      seed: `${this.seed}:r${this.round}:c${this.cycle}:s${seat}:training`,
      outcome,
      capability: provisionalCapability + (outcome === "crashed" ? 0 : Number(parameters.destinationCategory === "research")),
      trust,
      scrutiny,
      runwaySpent: 0,
      protectedDuplicate: Boolean(protection),
      protection,
      crashProtectable,
      ordinaryDomains: [...ordinaryDomains],
      ordinaryDomainCount: ordinaryDomains.size,
      distinctDomains: ordinaryDomains.size,
      revealed,
      cardsDrawn: revealed.length,
      deckExhausted: this.trainingDrawPile.length === 0,
      deckSnapshot: revealedCards.map((card) => ({ ...card }))
    };
  }

  currentScore(player) {
    return player.mandate;
  }

  factionResourceCap(player, resource) {
    const factionList = Array.isArray(this.factions)
      ? this.factions
      : this.factions.factions;
    return factionList.find((faction) => faction.id === player.factionId)
      ?.resourceCaps?.[resource] ?? this.config.resources[resource].cap;
  }

  latestPoweredFacilities(player) {
    const connected = this.infrastructureState(player).locallyEligible;
    return player.facilities.filter((facility) => connected.has(facility.id));
  }

  latestOfflineFacilities(player) {
    const poweredIds = new Set(this.latestPoweredFacilities(player).map((facility) => facility.id));
    return player.facilities.filter((facility) => !poweredIds.has(facility.id));
  }

  finalMandate(player) {
    const poweredFacilityMandate = this.latestPoweredFacilities(player).length *
      this.rulesVariant.finalPoweredFacilityMandate;
    const offlinePenalty = this.latestOfflineFacilities(player).length *
      this.config.scoring.finalOnly.offlineFacilityPenalty;
    return {
      score: Math.max(
        0,
        this.currentScore(player) + poweredFacilityMandate - offlinePenalty
      ),
      poweredFacilityMandate,
      offlinePenalty
    };
  }

  awardMandate(player, points, source) {
    if (!points) return;
    player.mandate += points;
    player.metrics.mandateEvents.push({
      round: this.round,
      cycle: this.cycle,
      source,
      points,
      total: player.mandate
    });
    const context = [...(this.runwayConversionContexts || [])]
      .reverse()
      .find((candidate) => candidate.player === player && candidate.events.length);
    if (context) {
      const event = context.events.at(-1);
      event.mandateAttributed += points;
      player.metrics.dealFlowConversion.mandateAttributed += points;
    }
    this.recordEvent(
      "mandate_awarded",
      player.seat,
      renderSimulationCopy(simulationCopy.events.mandateAwarded, {
        faction: player.factionName,
        points,
        source
      })
    );
  }

  synchronizePublicMandate(player, source) {
    const known = new Set(player.mandateAwards.map(award => award.id));
    for (const base of publicMandateAwards(this.config, player)) {
      if (known.has(base.id)) continue;
      let points = base.points;
      if (base.id.startsWith("customer-")) {
        const schedule = this.rulesVariant.customerMandateSchedule;
        const number = Number(base.id.slice(9));
        points = schedule && number >= schedule.lateFromCustomer ? schedule.lateMandate : schedule?.baseMandate ?? this.rulesVariant.customerMandate;
      } else if (base.id.startsWith("capability-")) {
        if (Number.isFinite(this.rulesVariant.capabilityThresholdMandate)) points = this.rulesVariant.capabilityThresholdMandate;
        else if (Number(base.id.slice(11)) >= 9) points = this.rulesVariant.lateCapabilityThresholdMandate;
      }
      player.mandateAwards.push({ ...base, points, source });
      this.awardMandate(player, points, base.id);
    }
    return { capabilityMandateWithheld: 0 };
  }

  controlledCategories(player) {
    const categories = new Set();
    for (const tile of this.board) {
      if (tile.category === "frontier") continue;
      const scores = this.players.map((candidate) => {
        const pieces = candidate.pieces
          .filter((piece) => piece.tileId === tile.instanceId)
          .length;
        const facilities = candidate.facilities
          .filter((facility) => facility.tileId === tile.instanceId).length;
        return pieces + facilities;
      });
      const maximum = Math.max(...scores);
      if (maximum > 0 && scores.filter((score) => score === maximum).length === 1) {
        if (scores[player.seat] === maximum) categories.add(tile.category);
      }
    }
    return categories;
  }

  controller(category) {
    const tile = this.board.find((candidate) => candidate.category === category);
    return tile ? this.districtController(tile.instanceId) : null;
  }

  districtController(tileId) {
    const tile = this.board.find((candidate) => candidate.instanceId === tileId);
    if (!tile || tile.category === "frontier") return null;
    const scores = this.players.map((player) => {
      const pieces = player.pieces
        .filter((piece) => piece.tileId === tile.instanceId)
        .length;
      return pieces +
        player.facilities.filter((item) => item.tileId === tile.instanceId).length;
    });
    const maximum = Math.max(...scores);
    if (maximum === 0 || scores.filter((score) => score === maximum).length !== 1) return null;
    return scores.indexOf(maximum);
  }

  hasPresenceAtCategory(player, category) {
    const tileIds = new Set(
      this.board.filter((tile) => tile.category === category).map((tile) => tile.instanceId)
    );
    return player.pieces.some((piece) => tileIds.has(piece.tileId)) ||
      player.facilities.some((facility) => tileIds.has(facility.tileId));
  }

  nearestInitiative(seats) {
    return this.initiativeOrder().find((seat) => seats.includes(seat));
  }

  publicObservation(seat) {
    this.refreshConnections();
    const base = super.publicObservation(seat);
    const player = this.players[seat];
    return {
      ...base,
      activeHeadline: this.activeHeadline
        ? { id: this.activeHeadline.id, name: this.activeHeadline.name, text: this.activeHeadline.text }
        : null,
      roundMandate: this.roundMandate
        ? { id: this.roundMandate.id, name: this.roundMandate.name, rulesText: this.roundMandate.rulesText }
        : null,
      self: {
        ...base.self,
        tactics: [...player.tactics],
        objectiveId: player.objectiveId,
        agentsInSupply: player.agentsInSupply,
        jointVentures: player.jointVentures.length,
        agiDeclared: player.agiDeclared,
        agiReadiness: this.declarationReadiness(player),
        dealFlowConversion: {
          unspentCredits: player.dealFlowRunwayCredits.reduce(
            (sum, credit) => sum + credit.remaining,
            0
          ),
          causallyNecessaryCreditsSpent:
            player.metrics.dealFlowConversion.causallyNecessaryCreditsSpent,
          mandateAttributed: player.metrics.dealFlowConversion.mandateAttributed
        },
        currentScore: this.currentScore(player)
      },
      opponents: base.opponents.map((opponent) => {
        const source = this.players[opponent.seat];
        return {
          ...opponent,
          currentScore: this.currentScore(source),
          agiDeclared: source.agiDeclared,
          relationship: this.relationshipFor(seat, source.seat)
        };
      }),
      publicTable: {
        players: this.players.map((candidate) => ({
          ...this.publicPlayerState(candidate),
          factionAbilityUsed: this.copyPublic(candidate.factionAbilityUsed || {}),
          agentsInSupply: candidate.agentsInSupply,
          jointVentures: this.copyPublic(candidate.jointVentures),
          megaClusters: this.copyPublic(candidate.megaClusters || []),
          agiDeclared: candidate.agiDeclared,
          agiReadiness: this.declarationReadiness(candidate),
          currentScore: this.currentScore(candidate)
        })),
        contracts: this.copyPublic(this.contracts),
        systemicRisk: this.systemicRisk
      }
    };
  }

  packet(seat, stage, legalDecisions) {
    const packet = super.packet(seat, `${stage}:${this.decisionSerial++}`, legalDecisions);
    packet.requestId = `${packet.matchId}:r${this.round}:c${this.cycle}:s${seat}:${stage}:${this.decisionSerial}`;
    return packet;
  }

  async choose(policies, seat, stage, legalDecisions) {
    throwIfAborted(this.signal);
    this.registerImmediateTradeDecisionWindow(seat, stage);
    const packet = this.packet(seat, stage, legalDecisions);
    const result = await policies[seat].decide(packet);
    this.recordPolicyReceipt(this.players[seat], result.receipt);
    const selected = legalDecisions.find(
      (decision) => decision.decisionId === result.decision.decisionId
    );
    if (!selected) throw new Error(`Policy selected missing decision ${result.decision.decisionId}.`);
    this.recordEvent("strategy_decision", seat, `${stage}: ${selected.label}.`, result.receipt);
    return selected;
  }

  registerImmediateTradeDecisionWindow(seat, stage) {
    if (!stage.startsWith("immediate_trade")) return;
    const activeSeat = this.activeImmediateTradeSeat ?? seat;
    const key = `${this.round}:${this.cycle}:${activeSeat}:${seat}:${stage}`;
    if (this.immediateTradeDecisionWindows.has(key)) {
      throw new Error(`Immediate-trade formal window repeated: ${key}.`);
    }
    this.immediateTradeDecisionWindows.add(key);
    this.immediateTradePackets += 1;
    if (this.immediateTradePackets > this.immediateTradePacketCeiling) {
      throw new Error(
        `Immediate-trade packet ceiling exceeded: ${this.immediateTradePackets}/` +
        `${this.immediateTradePacketCeiling}.`
      );
    }
  }

  relationshipFor(leftSeat, rightSeat) {
    return clone(this.relationships.get(`${leftSeat}:${rightSeat}`) || {
      fulfilled: 0,
      broken: 0
    });
  }

  changeRelationship(leftSeat, rightSeat, field) {
    for (const key of [`${leftSeat}:${rightSeat}`, `${rightSeat}:${leftSeat}`]) {
      const relationship = this.relationships.get(key) || { fulfilled: 0, broken: 0 };
      relationship[field] += 1;
      this.relationships.set(key, relationship);
    }
  }

  async chooseAll(policies, stage, decisionsForSeat) {
    return Promise.all(this.players.map((player) =>
      this.choose(policies, player.seat, stage, decisionsForSeat(player.seat))
    ));
  }

  dealTactic(player) {
    if (!this.rulesVariant.tacticsEnabled || !this.tacticDrawPile.length) return null;
    const tacticId = this.tacticDrawPile.shift();
    player.tactics.push(tacticId);
    return tacticId;
  }

  async setup(policies) {
    this.scrutinyChoicesEnabled = true;
    if (!this.rulesVariant.tacticsEnabled) return;
    for (const player of this.players) this.dealTactic(player);
  }

  async beginRound(policies) {
    if (this.round === 4 && this.matchMetrics.round4Start === null) {
      this.matchMetrics.round4Start = this.players.map((player) => ({
        seat: player.seat,
        score: this.currentScore(player),
        profileId: player.profileId
      }));
    }
    this.roundMandate = this.mandateDeck[this.round];
    this.regime = { persistent: this.regime.persistent || {}, round: {} };
    for (const player of this.players) {
      player.actionsUsed = [];
      player.selectedAction = null;

      player.tacticModifiers = {};
      player.roundMetrics = {
        capabilityStart: player.capability,
        customersStart: player.customers,
        scrutinyStart: player.metrics.scrutinyAdded,
        fundRunway: 0,
        computeProduced: 0,
        bestTrainingDomains: 0,
        deployed: false,
        jointVenturesCompleted: 0,
        riskyActions: 0
      };
      if (this.rulesVariant.tacticsEnabled) {
        this.dealTactic(player);
        while (player.tactics.length > 3) {
          const uniqueChoices = player.tactics.map((tacticId, index) => {
            const card = this.tacticDocument.tactics.find(
              (candidate) => candidate.id === tacticId
            );
            return {
              decisionId: `tactic_discard_${index}_${tacticId}`,
              label: decisionLabel("discardTactic", { card: card?.name || tacticId }),
              actionId: "tactic",
              parameters: { index, tacticId }
            };
          });
          const choice = await this.choose(
            policies,
            player.seat,
            "tactic_hand_limit",
            uniqueChoices
          );
          const [discarded] = player.tactics.splice(choice.parameters.index, 1);
          this.tacticDiscard.push(discarded);
        }
      }
    }
    this.roundInitialized = true;
    this.recordEvent(
      "round_started",
      null,
      renderSimulationCopy(simulationCopy.events.roundStarted, {
        round: this.round,
        mandate: this.roundMandate.name
      })
    );
  }

  headlineAvailable(card, round) {
    if (card.round !== round) return false;
    return true;
  }

  async prepareHeadline(policies) {
    this.activeHeadline = this.headlineDecks[this.round][this.cycle - 1];
    // History is separate from rules state: no Headline leaves a modifier behind.
    this.regime.cycle = {};
    const id = this.activeHeadline.id;
    increment(this.matchMetrics.headlines, id);
    this.matchMetrics.futureTimeline.push({ round: this.round, cycle: this.cycle,
      id, name: this.activeHeadline.name });
    this.recordEvent("headline_revealed", null, `${this.activeHeadline.name}: ${this.activeHeadline.text}`);
    const ordered = this.initiativeOrder().map(seat => this.players[seat]);
    const extreme = (key, direction) => {
      const value = direction(...this.players.map(player => player[key]));
      return this.players[this.nearestInitiative(this.players.filter(player => player[key] === value).map(player => player.seat))];
    };
    const offer = async (player, label, consequences, eligible = true, parameters = {}) => {
      if (!eligible) return false;
      const choice = await this.choose(policies, player.seat, `headline_${id}`, [
        { decisionId: `${id}_pass`, label: "Decline the Headline offer", actionId: "headline" },
        { decisionId: `${id}_accept`, label, actionId: "headline", consequences, parameters }
      ]);
      return choice.decisionId.endsWith("_accept");
    };
    const produce = async (player, optional = false) => {
      const facilities = this.latestPoweredFacilities(player);
      if (!facilities.length) return;
      const choice = await this.choose(policies, player.seat, `headline_${id}_facility`, [
        ...(optional ? [{ decisionId: `${id}_pass`, label: "Decline additional production", actionId: "headline" }] : []),
        ...facilities.map(facility => ({ decisionId: `${id}_${facility.id}`,
          label: `${optional ? "Add 1 Scrutiny; " : ""}produce ${facility.id} (${facility.category})`,
          actionId: "headline", parameters: { facilityId: facility.id },
          consequences: { scrutiny: Number(optional), produceFacility: true } }))
      ]);
      const facility = facilities.find(candidate => candidate.id === choice.parameters?.facilityId);
      if (!facility) return;
      if (optional) this.addScrutiny(player, 1);
      await this.produceFacility(policies, player, facility, `headline_${id}`);
    };
    const addSystemicRisk = () => {
      if (this.systemicRisk < this.config.sharedSupply.systemicRiskCubes) {
        this.systemicRisk += 1;
        this.matchMetrics.systemicRiskCreated += 1;
      }
    };
    if (id === "open_weights_drop") {
      for (const player of ordered) this.addResource(player, "capability", 1);
      this.addResource(extreme("customers", Math.min), "trust", 1);
    } else if (id === "export_controls") {
      const chip = this.board.find(tile => tile.category === "chip");
      const chipController = chip ? this.districtController(chip.instanceId) : null;
      if (chipController !== null) this.addResource(this.players[chipController], "runway", 1);
      for (const player of ordered) {
        if (this.controlledCategories(player).has("government")) this.addResource(player, "runway", 1);
      }
    } else if (id === "weights_on_internet") {
      const low = extreme("capability", Math.min), high = extreme("capability", Math.max);
      await produce(low);
      this.addResource(high, "trust", 1);
    } else if (id === "agi_blog_post") {
      this.addResource(extreme("capability", Math.max), "trust", 1);
    } else if (id === "professional_exam_sweep") {
      for (const player of ordered) {
        if (player.capability >= 3) this.addResource(player, "trust", 1);
        if (player.capability >= 5) this.removeScrutiny(player, 1);
      }
    } else if (id === "reactor_restart_one_model") {
      for (const player of ordered) if (player.generators.some(generator => generator.sourceId === "clean_infrastructure")) {
        this.awardMandate(player, 1, id);
      }
    } else if (id === "ai_written_law") {
      let accepted = 0;
      for (const player of ordered) if (await offer(player, "Pay 1 Runway; gain 1 Trust", { runway: -1, trust: 1 }, player.runway >= 1)) {
        this.spendRunway(player, 1, { cause: id });
        this.addResource(player, "trust", 1); accepted++;
      }
      for (const player of ordered) {
        if (this.controlledCategories(player).has("government")) this.addResource(player, "runway", accepted);
      }
    } else if (id === "autonomous_corporation") {
      const counts = this.players.map(player => this.board.filter(tile => this.districtController(tile.instanceId) === player.seat).length);
      const player = this.players[this.nearestInitiative(this.players.filter(player => counts[player.seat] === Math.max(...counts)).map(player => player.seat))];
      if (await offer(player, "Gain 2 Runway; add 1 Scrutiny", { runway: 2, scrutiny: 1 })) {
        this.addResource(player, "runway", 2); this.addScrutiny(player, 1);
      }
    } else if (id === "employee_free_unicorn") {
      for (const player of ordered) {
        if (player.pieces.length <= 1) continue;
        const choice = await this.choose(policies, player.seat, `headline_${id}`, [
          { decisionId: `${id}_pass`, label: "Keep all Agents", actionId: "headline" },
          ...player.pieces.map(piece => ({ decisionId: `${id}_${piece.id}`, label: `Return ${piece.id}; gain 2 Runway and add 2 Scrutiny`,
            actionId: "headline", parameters: { pieceId: piece.id }, consequences: { runway: 2, scrutiny: 2, agents: -1 } }))
        ]);
        if (!choice.parameters?.pieceId) continue;
        player.pieces = player.pieces.filter(piece => piece.id !== choice.parameters.pieceId);
        player.agentsInSupply++; this.addResource(player, "runway", 2); this.addScrutiny(player, 2);
      }
    } else if (id === "humanoid_factory_gate") {
      for (const player of ordered) {
        if (!player.agentsInSupply || player.runway < 1) continue;
        const destinations = [...new Set(player.pieces.map(piece => piece.tileId))];
        const choice = await this.choose(policies, player.seat, `headline_${id}`, [
          { decisionId: `${id}_pass`, label: "Decline recruitment", actionId: "headline" },
          ...destinations.map(tileId => ({ decisionId: `${id}_${tileId}`, label: `Pay 1 Runway; recruit in ${this.board.find(tile => tile.instanceId === tileId).name}; add 1 Scrutiny`,
            actionId: "headline", parameters: { tileId }, consequences: { runway: -1, agents: 1, scrutiny: 1 } }))
        ]);
        if (!choice.parameters?.tileId) continue;
        const number = Array.from({length: this.config.playerSupply.agents}, (_, i) => i + 1).find(i => !player.pieces.some(piece => piece.id === `s${player.seat}-agent-${i}`));
        this.spendRunway(player, 1, { cause: id });
        player.pieces.push({ id: `s${player.seat}-agent-${number}`, kind: "agent", tileId: choice.parameters.tileId });
        player.agentsInSupply--; this.addScrutiny(player, 1);
      }
    } else if (id === "agent_swarm_escapes_scope") {
      for (const player of ordered) await produce(player, true);
    } else {
      for (const player of ordered) {
        if (id === "ten_dollar_intelligence" && await offer(player, "Gain 1 Compute; add 1 Scrutiny", { compute: 1, scrutiny: 1 })) {
          this.addResource(player, "compute", 1); this.addScrutiny(player, 1);
        } else if (id === "synthetic_celebrity" && await offer(player, "Pay 1 Compute; gain 1 Capability and add 1 Scrutiny", { compute: -1, capability: 1, scrutiny: 1 }, player.compute >= 1)) {
          player.compute--; this.addResource(player, "capability", 1); this.addScrutiny(player, 1);
        } else if (id === "emergency_power_authority") {
          const power = this.infrastructureState(player);
          const eligible = power.connectedGenerators.some(generator => generator.sourceId === "emergency_infrastructure");
          if (await offer(player, "Gain 2 Compute; add 1 Scrutiny", { compute: 2, scrutiny: 1 }, eligible)) {
            this.addResource(player, "compute", 2); this.addScrutiny(player, 1);
          }
        } else if (id === "benchmark_is_economy" && await offer(player, "Gain 1 Capability; add 1 Systemic Risk", { capability: 1, systemicRisk: 1 })) {
          this.addResource(player, "capability", 1); addSystemicRisk();
        } else if (id === "recursive_self_improvement" && await offer(player, "Pay 2 Compute; gain 3 Capability, add 2 Scrutiny and 1 Systemic Risk", { compute: -2, capability: 3, scrutiny: 2, systemicRisk: 1 }, player.compute >= 2)) {
          player.compute -= 2; this.addResource(player, "capability", 3); this.addScrutiny(player, 2); addSystemicRisk();
        }
      }
    }
    this.recordEvent("headline_resolved", null, `${this.activeHeadline.name}: all instructions complete; no continuing effect.`);
  }

  consumeTactic(player, id) {
    const index = player.tactics.indexOf(id);
    if (index >= 0) {
      player.tactics.splice(index, 1);
      this.tacticDiscard.push(id);
    }
    increment(player.metrics.tactics, id);
    increment(this.matchMetrics.tactics, id);
  }

  async maybePlayTacticForResolution(policies, seat, selectedDecision) {
    const decision = clone(selectedDecision);
    const player = this.players[seat];
    const cycleKey = `${this.round}:${this.cycle}`;
    if (
      !this.rulesVariant.tacticsEnabled ||
      player.tacticPlayedCycleKey === cycleKey
    ) return decision;

    const tacticRequired = decision.actionId === "deploy" &&
      (decision.parameters?.computeCost || 0) > player.compute;
    const usable = [...new Set(player.tactics)].filter((id) => {
      if (tacticRequired) return id === "api_price_cut";
      if (["open_letter", "emergency_pause"].includes(id)) return false;
      if (id === "cloud_partnership") return player.runway >= 1;
      if (id === "api_price_cut" || id === "model_card") {
        return decision.actionId === "deploy";
      }
      if (id === "talent_raid") {
        return player.runway >= 1 && player.agentsInSupply > 0 &&
          Boolean(decision.parameters?.destinationId);
      }
      if (id === "board_reshuffle") {
        return player.actionsUsed.some((action) =>
          ["organize", "influence"].includes(action)
        );
      }
      if (id === "weights_leak") {
        return this.players.some((candidate) =>
          candidate.seat !== seat && this.latestPoweredFacilities(candidate).length
        );
      }
      if (id === "custom_silicon") return player.facilities.length > 0;
      if (id === "government_contract") return player.trust >= 4;
      if (id === "benchmark_optimization") return decision.actionId === "research";
      return id === "interconnection_waiver";
    });
    if (!usable.length) return decision;

    const choice = await this.choose(policies, seat, "tactic_resolution", [
      ...(!tacticRequired ? [{
        decisionId: "tactic_pass",
        label: decisionLabel("skipTactic"),
        actionId: "tactic",
        parameters: { tacticId: null }
      }] : []),
      ...usable.map((id) => {
        const card = this.tacticDocument.tactics.find((candidate) => candidate.id === id);
        return {
          decisionId: `tactic_${id}`,
          label: decisionLabel("playTactic", { card: card.name, text: card.text }),
          actionId: "tactic",
          parameters: { tacticId: id }
        };
      })
    ]);
    const id = choice.parameters.tacticId;
    if (!id) return decision;

    if (id === "cloud_partnership") {
      const target = await this.choose(
        policies,
        seat,
        "tactic_cloud_partnership_target",
        this.players.filter((candidate) => candidate.seat !== seat).map((candidate) => ({
          decisionId: `tactic_cloud_partnership_${candidate.seat}`,
          label: decisionLabel("tacticChooseBeneficiary", { seat: candidate.seat + 1 }),
          actionId: "tactic",
          parameters: { targetSeat: candidate.seat }
        }))
      );
      this.spendRunway(player, 1, {
        cause: "tactic_cloud_partnership",
        conversionEligible: true
      });
      this.addResource(player, "compute", 2);
      this.addResource(this.players[target.parameters.targetSeat], "runway", 1);
    } else if (id === "api_price_cut") {
      decision.parameters.computeCost = 0;
      player.tacticModifiers.api_price_cut = true;
    } else if (id === "model_card") {
      player.tacticModifiers.model_card = true;
    } else if (id === "talent_raid") {
      this.spendRunway(player, 1, {
        cause: "tactic_talent_raid",
        conversionEligible: true
      });
      const usedNumbers = new Set(
        player.pieces.filter((piece) => piece.kind === "agent")
          .map((piece) => Number(piece.id.split("-").at(-1)))
      );
      const number = Array.from(
        { length: this.config.playerSupply.agents },
        (_, candidate) => candidate + 1
      ).find((candidate) => !usedNumbers.has(candidate));
      player.pieces.push({
        id: `s${seat}-agent-${number}`,
        kind: "agent",
        tileId: decision.parameters.destinationId
      });
      player.agentsInSupply -= 1;
    } else if (id === "board_reshuffle") {
      const readyable = [...new Set(player.actionsUsed.filter((action) =>
        ["organize", "influence"].includes(action)
      ))];
      const target = await this.choose(
        policies,
        seat,
        "tactic_board_reshuffle_target",
        readyable.map((action) => ({
          decisionId: `tactic_board_reshuffle_${action}`,
          label: decisionLabel("tacticReadyAction", { action }),
          actionId: "tactic",
          parameters: { action }
        }))
      );
      const index = player.actionsUsed.indexOf(target.parameters.action);
      if (index >= 0) player.actionsUsed.splice(index, 1);
    } else if (id === "weights_leak") {
      const targets = this.players.flatMap((candidate) =>
        candidate.seat === seat ? [] : this.latestPoweredFacilities(candidate).map((facility) => ({
          decisionId: `tactic_weights_leak_${candidate.seat}_${facility.id}`,
          label: decisionLabel("tacticChooseRivalFacility", {
            seat: candidate.seat + 1,
            facility: facility.id
          }),
          actionId: "tactic",
          parameters: { targetSeat: candidate.seat, facilityId: facility.id }
        }))
      );
      const target = await this.choose(policies, seat, "tactic_weights_leak_target", targets);
      const source = this.latestPoweredFacilities(
        this.players[target.parameters.targetSeat]
      ).find((facility) => facility.id === target.parameters.facilityId);
      await this.produceFacility(policies, player, source, "weights_leak");
    } else if (id === "custom_silicon") {
      const target = await this.choose(
        policies,
        seat,
        "tactic_custom_silicon_target",
        player.facilities.map((facility) => ({
          decisionId: `tactic_custom_silicon_${facility.id}`,
          label: decisionLabel("tacticChooseOwnFacility", { facility: facility.id }),
          actionId: "tactic",
          parameters: { facilityId: facility.id }
        }))
      );
      player.facilities.find(
        (facility) => facility.id === target.parameters.facilityId
      ).customSilicon = true;
    } else if (id === "government_contract") {
      this.addResource(player, "runway", 2);
    } else if (id === "benchmark_optimization") {
      player.tacticModifiers.benchmark_optimization = true;
    } else if (id === "interconnection_waiver") {
      this.addResource(player, "runway", 1);
      this.addResource(player, "trust", 1);
    }
    this.consumeTactic(player, id);
    player.tacticPlayedCycleKey = cycleKey;
    return decision;
  }


  canDeploy(player) {
    return player.customers < this.config.resources.customers.cap &&
      player.capability >= this.customerRequirement(player.customers);
  }

  customerRequirement(customerCount) {
    const base = CUSTOMER_REQUIREMENTS[customerCount] ?? Infinity;
    return Number.isFinite(base)
      ? Math.max(1, base + this.rulesVariant.customerCapabilityOffset)
      : base;
  }

  legalDestinations(player, piece) {
    return [...this.board];
  }

  legalActionSelections(seat) {
    return super.legalActionSelections(seat);
  }

  selectionResolutionCount(seat, actionId) {
    return this.currentResolutionCountForSelection(seat, actionId);
  }

  selectionAvailability(seat, actionId) {
    const currentResolutionCount = this.selectionResolutionCount(
      seat,
      actionId
    );
    return {
      currentResolutionCount,
      resolvableWithoutTrade: currentResolutionCount > 0,
      resolvableWithImmediateTrade: false,
      status: currentResolutionCount > 0 ? "resolvable_now" : "speculative"
    };
  }

  legalFactionActions(seat) {
    void seat;
    return [];
  }

  legalResolutions(seat, actionId) {
    const player = this.players[seat];
    if (actionId === "build") return this.legalBuildResolutions(seat);
    let decisions = super.legalResolutions(seat, actionId, {
      skipAffordability: true
    });
    if (actionId === "organize") {
      decisions = this.assignmentVariants(player, (piece, destination) => {
        const base = {
          pieceId: piece.id,
          destinationId: destination.instanceId,
          destinationCategory: destination.category
        };
        const result = [];
        if (player.agentsInSupply > 0) {
          const cost = Math.max(0, 2 - Number(destination.category === "talent"));
          const maximum = 1;
          if (player.runway >= cost) {
            for (let count = 1; count <= maximum; count += 1) {
              result.push({
                decisionId: `organize_recruit_${count}_${piece.id}_${destination.instanceId}`,
                label: decisionLabel("recruitAgents", {
                  count,
                  plural: count === 1 ? "" : "s",
                  cost
                }),
                actionId,
                parameters: { ...base, mode: "recruit", count, cost },
                consequences: { runway: -cost, agents: count }
              });
            }
          }
        }
        for (const facility of player.facilities.filter(
          (candidate) => candidate.tileId === destination.instanceId
        )) {
          for (const target of this.board.filter((tile) =>
            axialDistance(destination, tile) === 1 &&
            tile.category !== "frontier" &&
            this.tileOccupancy(tile.instanceId) <
              (tile.facilitySpaces ?? this.config.board.facilitySpacesPerHex)
          )) {
            result.push({
              decisionId: `organize_relocate_${facility.id}_${target.instanceId}_${piece.id}`,
              label: decisionLabel("moveFacilityBetween", {
                facility: facility.id,
                from: destination.name,
                to: target.name
              }),
              actionId,
              parameters: {
                ...base,
                mode: "relocate",
                facilityId: facility.id,
                facilityDestinationId: target.instanceId
              },
              consequences: { relocateFacility: true }
            });
          }
        }
        return result;
      });
    }
    if (
      actionId === "deploy" &&
      player.customers < this.config.resources.customers.cap
    ) {
      const baseRequirement = this.customerRequirement(player.customers);
      decisions = this.assignmentVariants(player, (piece, destination) => {
        const computeCost = destination.category === "consumer" ? 0 : this.rulesVariant.deployComputeCost;
        const requirement = baseRequirement;
        if (player.capability < requirement) return [];
        return [{
          decisionId:
            `deploy_${destination.category}_${piece.id}_${destination.instanceId}`,
          label: renderSimulationCopy(simulationCopy.decisions.moveAndDeploy, {
            piece: piece.id,
            destination: destination.name,
            customer: player.customers + 1
          }),
          actionId,
          parameters: {
            pieceId: piece.id,
            destinationId: destination.instanceId,
            destinationCategory: destination.category,
            computeCost
          },
          consequences: {
            compute: -computeCost,
            customers: 1,
            scrutiny: 1
          }
        }];
      });
    }

    if (actionId === "influence" && this.round >= 3) {
      if (this.jointVentureSupplyAvailable()) decisions.push(...this.assignmentVariants(player, (piece, destination) => {
        if (!player.facilities.some((facility) => facility.tileId === destination.instanceId)) {
          return [];
        }
        const contractChoices = [];
        for (const rival of this.players.filter((candidate) => candidate.seat !== seat)) {
          const range = 1;
          for (const left of player.facilities.filter((facility) =>
            facility.tileId === destination.instanceId
          )) for (const right of rival.facilities) {
            const leftTile = this.board.find((tile) => tile.instanceId === left.tileId);
            const rightTile = this.board.find((tile) => tile.instanceId === right.tileId);
            const distance = axialDistance(leftTile, rightTile);
            if (distance < 1 || distance > range) continue;
            const base = {
              pieceId: piece.id,
              destinationId: destination.instanceId,
              destinationCategory: destination.category,
              targetSeat: rival.seat,
              leftFacilityId: left.id,
              rightFacilityId: right.id
            };
            contractChoices.push({
              decisionId:
                `influence_joint_venture_${rival.seat}_${left.id}_${right.id}_` +
                `${piece.id}_${destination.instanceId}`,
              label: decisionLabel("proposeJointVenture", { seat: rival.seat + 1 }),
              actionId,
              parameters: { ...base, mode: "joint_venture" },
              consequences: { negotiation: true }
            });
          }
        }
        return contractChoices;
      }));
      const terminable = this.contracts.filter((contract) =>
        contract.kind === "joint_venture" &&
        (contract.left.seat === seat || contract.right.seat === seat)
      );
      if (terminable.length) decisions.push(...this.assignmentVariants(player, (piece, destination) =>
        player.facilities.some((facility) => facility.tileId === destination.instanceId)
          ? terminable.map((contract) => ({
          decisionId: `influence_terminate_joint_venture_${contract.id}_${piece.id}_` +
            destination.instanceId,
          label: decisionLabel("terminateJointVenture", { contract: contract.id }),
          actionId,
          parameters: {
            pieceId: piece.id,
            destinationId: destination.instanceId,
            destinationCategory: destination.category,
            mode: "terminate_joint_venture",
            contractId: contract.id
          },
          consequences: { terminateJointVenture: contract.id }
          }))
          : []
      ));
    }
    return decisions
      .map((decision) => this.adjustDecision(player, decision))
      .filter((decision) =>
        decision.parameters?.actualRunwayCost === undefined ||
        decision.parameters.actualRunwayCost <= player.runway
      )
      .filter((decision) => {
        const computeCost = decision.actionId === "research"
          ? decision.parameters?.actualComputeCost ?? 1
          : decision.actionId === "deploy"
            ? decision.parameters?.computeCost ?? 0
            : 0;
        const apiPriceCutAvailable =
          this.rulesVariant.tacticsEnabled &&
          decision.actionId === "deploy" &&
          player.tactics.includes("api_price_cut") &&
          player.tacticPlayedCycleKey !== `${this.round}:${this.cycle}`;
        return computeCost <= player.compute || apiPriceCutAvailable;
      });
  }

  adjustDecision(player, decision) {
    const result = { ...decision, parameters: { ...(decision.parameters || {}) } };
    const category = result.parameters.destinationCategory;
    if (result.actionId === "fund") {
      result.parameters.actualRunway = (result.parameters.mode === "venture" ? this.rulesVariant.fundVenture : this.rulesVariant.fundConservative) + Number(category === "capital");
    }
    if (result.actionId === "research") result.parameters.actualComputeCost = category === "cloud" ? 0 : 1;
    if (result.actionId === "deploy") result.parameters.computeCost = category === "consumer" || player.tacticModifiers.api_price_cut ? 0 : this.rulesVariant.deployComputeCost;
    if (result.actionId === "build") {
      result.parameters.actualRunwayCost = Math.max(0, this.rulesVariant.facilityCost - Number(category === "chip") - Number(this.hasFactionAbility(player, "industrial_velocity")));
    }
    return result;
  }

  legalBuildResolutions(seat) {
    const player = this.players[seat];
    const facilityChoices = super.legalResolutions(seat, "build", { skipAffordability: true });
    return this.assignmentVariants(player, (piece, destination) => {
      const base = { pieceId: piece.id, destinationId: destination.instanceId,
        destinationCategory: destination.category };
      const facilityChoice = facilityChoices
        .find(choice => choice.parameters.buildMode === "facility" &&
          choice.parameters.pieceId === piece.id && choice.parameters.destinationId === destination.instanceId);
      const facilityCost = facilityChoice
        ? this.adjustDecision(player, facilityChoice).parameters.actualRunwayCost : null;
      const decisions = [];
      for (const facility of [false, true]) {
        if (facility && (facilityCost === null || player.runway < facilityCost)) continue;
        const preview = { ...player, facilities: [...player.facilities], runway: player.runway - (facility ? facilityCost : 0) };
        const newFacility = { id: `s${seat}-facility-${player.facilities.length + 1}`,
          tileId: destination.instanceId, category: destination.category, powered: false };
        if (facility) preview.facilities.push(newFacility);
        const projects = [null];
        if (this.round >= 2 && destination.category === "energy" &&
            player.generators.filter(g => g.sourceId !== "fusion_demonstrator").length < this.rulesVariant.singleGeneratorRule.ordinaryGeneratorLimit &&
            this.generatorOccupancy(destination.instanceId) < 3) {
          const location = this.rulesVariant.singleGeneratorRule.locations[destination.id];
          if (location) projects.push({ id: "generator", sourceId: location.sourceId, runway: location.constructionCost, compute: 0 });
        }
        if (this.round >= 2 && this.megaClusters.length < this.config.sharedSupply.megaClusterPairs) {
          for (const left of preview.facilities) for (const right of preview.facilities) {
            if (left.id >= right.id || ![left.tileId, right.tileId].includes(destination.instanceId)) continue;
            if (this.megaClusterHostsAvailable([left.id, right.id]) && this.megaClusterLocallyEligible(preview, [left.id, right.id])) {
              projects.push({ id: "mega_cluster", leftId: left.id, rightId: right.id, runway: 3, compute: 2 });
            }
          }
        }
        if (this.round >= 4 && destination.id === "grid_reactor" && this.fusionBuiltBy === null && this.generatorOccupancy(destination.instanceId) < 3) {
          projects.push({ id: "fusion_demonstrator", runway: this.config.powerSources.find(source => source.id === "fusion_demonstrator").runwayCost, compute: 0 });
        }
        for (const project of projects) {
          if (!facility && !project) continue;
          const runway = (facility ? facilityCost : 0) + (project?.runway || 0);
          if (runway > player.runway || (project?.compute || 0) > player.compute) continue;
          const parts = [facility ? "Facility" : null, project ? (project.id === "generator" ? this.config.powerSources.find(source => source.id === project.sourceId).name : this.projectDocument.projects.find(item => item.id === project.id).name) : null].filter(Boolean);
          decisions.push({
            decisionId: `build_${facility ? `facility_${destination.category}` : project?.id === "generator" ? `generator_${project.sourceId}` : project?.id}_${project?.id || "none"}_${project?.leftId || ""}_${project?.rightId || ""}_${piece.id}_${destination.instanceId}`,
            label: `Assign ${piece.id} to ${destination.name}: construct ${parts.join(" + ")} (${runway} Runway${project?.compute ? `, ${project.compute} Compute` : ""})`,
            actionId: "build", parameters: { ...base, buildMode: "construction", facility, project, facilityCost: facility ? facilityCost : 0, actualRunwayCost: runway },
            consequences: { runway: -runway, compute: -(project?.compute || 0), ...(facility ? { facility: destination.category } : {}), ...(project ? { project: project.id, connectsLocalFacilities: project.id !== "mega_cluster" } : {}) }
          });
        }
      }
      return decisions;
    });
  }

  applyBuild(seat, decision) {
    // Revalidate the complete plan against the board at resolution, including its total price.
    const legal = this.legalBuildResolutions(seat).find(choice => choice.decisionId === decision.decisionId);
    if (!legal) throw new RangeError("This construction plan is no longer legal.");
    const player = this.players[seat];
    const p = legal.parameters;
    this.assignAgent(player, p);
    this.spendRunway(player, p.actualRunwayCost, { cause: "build", conversionEligible: true });
    player.compute -= p.project?.compute || 0;
    if (p.facility) {
      player.facilities.push({ id: `s${seat}-facility-${player.facilities.length + 1}`, tileId: p.destinationId, category: p.destinationCategory, powered: false });
      if (this.hasFactionAbility(player, "industrial_velocity")) this.recordFactionAbility(player, "industrial_velocity", { runwaySaved: 1 });
    }
    const project = p.project;
    if (project) { increment(player.metrics.projects, project.id); increment(this.matchMetrics.projects, project.id); }
    if (project?.id === "generator") {
      const source = this.config.powerSources.find(source => source.id === project.sourceId);
      player.generators.push({ id: `s${seat}-generator-${player.generators.length + 1}`, tileId: p.destinationId, sourceId: source.id });
      this.addResource(player, "trust", source.trust || 0);
      this.addScrutiny(player, source.scrutinyOnBuild || 0);
    } else if (project?.id === "mega_cluster") {
      const cluster = { id: `mega-${this.megaClusters.length + 1}`, leadSeat: seat, leftId: project.leftId, rightId: project.rightId, powered: false, builtEra: this.round };
      this.megaClusters.push(cluster); player.megaClusters.push(cluster);
      this.addScrutiny(player, 2);
    } else if (project?.id === "fusion_demonstrator") {
      player.generators.push({ id: `s${seat}-fusion`, tileId: p.destinationId, sourceId: project.id });
      this.fusionBuiltBy = seat; player.history.fusionBuilt = true;
      this.awardMandate(player, 2, project.id); this.addScrutiny(player, 3);
    }
    (player.metrics.construction ||= []).push({ era: this.round, facility: p.facility, project: project?.id || null });
    this.markAction(player, "build", legal.label);
    this.synchronizePublicMandate(player, "build");
    this.recordEligibility(player, "after_action");
  }

  areAdjacent(leftId, rightId) {
    const left = this.board.find((tile) => tile.instanceId === leftId);
    const right = this.board.find((tile) => tile.instanceId === rightId);
    return axialDistance(left, right) === 1;
  }

  hasAdjacentFacilities(left, right) {
    return left.facilities.some((a) =>
      right.facilities.some((b) => this.areAdjacent(a.tileId, b.tileId))
    );
  }

  canFormPartnership(left, right) {
    const range = left.factionId === "coalition_lab" && this.round >= 3 ? 2 : 1;
    return left.facilities.some((a) =>
      right.facilities.some((b) => {
        const leftTile = this.board.find((tile) => tile.instanceId === a.tileId);
        const rightTile = this.board.find((tile) => tile.instanceId === b.tileId);
        return axialDistance(leftTile, rightTile) <= range;
      })
    );
  }

  async negotiate(policies, seat, decision) {
    if (
      decision.parameters.mode === "joint_venture" &&
      !this.jointVentureSupplyAvailable()
    ) return false;
    const targetSeat = decision.parameters.targetSeat;
    const response = await this.choose(policies, targetSeat, "negotiation_response", [
      {
        decisionId: "agreement_accept",
        label: decisionLabel("agreementAccept"),
        actionId: "influence"
      },
      {
        decisionId: "agreement_reject",
        label: decisionLabel("agreementReject"),
        actionId: "influence"
      }
    ]);
    if (response.decisionId === "agreement_reject") return false;
    const player = this.players[seat];
    const target = this.players[targetSeat];
    const contract = {
      id: ++this.contractSerial,
      kind: decision.parameters.mode,
      createdRound: this.round,
      left: {
        seat,
        facilityId: decision.parameters.leftFacilityId
      },
      right: {
        seat: targetSeat,
        facilityId: decision.parameters.rightFacilityId
      },
      supplierSeat: decision.parameters.supplierSeat,
      buyerSeat: decision.parameters.buyerSeat
    };
    this.contracts.push(contract);
    if (decision.parameters.mode === "joint_venture") {
      player.jointVentures.push({ contractId: contract.id, partnerSeat: targetSeat, createdRound: this.round });
      target.jointVentures.push({ contractId: contract.id, partnerSeat: seat, createdRound: this.round });
      player.roundMetrics.jointVenturesCompleted += 1;
      target.roundMetrics.jointVenturesCompleted += 1;
      player.history.jointVenturePartners.push(targetSeat);
      target.history.jointVenturePartners.push(seat);
    }
    return true;
  }

  jointVentureSupplyAvailable() {
    return this.contracts.filter((contract) => contract.kind === "joint_venture").length <
      this.config.sharedSupply.jointVenturePairs;
  }

  terminateJointVenture(seat, contractId) {
    const index = this.contracts.findIndex((contract) =>
      contract.kind === "joint_venture" &&
      contract.id === contractId &&
      (contract.left.seat === seat || contract.right.seat === seat)
    );
    if (index < 0) return false;
    const [contract] = this.contracts.splice(index, 1);
    for (const participant of [contract.left.seat, contract.right.seat]) {
      this.players[participant].jointVentures = this.players[participant].jointVentures.filter(
        (venture) => venture.contractId !== contract.id
      );
    }
    return true;
  }

  applyResolution(seat, decision) {
    const player = this.players[seat];
    if (decision.consequences?.noOp) {
      this.assignAgent(player, decision.parameters || {});
      this.markAction(player, decision.actionId, decision.label);
      return;
    }
    if (decision.actionId === "build") return this.applyBuild(seat, decision);
    if (decision.actionId === "organize" && decision.parameters?.mode === "recruit") {
      this.spendRunway(player, decision.parameters.cost, {
        cause: "organize_recruit",
        conversionEligible: true
      });
      this.assignAgent(player, decision.parameters);
      for (let index = 0; index < decision.parameters.count; index += 1) {
        const usedNumbers = new Set(
          player.pieces
            .filter((piece) => piece.kind === "agent")
            .map((piece) => Number(piece.id.split("-").at(-1)))
        );
        const number = Array.from(
          { length: this.config.playerSupply.agents },
          (_, candidate) => candidate + 1
        ).find((candidate) => !usedNumbers.has(candidate));
        if (!number) throw new Error(`No Agent piece remains in seat ${seat}'s supply.`);
        player.pieces.push({
          id: `s${seat}-agent-${number}`,
          kind: "agent",
          tileId: decision.parameters.destinationId
        });
        player.agentsInSupply -= 1;
      }
      this.markAction(player, "organize", decision.label);
      return;
    }
    if (decision.actionId === "organize" && decision.parameters?.mode === "relocate") {
      this.assignAgent(player, decision.parameters);
      const facility = player.facilities.find(
        (candidate) => candidate.id === decision.parameters.facilityId
      );
      if (facility) {
        facility.tileId = decision.parameters.facilityDestinationId;
        facility.category = this.board.find(
          (tile) => tile.instanceId === facility.tileId
        )?.category;
      }
      this.markAction(player, "organize", decision.label);
      return;
    }

    if (decision.actionId === "influence" &&
      ["joint_venture", "terminate_joint_venture"].includes(decision.parameters?.mode)) {
      this.assignAgent(player, decision.parameters);
      const tile = this.board.find(
        (candidate) => candidate.instanceId === decision.parameters.destinationId
      );
      if (!tile) throw new Error("Influence resolution requires a board destination.");
      if (decision.parameters.mode === "terminate_joint_venture") {
        this.terminateJointVenture(player.seat, decision.parameters.contractId);
      }
      this.markAction(player, "influence", decision.label);
      return;
    }
    if (decision.actionId === "research" && !decision.parameters?.trainingResult) {
      decision = { ...decision, parameters: { ...decision.parameters,
        trainingResult: this.resolveTrainingRun(seat, player, decision.parameters || {}) } };
    }
    const before = { runway: player.runway, scrutiny: player.scrutiny };
    this.beginRunwayConversionContext(player, decision);
    super.applyResolution(seat, decision);
    if (decision.actionId === "fund") {
      const expected = decision.parameters.mode === "venture" ? 4 : 2;
      this.addResource(player, "runway", (decision.parameters.actualRunway ?? expected) - expected);
      player.roundMetrics.fundRunway += Math.max(0, player.runway - before.runway);
    }
    if (decision.actionId === "research") {
      player.compute += 1 - (decision.parameters.actualComputeCost ?? 1);
      if (player.lastTrainingResult?.protection === "scientific_method") {
        this.spendRunway(player, 1, { cause: "scientific_method", conversionEligible: true });
        this.recordFactionAbility(player, "scientific_method", { runwaySpent: 1, duplicatesProtected: 1, capabilityPreserved: player.lastTrainingResult.capability });
      }
      if (player.lastTrainingResult?.outcome === "crashed" && this.hasFactionAbility(player, "crash_retention")) {
        this.recordFactionAbility(player, "crash_retention", { capabilityPreserved: player.lastTrainingResult.capability });
      }
      player.roundMetrics.bestTrainingDomains = Math.max(player.roundMetrics.bestTrainingDomains, player.lastTrainingResult?.outcome === "crashed" ? 0 : player.lastTrainingResult?.ordinaryDomainCount || 0);
    }
    if (decision.actionId === "deploy") {
      player.roundMetrics.deployed = true;
      if (!player.history.deployRounds.includes(this.round)) player.history.deployRounds.push(this.round);
      if (this.hasFactionAbility(player, "installed_base")) {
        this.addResource(player, "runway", 1);
        this.recordFactionAbility(player, "installed_base", { runwayGained: 1 });
      }
    }
    if (player.scrutiny > before.scrutiny) player.roundMetrics.riskyActions += 1;
    this.synchronizePublicMandate(player, decision.actionId);
    this.endRunwayConversionContext(player);
  }

  async applyResolutionWithPolicies(policies, seat, selectedDecision) {
    const decision = clone(selectedDecision);
    if (decision.actionId === "research" && !decision.consequences?.noOp) {
      decision.parameters ||= {};
      this.assignAgent(this.players[seat], decision.parameters);
      decision.parameters.trainingResult = await this.resolveTrainingRunWithPolicies(
        policies,
        seat,
        decision.parameters
      );
    }
    this.applyResolution(seat, decision);
    await this.settlePendingScrutinyOverflow(policies, "action_scrutiny_overflow");
    return decision;
  }

  markAction(player, actionId, label) {
    player.actionsUsed.push(actionId);
    increment(player.metrics.actions, actionId);
    if (this.round === 1) player.metrics.openingActions.push(actionId);
    this.synchronizePublicMandate(player, actionId);
    this.recordEligibility(player, "after_action");
    this.recordEvent("action_resolved", player.seat, `${player.factionName}: ${label}.`);
    this.endRunwayConversionContext(player);
  }

  provisionalWinnerSeats() {
    const standings = this.players.map((player) => ({
      seat: player.seat,
      score: this.finalMandate(player).score,
      trust: player.trust,
      customers: player.customers,
      compute: player.compute
    })).sort((left, right) =>
      right.score - left.score ||
      right.trust - left.trust ||
      right.customers - left.customers ||
      right.compute - left.compute ||
      left.seat - right.seat
    );
    const best = standings[0];
    return standings.filter((entry) =>
      entry.score === best.score &&
      entry.trust === best.trust &&
      entry.customers === best.customers &&
      entry.compute === best.compute
    ).map((entry) => entry.seat);
  }

  declarationReadiness(player) {
    const rule = this.currentAgiRequirements();
    const values = { capability: player.capability,
      poweredFacilities: this.latestPoweredFacilities(player).length,
      trust: player.trust, compute: player.compute };
    const requirements = { capability: rule.capability, poweredFacilities: rule.poweredFacilities,
      trust: rule.trust, compute: rule.computeCost };
    const failingRequirement = Object.keys(requirements).find((key) => values[key] < requirements[key]) || null;
    return { ready: !failingRequirement, failingRequirement, values, requirements,
      recognized: Boolean(player.agiDeclared) };
  }

  isAgiEligible(player) {
    return this.declarationReadiness(player).ready;
  }

  recordEligibility(player, timing) {
    this.recordAgiCoreRequirements(player, timing);
    if (!player.metrics.earliestAgiEligibility && this.isAgiEligible(player)) {
      player.metrics.earliestAgiEligibility = {
        round: this.round,
        cycle: this.cycle,
        timing
      };
    }
  }

  async declareAgiAchievements(policies) {
    if (this.round !== 4) return;
    for (const seat of this.initiativeOrder()) {
      const player = this.players[seat];
      this.recordEligibility(player, "after_era_iv_production");
      const readiness = this.declarationReadiness(player);
      this.matchMetrics.declarationReadiness.push({ seat, round: this.round, cycle: this.cycle, ...readiness });
      if (!readiness.ready || player.agiDeclared) continue;
      this.markAgiFunnel(player, "legalDeclarationWindow", "after_era_iv_production", readiness);
      const rule = this.currentAgiRequirements();
      const choice = await this.choose(policies, seat, "agi_achievement", [
        { decisionId: "agi_pass", label: "Decline AGI recognition", actionId: "agi" },
        { decisionId: "agi_declare", label: `Pay ${rule.computeCost} Compute to declare recognized AGI: gain ${rule.mandate} Mandate and add ${rule.scrutiny} Scrutiny`, actionId: "agi",
          consequences: { compute: -rule.computeCost, mandate: rule.mandate, scrutiny: rule.scrutiny, agiDeclared: true } }
      ]);
      if (choice.decisionId !== "agi_declare") continue;
      player.compute -= rule.computeCost;
      player.agiDeclared = true;
      player.agiClaimed = true;
      player.history.declarations += 1;
      this.matchMetrics.declarations += 1;
      this.firstAgiSeat ??= seat;
      this.awardMandate(player, rule.mandate, "agi_recognition");
      this.addScrutiny(player, rule.scrutiny);
      for (const stage of ["claimRegistered", "emergenceTriggered", "declared"]) {
        this.markAgiFunnel(player, stage, "after_era_iv_production", { mandate: rule.mandate });
      }
      this.recordEvent("agi_declared", seat, `${player.factionName} paid for recognized AGI and gained ${rule.mandate} Mandate.`);
      markScenarioClaim(this, player);
      markScenarioDeclaration(this, player);
    }
  }

  resolveAgiOutcome() {
    const claimantSeats = this.players.filter((player) => player.agiDeclared).map((player) => player.seat);
    this.matchMetrics.agiResolution = { method: "scored-achievement", claimantSeats,
      recognized: claimantSeats.length > 0, emerged: claimantSeats.length > 0,
      winnerOverridden: false };
  }

  infrastructureState(player) {
    const locallyEligible = locallyEligibleFacilityIds(this.board, {
      ...player,
      startingGridConnection: {
        assignedFacilityId: player.facilities[0]?.id || null
      }
    });
    const connectedGenerators = player.generators.filter((generator) => {
      const generatorTile = this.board.find((tile) => tile.instanceId === generator.tileId);
      return player.facilities.some((facility) => {
        if (!locallyEligible.has(facility.id)) return false;
        const facilityTile = this.board.find((tile) => tile.instanceId === facility.tileId);
        return generatorTile && facilityTile && axialDistance(generatorTile, facilityTile) <= 1;
      });
    });
    return { locallyEligible, connectedGenerators };
  }

  megaClusterLocallyEligible(player, facilityIds) {
    if (facilityIds.length !== 2 || new Set(facilityIds).size !== 2) return false;
    const hosts = facilityIds.map((id) => player.facilities.find((facility) => facility.id === id));
    const connected = this.infrastructureState(player).locallyEligible;
    return hosts.every(Boolean) && hosts.every((host) => connected.has(host.id)) &&
      this.areAdjacent(hosts[0].tileId, hosts[1].tileId);
  }

  megaClusterHostsAvailable(facilityIds) {
    const requested = new Set(facilityIds);
    if (requested.size !== facilityIds.length) return false;
    return this.megaClusters.every((cluster) =>
      !requested.has(cluster.leftId) && !requested.has(cluster.rightId)
    );
  }

  megaClusterDecisionLocallyEligible(seat, parameters = {}) {
    const player = this.players[seat];
    if (!player || !parameters.leftId || !parameters.rightId) return false;
    if (!this.megaClusterHostsAvailable([parameters.leftId, parameters.rightId])) {
      return false;
    }
    return this.megaClusterLocallyEligible(player, [parameters.leftId, parameters.rightId]);
  }

  facilityContractResource(facility) {
    const tile = this.board.find((candidate) => candidate.instanceId === facility.tileId);
    if (!tile) return null;
    if (["research", "cloud", "chip"].includes(tile.category)) return "compute";
    if (tile.id === "grid_reactor") return "compute";
    if (["consumer", "capital", "talent", "media", "government"].includes(tile.category)) {
      return "runway";
    }
    if (tile.id === "renewable_basin") return "runway";
    return null;
  }

  async produceFacility(policies, player, facility, stage = "facility_production") {
    const countsForProduction = stage === "facility_production";
    if (facility.category === "cloud") {
      this.addResource(player, "compute", 2);
      if (countsForProduction) player.roundMetrics.computeProduced += 2;
    } else if (facility.category === "research") {
      this.addResource(player, "compute", 1);
      if (countsForProduction) player.roundMetrics.computeProduced += 1;
    } else if (facility.category === "consumer") {
      this.addResource(player, "runway", 1);
    } else if (facility.category === "chip") {
      this.addResource(player, "compute", 1);
      this.addResource(player, "runway", 1);
      if (countsForProduction) player.roundMetrics.computeProduced += 1;
    } else if (facility.category === "capital") {
      this.addResource(player, "runway", 2);
    } else if (facility.category === "talent") {
      const choices = this.assignmentVariants(player, (piece, destination) => [{
        decisionId: `talent_assign_${facility.id}_${piece.id}_${destination.instanceId}`,
        label: decisionLabel("talentAssignAgent", { agent: piece.id, destination: destination.name }),
        actionId: "talent_assignment",
        parameters: { pieceId: piece.id, destinationId: destination.instanceId,
          destinationCategory: destination.category }
      }]);
      const choice = await this.choose(policies, player.seat, "talent_assignment", choices);
      this.assignAgent(player, choice.parameters);
      this.recordEvent("talent_assignment", player.seat, choice.label);
    } else if (facility.category === "media") {
      this.removeScrutiny(player, 1);
    } else if (facility.category === "government") {
      this.addResource(player, "trust", 1);
    } else if (facility.category === "energy") {
      const tile = this.board.find((candidate) => candidate.instanceId === facility.tileId);
      if (tile?.id === "grid_reactor") {
        this.addResource(player, "compute", 1);
        if (countsForProduction) player.roundMetrics.computeProduced += 1;
      } else {
        this.removeScrutiny(player, 1);
      }
    }
    if (facility.customSilicon) {
      this.addResource(player, "compute", 1);
      if (countsForProduction) player.roundMetrics.computeProduced += 1;
    }
  }

  async produceAll(policies) {
    for (const player of this.players) {
      if (!this.hasFactionAbility(player, "the_shovels")) continue;
      const income = Math.min(2, this.players.filter(rival => rival.seat !== player.seat && rival.facilities.length > 0).length);
      const before = player.runway;
      this.addResource(player, "runway", income);
      player.metrics.shovelsIncome += player.runway - before;
      this.recordFactionAbility(player, "the_shovels", { runwayGained: player.runway - before });
    }
    const infrastructure = this.players.map((player) => this.infrastructureState(player));
    for (const player of this.players) {
      const state = infrastructure[player.seat];
      for (const generator of state.connectedGenerators) {
        const source = this.config.powerSources.find((candidate) => candidate.id === generator.sourceId);
        increment(player.metrics.generatorChoices, generator.sourceId);
        if (source?.scrutinyPerUse) {
          this.addScrutiny(player, source.scrutinyPerUse);
          increment(player.metrics.generatorScrutiny, source.id, source.scrutinyPerUse);
        }
      }
      for (const facility of player.facilities) facility.powered = state.locallyEligible.has(facility.id);
      player.roundMetrics.poweredProjectIds = this.megaClusters.filter((cluster) =>
        cluster.leadSeat === player.seat && this.megaClusterLocallyEligible(player, [cluster.leftId, cluster.rightId])
      ).map((cluster) => cluster.id);
    }
    await this.settlePendingScrutinyOverflow(policies, "production_generator_scrutiny_overflow");

    for (const cluster of this.megaClusters) {
      const lead = this.players[cluster.leadSeat];
      const left = lead.facilities.find((facility) => facility.id === cluster.leftId);
      const right = lead.facilities.find((facility) => facility.id === cluster.rightId);
      const leadCommitted = lead.roundMetrics.poweredProjectIds?.includes(cluster.id);
      cluster.powered = Boolean(
        left && right && left.powered && right.powered &&
        this.areAdjacent(left.tileId, right.tileId) &&
        leadCommitted
      );
    }

    // Produce box: Facilities for every player, then Customer income, then
    // active Mega-Clusters. Initiative orders each sub-step.
    for (const seat of this.initiativeOrder()) {
      const player = this.players[seat];
      for (const facility of player.facilities.filter((candidate) => candidate.powered)) {
        await this.produceFacility(policies, player, facility);
      }
    }

    for (const seat of this.initiativeOrder()) {
      const player = this.players[seat];
      let customerIncome = Math.max(
        0,
        player.customers - (player.roundMetrics.discountedCustomerNoIncome || 0)
      );

      this.addResource(player, "runway", customerIncome);
    }

    const initiativeRank = new Map(
      this.initiativeOrder().map((seat, index) => [seat, index])
    );
    for (const cluster of [...this.megaClusters].sort((left, right) =>
      initiativeRank.get(left.leadSeat) - initiativeRank.get(right.leadSeat) ||
      left.id.localeCompare(right.id)
    )) {
      if (!cluster.powered) continue;
      const lead = this.players[cluster.leadSeat];
      const computeBefore = lead.compute;
      this.addResource(lead, "compute", 3);
      lead.roundMetrics.computeProduced += 3;
      this.matchMetrics.projectProduction.push({
        round: this.round, seat: lead.seat, projectId: cluster.id,
        project: "mega_cluster", nominalCompute: 3,
        gainedCompute: lead.compute - computeBefore
      });
    }

    // Partner box: Joint Ventures always resolve after all Produce sub-steps.
    for (const contract of this.contracts
      .filter((candidate) => candidate.kind === "joint_venture")
      .sort((left, right) => left.id - right.id)) {
      const leftPlayer = this.players[contract.left.seat];
      const rightPlayer = this.players[contract.right.seat];
      const left = leftPlayer.facilities.find(
        (facility) => facility.id === contract.left.facilityId
      );
      const right = rightPlayer.facilities.find(
        (facility) => facility.id === contract.right.facilityId
      );
      const range = 1;
      if (!left?.powered || !right?.powered) continue;
      const leftTile = this.board.find((tile) => tile.instanceId === left.tileId);
      const rightTile = this.board.find((tile) => tile.instanceId === right.tileId);
      if (axialDistance(leftTile, rightTile) > range) continue;
      const leftResource = this.facilityContractResource(right);
      const rightResource = this.facilityContractResource(left);
      if (leftResource) {
        this.addResource(leftPlayer, leftResource, 1);
        if (leftResource === "compute") leftPlayer.roundMetrics.computeProduced += 1;
      }
      if (rightResource) {
        this.addResource(rightPlayer, rightResource, 1);
        if (rightResource === "compute") rightPlayer.roundMetrics.computeProduced += 1;
      }
      if (contract.createdRound === this.round) {
        leftPlayer.roundMetrics.activeNewJointVentures =
          (leftPlayer.roundMetrics.activeNewJointVentures || 0) + 1;
        rightPlayer.roundMetrics.activeNewJointVentures =
          (rightPlayer.roundMetrics.activeNewJointVentures || 0) + 1;
      }
    }

    await this.settlePendingScrutinyOverflow(
      policies,
      "production_scrutiny_overflow"
    );

    for (const player of this.players) {
      const poweredFacilityIds = player.facilities
        .filter((facility) => facility.powered)
        .map((facility) => facility.id);
      const powered = poweredFacilityIds.length;
      player.latestProductionSnapshot = {
        round: this.round,
        poweredFacilityIds,
        offlineFacilityIds: player.facilities
          .filter((facility) => !poweredFacilityIds.includes(facility.id))
          .map((facility) => facility.id),
        source: "current-board-connections"
      };
      player.metrics.poweredFacilityRounds.push({
        round: this.round,
        powered,
        facilities: player.facilities.length,
        locallyEligible: infrastructure[player.seat].locallyEligible.size
      });
      this.recordEligibility(player, "after_production");
    }
    const platform = this.players.find((player) => player.factionId === "platform_empire");
    const leader = Math.max(...this.players.map((player) => this.currentScore(player)));
    this.matchMetrics.productionSnapshots.push({
      round: this.round,
      scores: this.players.map((player) => ({
        seat: player.seat,
        factionId: player.factionId,
        mandate: this.currentScore(player),
        poweredFacilities: player.latestProductionSnapshot.poweredFacilityIds.length
      })),
      platformLead: platform ? this.currentScore(platform) - leader : null,
      gridGeneratorSlotsFilled: this.generatorOccupancy(
        this.board.find((tile) => tile.id === "grid_reactor").instanceId
      )
    });
  }

  facilityComponents(player) {
    const remaining = new Set(player.facilities.map((facility) => facility.id));
    const result = [];
    while (remaining.size) {
      const first = remaining.values().next().value;
      remaining.delete(first);
      const component = [first];
      const queue = [first];
      while (queue.length) {
        const currentId = queue.shift();
        const current = player.facilities.find((facility) => facility.id === currentId);
        for (const candidate of player.facilities) {
          if (remaining.has(candidate.id) && this.areAdjacent(current.tileId, candidate.tileId)) {
            remaining.delete(candidate.id);
            component.push(candidate.id);
            queue.push(candidate.id);
          }
        }
      }
      result.push(component);
    }
    return result;
  }

  applyAutomaticPenalty(player, cause) {
    if (player.runway > 0) this.spendRunway(player, 1, { cause });
    else if (player.trust > 0) this.addResource(player, "trust", -1);
  }

  async audit(policies) {
    const base = this.config.rounds[this.round - 1].auditBaseDraws;
    const draws = Math.max(
      1,
      Math.round(base * this.playerCount / 4 * this.rulesVariant.auditMultiplier)
    );
    const rng = createRng(`${this.seed}:audit:${this.round}`);
    for (let draw = 0; draw < draws; draw += 1) {
      const bag = [
        ...this.players.flatMap((player) =>
          Array.from({ length: player.scrutiny }, () => ({ type: "player", seat: player.seat }))
        ),
        ...Array.from({ length: this.systemicRisk }, () => ({ type: "systemic" }))
      ];
      if (!bag.length) break;
      const selected = bag[Math.floor(rng() * bag.length)];
      if (selected.type === "systemic") {
        this.systemicRisk -= 1;
        for (const seat of this.initiativeOrder()) {
          const player = this.players[seat];
          if (player.customers < 3) continue;
          this.applyAutomaticPenalty(player, "systemic_audit");
          player.metrics.systemicRiskHits += 1;
        }
      } else {
        const player = this.players[selected.seat];
        player.scrutiny -= 1;
        player.metrics.auditHits += 1;
        this.applyAutomaticPenalty(player, "player_audit");
      }
    }
  }

  scoreMandate() {
    const id = this.roundMandate.id;
    const values = this.players.map((player) => {
      if (id === "quarter_humanity_notices") return player.capability - player.roundMetrics.capabilityStart;
      if (id === "continent_signs_loi") return player.customers - player.roundMetrics.customersStart;
      if (id === "building_has_weather") return this.latestPoweredFacilities(player).length;
      if (id === "stack_reaches_horizon") return this.latestPoweredFacilities(player).length + player.megaClusters.filter(cluster => this.megaClusterLocallyEligible(player, [cluster.leftId, cluster.rightId])).length;
      if (id === "voluntary_coordination_triumphs") return player.roundMetrics.activeNewJointVentures || 0;
      if (id === "legibility_offensive") return player.roundMetrics.deployed ? player.trust : -1;
      if (id === "national_champion_without_nationalization") return this.controlledCategories(player).size;
      if (id === "model_ate_tuesday") return player.roundMetrics.bestTrainingDomains;
      if (id === "compute_new_weather") return player.roundMetrics.computeProduced;
      if (id === "zero_incident_quarter") {
        const added = player.metrics.scrutinyAdded - player.roundMetrics.scrutinyStart;
        return -added;
      }
      if (id === "responsible_acceleration") return player.trust >= 4 ? player.capability : -1;
      if (id === "markets_prefer_destiny") return player.roundMetrics.fundRunway;
      return 0;
    });
    const minimum = this.roundMandate.minimumQualification ?? 1;
    const qualificationValues = id === "zero_incident_quarter"
      ? this.players.map((player) =>
        player.metrics.scrutinyAdded - player.roundMetrics.scrutinyStart
      )
      : values;
    const qualifiedValues = values.map((value, index) =>
      qualificationValues[index] >= minimum ? value : -Infinity
    );
    const maximum = Math.max(...qualifiedValues);
    increment(this.matchMetrics.mandates, id);
    if (!Number.isFinite(maximum)) return;
    const winners = qualifiedValues.map((value, seat) => value === maximum ? seat : null)
      .filter((seat) => seat !== null);
    for (const seat of winners) {
      const points = winners.length === 1 ? this.mandateDocument.points.winner : this.mandateDocument.points.tied;
      this.awardMandate(this.players[seat], points, `round_mandate:${id}`);
      this.players[seat].metrics.mandatesWon[id] = points;
    }
  }

  objectiveComplete(player) {
    const id = player.objectiveId;
    const powered = this.latestPoweredFacilities(player).length;
    if (id === "quietly_indispensable") return powered >= 2 && player.scrutiny <= 4;
    if (id === "too_big_to_pause") return player.customers >= 3 && player.trust <= 3;
    if (id === "benevolent_monopoly") return player.customers >= 3 && player.trust >= 4;
    if (id === "institutional_capture") {
      return ["media", "government", "capital"]
        .filter((category) => this.controller(category) === player.seat).length >= 2;
    }
    if (id === "distributed_scarcity") {
      return this.facilityComponents(player).some((component) => component.length >= 2) &&
        player.generators.length >= 1;
    }
    if (id === "paper_agi") return player.agiDeclared && player.facilities.length === 2;
    if (id === "industrial_sublime") {
      return player.facilities.length >= 3 && player.generators.length >= 1;
    }
    if (id === "public_option_private_invoice") {
      return [this.controller("government"), this.controller("capital")].includes(player.seat) &&
        player.runway >= 6;
    }
    if (id === "open_closed_loop") {
      if (!player.history.openWeightsCapabilitySnapshot) return false;
      return this.players.every((candidate) =>
        candidate.seat === player.seat ||
        player.history.openWeightsCapabilitySnapshot[candidate.seat] >=
          player.history.openWeightsCapabilitySnapshot[player.seat] ||
        player.capability > candidate.capability
      );
    }
    if (id === "alignment_as_service") return player.trust >= 4 && player.jointVentures.length > 0;
    if (id === "everyone_customer") return player.history.deployRounds.length >= 2;
    if (id === "regulatory_moat") {
      return player.trust >= 4 && this.controller("government") === player.seat;
    }
    if (id === "recursive_revenue") {
      return player.customers > 0 && player.facilities.length > 0 &&
        player.jointVentures.length > 0;
    }
    if (id === "credible_denial") return player.capability >= 8 && player.customers <= 1;
    if (id === "history_will_call") return player.history.cumulativeScrutiny >= 6 && player.trust >= 4;
    if (id === "fusion_press_cycle") return player.history.fusionBuilt && player.agiDeclared;
    return false;
  }

  tradableResources(player, receiver, excluded = null) {
    return ["runway", "compute"].filter((resource) =>
      resource !== excluded &&
      player[resource] > 0 &&
      receiver[resource] < (
        this.factionResourceCap(receiver, resource)
      )
    );
  }

  selectedActionResolutions(seat) {
    const player = this.players[seat];
    if (!player.selectedAction) return [];
    return this.legalResolutions(seat, player.selectedAction);
  }

  immediateTradeGiveAmounts(seat, partner, resource) {
    const player = this.players[seat];
    const partnerCap = this.factionResourceCap(partner, resource);
    const maximumGive = Math.min(player[resource], partnerCap - partner[resource]);
    return maximumGive >= 1 ? [1] : [];
  }

  immediateTradeReceiveAmounts(seat, partner, resource) {
    const player = this.players[seat];
    const playerCap = this.factionResourceCap(player, resource);
    const maximumReceive = Math.min(partner[resource], playerCap - player[resource]);
    return maximumReceive >= 1 ? [1] : [];
  }

  dealFlowEligibleTrade(offer) {
    return offer.giveResource !== offer.receiveResource;
  }

  provisionalTradeResolvesSelection(seat, offer, actionId) {
    const player = this.players[seat];
    const partner = this.players[offer.partnerSeat];
    const snapshots = [player, partner].map((participant) => ({
      participant,
      runway: participant.runway,
      compute: participant.compute
    }));
    player[offer.giveResource] -= offer.giveAmount;
    partner[offer.giveResource] += offer.giveAmount;
    partner[offer.receiveResource] -= offer.receiveAmount;
    player[offer.receiveResource] += offer.receiveAmount;
    if (
      this.dealFlowEligibleTrade(offer) &&
      player.factionId === "coalition_lab" &&
      !this.isFactionAbilityPaused(player, "deal_flow")
    ) {
      player.runway = Math.min(
        this.config.resources.runway.cap,
        player.runway + 1
      );
    }
    const resolves = this.selectionResolutionCount(
      seat,
      actionId
    ) > 0;
    for (const snapshot of snapshots) {
      snapshot.participant.runway = snapshot.runway;
      snapshot.participant.compute = snapshot.compute;
    }
    return resolves;
  }

  immediateTradeOffers(seat, timing) {
    const player = this.players[seat];
    const offers = [];
    for (const partner of this.players.filter((candidate) => candidate.seat !== seat)) {
      const giveResources = this.tradableResources(player, partner).filter(
        (resource) => this.immediateTradeGiveAmounts(seat, partner, resource).length > 0
      );
      for (const giveResource of giveResources) {
        for (const giveAmount of this.immediateTradeGiveAmounts(seat, partner, giveResource)) {
          const receiveResources = this.tradableResources(partner, player).filter(
            (resource) => this.immediateTradeReceiveAmounts(seat, partner, resource).length > 0
          );
          for (const receiveResource of receiveResources) {
            if (receiveResource === giveResource) continue;
            for (const receiveAmount of this.immediateTradeReceiveAmounts(
              seat,
              partner,
              receiveResource
            )) {
              offers.push({
                timing,
                partnerSeat: partner.seat,
                targetSeat: partner.seat,
                giveResource,
                giveAmount,
                receiveResource,
                receiveAmount
              });
            }
          }
        }
      }
    }
    return offers;
  }

  canResolveSelectionAfterImmediateTrade(seat, actionId, options = {}) {
    return this.immediateTradeOffers(seat, "before").some((offer) =>
      this.provisionalTradeResolvesSelection(seat, offer, actionId, options)
    );
  }

  immediateTradeDecisions(seat, timing = "before") {
    if (timing !== "before") {
      throw new RangeError("Immediate trades occur only before action resolution.");
    }
    const player = this.players[seat];
    const selectedAction = player.selectedAction;
    const selectedActionId = selectedAction;
    const selectedCurrentlyResolvable = selectedAction
      ? this.selectedActionResolutions(seat).length > 0
      : true;
    const offers = this.immediateTradeOffers(seat, timing).filter((offer) =>
      !selectedActionId ||
      this.provisionalTradeResolvesSelection(seat, offer, selectedActionId)
    );
    const decisions = [{
      decisionId: "trade_none",
      label: decisionLabel("tradeNone"),
      actionId: "trade",
      consequences: {
        timing,
        selectedActionCurrentlyResolvable: selectedCurrentlyResolvable
      }
    }];
    for (const offer of offers) {
      decisions.push({
        decisionId: [
          "trade_offer",
          timing,
          offer.partnerSeat,
          offer.giveResource,
          offer.giveAmount,
          offer.receiveResource,
          offer.receiveAmount
        ].join("_"),
        label: decisionLabel("tradeOffer", {
          timing: decisionLabel("tradeTimingBefore"),
          giveAmount: offer.giveAmount,
          giveResource: offer.giveResource,
          partner: this.players[offer.partnerSeat].factionName,
          receiveAmount: offer.receiveAmount,
          receiveResource: offer.receiveResource
        }),
        actionId: "trade",
        parameters: offer,
        consequences: {
          timing,
          enablesSelectedAction: !selectedCurrentlyResolvable
        }
      });
    }
    return decisions;
  }

  async chooseImmediateTrade(policies, seat, timing) {
    const decisions = this.immediateTradeDecisions(seat, timing);
    if (decisions.length === 1) return null;
    const choice = await this.choose(
      policies,
      seat,
      `immediate_trade_${timing}`,
      decisions
    );
    return choice.parameters?.partnerSeat === undefined ? null : choice.parameters;
  }

  canCompleteImmediateTrade(seat, partnerSeat, offer) {
    const partner = this.players[partnerSeat];
    const allowedResources = new Set(["runway", "compute"]);
    if (
      !partner ||
      offer?.timing !== "before" ||
      !allowedResources.has(offer.giveResource) ||
      !allowedResources.has(offer.receiveResource) ||
      offer.giveResource === offer.receiveResource ||
      offer.giveAmount !== 1 ||
      offer.receiveAmount !== 1
    ) return false;
    const resourcesAvailable = this.immediateTradeGiveAmounts(
      seat,
      partner,
      offer.giveResource
    ).includes(
      offer.giveAmount
    ) && this.immediateTradeReceiveAmounts(seat, partner, offer.receiveResource).includes(
      offer.receiveAmount
    );
    if (!resourcesAvailable) return false;
    const selectedAction = this.players[seat].selectedAction;
    if (!selectedAction) return resourcesAvailable;
    return this.provisionalTradeResolvesSelection(seat, offer, selectedAction);
  }

  completeImmediateTrade(seat, partnerSeat, offer) {
    const player = this.players[seat];
    const partner = this.players[partnerSeat];
    if (!this.canCompleteImmediateTrade(seat, partnerSeat, offer)) return false;
    if (offer.giveResource === "runway") {
      this.spendRunway(player, offer.giveAmount, { cause: "immediate_trade_payment" });
    } else {
      player[offer.giveResource] -= offer.giveAmount;
    }
    if (offer.receiveResource === "runway") {
      this.spendRunway(partner, offer.receiveAmount, {
        cause: "immediate_trade_payment"
      });
    } else {
      partner[offer.receiveResource] -= offer.receiveAmount;
    }
    this.addResource(partner, offer.giveResource, offer.giveAmount);
    this.addResource(player, offer.receiveResource, offer.receiveAmount);
    for (const participant of [player]) {
      if (
        this.dealFlowEligibleTrade(offer) &&
        participant.factionId === "coalition_lab" &&
        !this.isFactionAbilityPaused(participant, "deal_flow")
      ) {
        const runwayGained = this.grantDealFlowRunway(participant, {
          tradeMakerSeat: seat,
          partnerSeat
        });
        this.recordFactionAbility(participant, "deal_flow", {
          runwayGained,
          creditsGranted: runwayGained,
          completedTrades: 1
        });
      }
    }
    this.recordEvent(
      "immediate_trade",
      seat,
      `${player.factionName} traded ${offer.giveAmount} ${offer.giveResource} to ` +
        `${partner.factionName} for ${offer.receiveAmount} ${offer.receiveResource}.`
    );
    return true;
  }

  async settleImmediateTrade(policies, seat, offer) {
    if (!offer) return false;
    this.activeImmediateTradeSeat = seat;
    const partner = this.players[offer.partnerSeat];
    const response = await this.choose(policies, partner.seat, "immediate_trade_response", [
      {
        decisionId: "trade_reject",
        label: decisionLabel("tradeReject", offer),
        actionId: "trade",
        parameters: {
          ...offer,
          partnerSeat: seat,
          targetSeat: seat,
          tradePerspective: "responder"
        }
      },
      {
        decisionId: "trade_accept",
        label: decisionLabel("tradeAccept", offer),
        actionId: "trade",
        parameters: {
          ...offer,
          partnerSeat: seat,
          targetSeat: seat,
          tradePerspective: "responder"
        }
      }
    ]);
    if (response.decisionId === "trade_accept") {
      return this.completeImmediateTrade(seat, partner.seat, offer);
    }
    return false;
  }

  assignmentOnlyDecisions(player, actionId) {
    return this.assignmentVariants(player, (piece, district) => [{
      decisionId: `assign_only_${actionId}_${piece.id}_${district.instanceId}`,
      label: `Assign ${piece.id} to ${district.name}; ${actionId} has no legal effect and exhausts`,
      actionId, parameters: { pieceId: piece.id, destinationId: district.instanceId,
        destinationCategory: district.category }, consequences: { noOp: true }
    }]);
  }

  async resolveSelectedSeat(policies, seat) {
    const player = this.players[seat];
    const beforeTrade = await this.chooseImmediateTrade(policies, seat, "before");
    const beforeTradeAccepted = beforeTrade
      ? await this.settleImmediateTrade(policies, seat, beforeTrade)
      : false;
    void beforeTradeAccepted;
    let legal = this.legalResolutions(seat, player.selectedAction);
    if (!legal.length) {
      player.metrics.forcedNoOps += 1;
      player.metrics.blockedAfterCommitment += 1;
      legal = this.assignmentOnlyDecisions(player, player.selectedAction);
    }
    let decision = await this.choose(policies, seat, "resolve", legal);
    decision = await this.maybePlayTacticForResolution(policies, seat, decision);
    if (decision.parameters?.mode === "joint_venture") {
      await this.negotiate(policies, seat, decision);
    }
    const computeBeforeAction = player.compute;
    await this.applyResolutionWithPolicies(policies, seat, decision);
    await this.resolveFrontierBridge(policies, seat, decision);
    player.selectedAction = null;
  }

  async resolveFrontierBridge(policies, seat, decision) {
    const destination = this.board.find(
      (tile) => tile.instanceId === decision.parameters?.destinationId
    );
    if (destination?.category !== "frontier") return;
    const choice = await this.choose(policies, seat, "frontier_bridge", [
      {
        decisionId: "frontier_bridge_pass",
        label: decisionLabel("frontierBridgeDecline"),
        actionId: "frontier"
      },
      {
        decisionId: "frontier_bridge_take",
        label: decisionLabel("frontierBridgeAccept"),
        actionId: "frontier",
        consequences: { runway: 1, scrutiny: 1 }
      }
    ]);
    if (choice.decisionId === "frontier_bridge_take") {
      this.addResource(this.players[seat], "runway", 1);
      this.addScrutiny(this.players[seat], 1);
    }
  }

  async finishSelectedRound(policies) {
    await this.produceAll(policies);
    applyAgiDeclarationScenario(this);
    await this.declareAgiAchievements(policies);
    await this.settlePendingScrutinyOverflow(policies, "agi_scrutiny_overflow");
    await this.audit(policies);
    this.scoreMandate();

    if (this.round === this.config.rounds.at(-1).number) {
      this.resolveAgiOutcome();
    }
    this.recordEvent(
      "round_settled",
      null,
      renderSimulationCopy(simulationCopy.events.selectedRoundSettled, { round: this.round })
    );
    this.reportProgress("round");
    if (this.round === this.config.rounds.at(-1).number) {
      this.complete = true;
      return;
    }
    this.round += 1;
    this.cycle = 1;
    this.roundInitialized = false;
    await this.beginRound(policies);
  }

  async playCycle(policies) {
    if (!this.roundInitialized) await this.beginRound(policies);
    await this.prepareHeadline(policies);
    await this.settlePendingScrutinyOverflow(policies, "headline_scrutiny_overflow");
    await this.settlePendingScrutinyOverflow(policies, "headline_choice_scrutiny_overflow");
    await this.settlePendingScrutinyOverflow(policies, "faction_scrutiny_overflow");

    const selectionPackets = this.players.map((player) =>
      this.packet(player.seat, "select", this.legalActionSelections(player.seat))
    );
    const results = await Promise.all(
      selectionPackets.map((packet, seat) => policies[seat].decide(packet))
    );
    const selections = [];
    for (const [seat, result] of results.entries()) {
      const player = this.players[seat];
      this.recordPolicyReceipt(player, result.receipt);
      const legal = selectionPackets[seat].legalDecisions.find(
        (decision) => decision.decisionId === result.decision.decisionId
      );
      player.selectedAction = legal.decisionId.replace(/^select_/, "");
      player.metrics.selectionAvailability.resolvableNow += 1;
      selections[seat] = player.selectedAction;
      this.recordEvent(
        "action_selected",
        seat,
        renderSimulationCopy(simulationCopy.events.actionSelected, {
          faction: player.factionName,
          action: player.selectedAction
        }),
        result.receipt
      );
    }

    for (const [turnInCycle, seat] of this.initiativeOrder().entries()) {
      await this.resolveSelectedSeat(policies, seat);
      await this.settlePendingScrutinyOverflow(policies, "turn_scrutiny_overflow");
      this.reportProgress("turn", {
        completedSeat: seat,
        turnNumber: (this.config.rounds
          .filter((round) => round.number < this.round)
          .reduce((total, round) => total + round.cycles, 0) * this.playerCount) +
          ((this.cycle - 1) * this.playerCount) + turnInCycle + 1
      });
    }
    this.reportProgress("cycle", {
      cycleNumber: this.config.rounds
        .filter((round) => round.number < this.round)
        .reduce((total, round) => total + round.cycles, this.cycle)
    });
    this.initiativeSeat = (this.initiativeSeat + 1) % this.playerCount;
    const cycleLimit = this.config.rounds.find((round) => round.number === this.round).cycles;
    if (this.cycle === cycleLimit) await this.finishSelectedRound(policies);
    else this.cycle += 1;
  }

  async play(policies) {
    throwIfAborted(this.signal);
    await this.setup(policies);
    while (!this.complete) {
      throwIfAborted(this.signal);
      await this.playCycle(policies);
    }
    return this.result();
  }

  reportProgress(kind, details = {}) {
    if (!this.onProgress) return;
    const standings = this.players.map((player) => ({
      seat: player.seat,
      factionName: player.factionName,
      profileId: player.profileId,
      backendId: player.backendId,
      model: player.model,
      reasoningEffort: player.reasoningEffort,
      score: this.currentScore(player),
      trust: player.trust,
      customers: player.customers,
      compute: player.compute,
      capability: player.capability,
      facilities: player.facilities.length,
      agiDeclared: player.agiDeclared
    })).sort((left, right) =>
      right.score - left.score ||
      right.trust - left.trust ||
      right.customers - left.customers ||
      right.compute - left.compute ||
      left.seat - right.seat
    );
    this.onProgress({
      kind,
      round: this.round,
      cycle: this.cycle,
      ...details,
      projectedWinnerSeat: standings[0]?.seat ?? null,
      standings
    });
  }

  refreshConnections() {
    for (const player of this.players) {
      const connected = this.infrastructureState(player).locallyEligible;
      for (const facility of player.facilities) facility.powered = connected.has(facility.id);
    }
  }

  snapshot() {
    this.refreshConnections();
    const base = super.snapshot();
    if (!this.rulesVariant) return base;
    return {
      ...base,
      activeHeadline: this.activeHeadline
        ? {
          id: this.activeHeadline.id,
          name: this.activeHeadline.name,
          newswire: this.activeHeadline.newswire,
          text: this.activeHeadline.text,
          quote: this.activeHeadline.quote
        }
        : null,
      roundMandate: this.roundMandate?.id || null,
      fusionBuiltBy: this.fusionBuiltBy,
      systemicRisk: this.systemicRisk,
      players: base.players.map((snapshot, seat) => {
        const player = this.players[seat];
        return {
          ...snapshot,
          tactics: [...(player.tactics || [])],
          objectiveId: player.objectiveId,
          jointVentures: clone(player.jointVentures || []),
          megaClusters: clone(player.megaClusters || []),
          agiDeclared: player.agiDeclared,
          agiClaimed: player.agiClaimed,
          agiReadiness: this.declarationReadiness(player),
          latestProductionSnapshot: clone(player.latestProductionSnapshot),
          currentScore: this.currentScore(player)
        };
      })
    };
  }

  result() {
    finalizeAgiDeclarationScenario(this);
    for (const player of this.players) {
      this.recordAgiCoreRequirements(player, "match_complete");
      player.metrics.dealFlowConversion.unspentCredits =
        player.dealFlowRunwayCredits.reduce(
          (sum, credit) => sum + credit.remaining,
          0
        );
    }
    const standings = this.players.map((player) => {
      const {
        score,
        poweredFacilityMandate,
        offlinePenalty
      } = this.finalMandate(player);
      return {
        seat: player.seat,
        factionId: player.factionId,
        factionName: player.factionName,
        profileId: player.profileId,
        backendId: player.backendId,
        model: player.model,
        reasoningEffort: player.reasoningEffort,
        score,
        trust: player.trust,
        customers: player.customers,
        compute: player.compute,
        capability: player.capability,
        facilities: player.facilities.length,
        poweredFacilityMandate,
        offlinePenalty,
        agiDeclared: player.agiDeclared,
        agiClaimed: player.agiClaimed,
        agiReadiness: this.declarationReadiness(player),
        metrics: clone(player.metrics)
      };
    }).sort((left, right) =>
      right.score - left.score ||
      right.trust - left.trust ||
      right.customers - left.customers ||
      right.compute - left.compute ||
      left.seat - right.seat
    );
    const best = standings[0];
    const winnerSeats = standings.filter((entry) =>
        entry.score === best.score &&
        entry.trust === best.trust &&
        entry.customers === best.customers &&
        entry.compute === best.compute
      ).map((entry) => entry.seat)
;
    const setupCollectiveTrust = this.players.reduce(
      (sum, player) => sum + Number(
        this.factions.find((faction) => faction.id === player.factionId)?.starts.trust || 0
      ),
      0
    );
    const collectiveTrust = this.players.reduce((sum, player) => sum + player.trust, 0);
    const qualifyingDeclarers = this.players.filter(
      (player) => player.agiDeclared
    ).length;
    const agiEmerges = qualifyingDeclarers >=
        this.config.worldEnding.agiEmergence.minimumFormations;
    const requiredCollectiveTrust = setupCollectiveTrust +
      this.playerCount * this.config.worldEnding.openContinuity.collectiveTrustOffsetPerPlayer;
    const systemicRiskBounded = !this.config.worldEnding.openContinuity
      .systemicRiskMustBeBelowPlayerCount || this.systemicRisk < this.playerCount;
    const openContinuity = collectiveTrust >= requiredCollectiveTrust && systemicRiskBounded;
    const outcomeId = agiEmerges
      ? (openContinuity ? "singularity" : "closed_loop")
      : (openContinuity ? "plural_future" : "assured_continuity");
    const outcomeNames = this.config.worldEnding.outcomes;
    const outcomeName = {
      singularity: outcomeNames.singularity,
      closed_loop: outcomeNames.closedLoop,
      plural_future: outcomeNames.pluralFuture,
      assured_continuity: outcomeNames.assuredContinuity
    }[outcomeId];
    return {
      schemaVersion: 1,
      evidenceLabel: "simulation",
      scope: this.scope,
      seed: this.seed,
      playerCount: this.playerCount,
      rulesVariant: clone(this.rulesVariant),
      matchMetrics: clone(this.matchMetrics),
      decisionProtocol: {
        immediateTradePackets: this.immediateTradePackets,
        immediateTradePacketCeiling: this.immediateTradePacketCeiling
      },
      futureTimeline: clone(this.matchMetrics.futureTimeline),
      worldEnding: {
        id: outcomeId,
        name: outcomeName,
        agiEmerges,
        openContinuity,
        qualifyingDeclarers,
        collectiveTrust,
        requiredCollectiveTrust,
        unresolvedSystemicRisk: this.systemicRisk,
        systemicRiskExclusiveCeiling: this.playerCount
      },
      standings,
      winnerSeats,
      replay: this.recordReplay ? this.replay : undefined
    };
  }
}
