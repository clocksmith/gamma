import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import test from "node:test";
import { writeImmutableArtifact } from "../tasks/release-artifacts.mjs";

const root = new URL("../", import.meta.url);
const projectRoot = root.pathname;
const readJson = async (path) => JSON.parse(await readFile(new URL(path, root), "utf8"));

test("current release declaration separates executable game from physical rules candidate", async () => {
  const current = await readJson("versions/current-release.json");
  const packageDocument = await readJson("package.json");

  assert.match(current.gameVersion, /^\d+\.\d+\.\d+$/);
  assert.equal(packageDocument.name, "mandate-2038");
  assert.equal(packageDocument.version, current.gameVersion);
  assert.match(current.rulesCandidate.version, /^\d+\.\d+\.\d+-rc\.\d+(-test)?$/);
  assert.equal(current.rulesCandidate.implementationStatus, "synchronized");
  assert.equal(current.rulesCandidate.implementedByGameVersion, current.gameVersion);
  assert.equal(current.contracts.mechanicsProjectionVersion, 2);
  assert.ok(current.rulesetFiles.includes("dist/runtime/game-config.json"));
  assert.ok(current.playtestKitFiles.includes("dist/runtime/simulation-copy.json"));
  assert.deepEqual(current.rulesCandidate.files.slice(0, 3), [
    "dist/docs/core-rules.md",
    "dist/docs/world-and-institutions.md",
    "dist/docs/optional-tactics.md"
  ]);
});

test("physical authority defines one inventory and preserves automatic blind Audit draws", async () => {
  const [spec, inventory, governanceLedger, manufacturing, manifest] = await Promise.all([
    readFile(new URL("physical/component-spec.md", root), "utf8"),
    readFile(new URL("dist/docs/component-inventory.md", root), "utf8"),
    readFile(new URL("physical/governance-ledger.md", root), "utf8"),
    readFile(new URL("docs/manufacturing-and-publishing-study.md", root), "utf8"),
    readJson("content/data/content-manifest.json")
  ]);

  assert.match(spec, /indistinguishable by touch while concealed/);
  assert.match(spec, /same size, shape, material, and\s+weight/);
  assert.doesNotMatch(spec, /distinguishable by touch or sight/);
  assert.match(spec, /shared Mandate track/);
  assert.match(spec, /AGI recognition/);
  assert.match(spec, /Fusion Demonstrator/);
  assert.doesNotMatch(spec, /Economic Benchmark/);
  assert.doesNotMatch(spec, /Market Access/);
  assert.doesNotMatch(spec, /Influence cube/);
  assert.match(spec, /Initiative/);
  assert.match(spec, /visibly numbered 1–4/);
  assert.match(spec, /Current connections/);
  assert.match(spec, /use no Power cubes/);
  assert.doesNotMatch(spec, /Temporary Compute/);

  assert.match(inventory, /## One prepacked faction tray per player/);

  assert.match(inventory, /five captive sliders/);
  assert.match(inventory, /2 project references/);
  assert.doesNotMatch(inventory, /Program markers/);
  assert.match(inventory, /6 foldout player aids/);
  assert.match(inventory, /4 Agents/);
  assert.doesNotMatch(inventory, /Temporary Compute/);
  assert.doesNotMatch(inventory, /final production copy count remains open/);
  assert.doesNotMatch(inventory, /Unresolved packing quantities/);
  assert.match(governanceLedger, /Current Mandate/);
  assert.match(governanceLedger, /Criterion value or status/);
  assert.match(governanceLedger, /Setup Collective Trust/);
  assert.match(governanceLedger, /Unresolved Systemic Risk/);
  assert.match(governanceLedger, /Final institutional winner/);
  assert.match(governanceLedger, /World Ending/);
  assert.doesNotMatch(governanceLedger, /Permanent Program use/);

  for (const staleClaim of [
    "Approximately 190 baseline cards",
    "approximately 188 plus player references",
    "180 Default or 194 with Advanced",
    "older rules release",
    "Four shared ordinary Power Source references"
  ]) {
    assert.ok(!manufacturing.includes(staleClaim), `manufacturing retires ${staleClaim}`);
  }
  assert.match(manufacturing, /106 standard cards plus 6 foldouts/);

  assert.match(manufacturing, /Three Power contracts remain in the rules without separate cards/);

  const mapSurface = manifest.surfaces.find((surface) => surface.id === "map_tile_types");
  assert.equal(mapSurface.physicalCopies, 19);
  const governanceLedgerSurface = manifest.surfaces.find(
    (surface) => surface.id === "governance_ledger"
  );
  assert.equal(governanceLedgerSurface.physicalCopies, 1);
  assert.equal(
    manifest.surfaces.find((surface) => surface.id === "player_aid_panels").physicalCopies,
    6
  );
});

test("release artifacts are immutable once a version path exists", async () => {
  const directory = await mkdtemp(join(tmpdir(), "mandate-2038-release-artifact-"));
  const path = join(directory, "test-version", "manifest.json");
  try {
    assert.equal(await writeImmutableArtifact(path, "first\n"), true);
    assert.equal(await writeImmutableArtifact(path, "first\n"), false);
    await assert.rejects(
      writeImmutableArtifact(path, "different\n"),
      /Refusing to overwrite immutable release artifact/
    );
    assert.equal(await readFile(path, "utf8"), "first\n");
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("complexity-reduction review rules preserve precision and remove table accounting", async () => {
  const current = await readJson("versions/current-release.json");
  const [rules, mapReference, componentReference] = await Promise.all([
    readFile(new URL("dist/docs/core-rules.md", root), "utf8"),
    readFile(new URL("dist/docs/map-reference.md", root), "utf8"),
    readFile(new URL("dist/docs/component-reference.md", root), "utf8"),
  ]);
  const normalizedRules = [rules, mapReference, componentReference].join("\n").replace(/\s+/g, " ");
  for (const clause of [
    `**Rules version:** ${current.rulesCandidate.version}`,
    `synchronized with executable game ${current.gameVersion}`,
    "Political control uses Agents and Facilities already on the board",
    "two adjacent connected Facilities you own",
    "Each Facility may host only one Mega-Cluster",
    "Facility 1 is always powered",
    "acting Agent's district",
    "Every cross-player contract or jointly funded project requires the explicit",
    "Facilities sharing one hex are **co-located**. Adjacent host Facilities occupy hexes that share an edge",
    "### Universal costs and caps",
    "integrated starting-grid identifier",
    "Place two Agents per player at Frontier",
    "Use nineteen tiles in a complete radius-two hexagon",
    "Every outer district touches its two outer neighbors",
    "These ring pools are fixed; shuffle tiles only within their listed ring",
    "All copies of one named district are mechanically identical",
    "### C. Production",
    "No Power is assigned, spent, or marked.",
    "No separate Power Source cards are used",
    "### D. Optional AGI recognition",
    "Every qualifying institution may declare",
    "Every Faction has one persistent institutional identity and one signature ability",
    "your faction's single permanent ability",
    "There is no second winner procedure"
  ]) {
    assert.ok(normalizedRules.includes(clause), `canonical rules include ${clause}`);
  }
  assert.ok(!normalizedRules.includes("simultaneous capacity proof"));
  assert.ok(!normalizedRules.includes("notional transfer counts"));
  assert.ok(!normalizedRules.includes("Upgrade a Facility"));
  assert.ok(!normalizedRules.includes("Power Purchase Agreement"));
});

test("complexity positioning stays broad, unmeasured, and game-scoped", async () => {
  const [comparisons, decisions, manufacturing] = await Promise.all([
    readFile(new URL("docs/comparisons.md", root), "utf8"),
    readFile(new URL("docs/design-decisions.md", root), "utf8"),
    readFile(new URL("docs/manufacturing-and-publishing-study.md", root), "utf8")
  ]);

  assert.match(comparisons, /Mandate 2038 is designed as \*\*upper-medium\*\*/);
  assert.match(comparisons, /`3\.0–3\.4`/);

  assert.match(comparisons, /broad positioning hypotheses, not\s+community ratings/);
  assert.match(comparisons, /No current evidence supports a narrower Weight estimate/);
  assert.doesNotMatch(comparisons, /`3\.0–3\.2`/);
  assert.match(manufacturing, /ages 14\+, upper-medium strategy/);
  assert.match(decisions, /Presentation cannot create a new phase/);
  assert.match(decisions, /ReAct names Reason, Act, and Observe within the existing turn/);
});

test("the thematic inventory matches the two-source Power contract", async () => {
  const [bible, inventory, specification] = await Promise.all([
    readFile(new URL("world.md", root), "utf8"),
    readFile(new URL("dist/docs/component-inventory.md", root), "utf8"),
    readFile(new URL("physical/component-spec.md", root), "utf8")
  ]);
  assert.doesNotMatch(bible, /## Player-copy design inventory/);
  assert.doesNotMatch(bible, /## Physical quantity interpretation/);
  assert.doesNotMatch(bible, /## Concept inventory by Era/);
  assert.match(inventory, /1 three-panel foldout player aid/);
  assert.match(inventory, /2 project references/);
  assert.doesNotMatch(inventory, /Program markers/);
  assert.match(inventory, /The Grid and Renewable tiles print ordinary Power contracts/);
  assert.match(inventory, /10 Scrutiny cubes/);
  assert.match(inventory, /1 Mandate marker/);
  assert.match(inventory, /4 Agents/);
  assert.match(inventory, /integrated starting-grid identifier on Facility 1/);
  assert.match(specification, /Ordinary Power contract[\s\S]*Tile identity; no separate reference card/);
});

test("one thematic authority governs every lore-bearing surface", async () => {
  const [bible, eraLedger, prototype, world, tactics, reserve, objectives] = await Promise.all([
    readFile(new URL("world.md", root), "utf8"),
    readJson("dist/contracts/era-situation-ledger.json"),
    readFile(new URL("web/templates/prototype.html", root), "utf8"),
    readJson("dist/runtime/world-copy.json"),
    readJson("dist/runtime/tactics.json"),
    readJson("dist/runtime/reserve-specialists.json"),
    readJson("dist/runtime/secret-objectives.json")
  ]);

  await assert.rejects(stat(new URL("docs/lore-scratchpad.md", root)), { code: "ENOENT" });
  await assert.rejects(stat(new URL("dist/site/docs/lore-scratchpad.html", root)), {
    code: "ENOENT"
  });
  assert.match(bible, /sole editorial authority/);
  assert.match(bible, /## Writing contract/);
  assert.match(bible, /## Authoring/);
  assert.match(bible, /## Research provenance/);
  assert.ok(bible.indexOf("<!-- world-setting:start -->") < bible.indexOf("<!-- world-guide:start -->"));
  assert.doesNotMatch(bible, /GENERATED:ERA_SITUATION_LEDGER/);
  assert.equal(eraLedger.scenarios.length, 51);
  assert.equal(
    eraLedger.scenarios.flatMap((scenario) => scenario.surfaceBindings).length,
    54
  );
  assert.match(bible, /Bankruptcy Data Estates/);
  const tracedConcepts = new Set(eraLedger.scenarios.flatMap((scenario) => scenario.concepts));
  assert.ok(tracedConcepts.has("Bankruptcy Data Estates"));
  assert.ok(tracedConcepts.has("Cognitive Donor Clinics"));
  assert.ok(tracedConcepts.has("Metropolitan Mind Trust"));
  assert.match(prototype, /worldCopy\.box\.frontStrapline/);
  assert.match(prototype, /worldCopy\.box\.shortPitch/);

  assert.equal(tactics.tactics.length, 12);
  assert.equal(reserve.specialists.length, 12);
  assert.equal(objectives.objectives.length, 17);
  const deferredLore = JSON.stringify({ tactics, reserve, objectives });
  for (const phrase of [
    "Cheap-Token Rebound",
    "Failed Institutions",
    "Cognitive Donation",
    "The Refinancing Threshold",
    "Parameters Successfully Expanded"
  ]) {
    assert.match(deferredLore, new RegExp(phrase));
  }
  assert.doesNotMatch(
    JSON.stringify({ world, tactics, reserve, objectives }).concat("\n", prototype),
    /Build\. Deploy\. Regulate\. Plausibly declare|Tracking Pixels|Ask before displaying external images/
  );
});

test("selected deck contracts have exact physical counts", async () => {
  const [config, tactics, escalation, headlines, mandates, factions] = await Promise.all([
    readJson("dist/runtime/game-config.json"),
    readJson("dist/runtime/tactics.json"),
    readJson("dist/runtime/projects.json"),
    readJson("dist/runtime/headlines.json"),
    readJson("dist/runtime/mandates.json"),
    readJson("dist/runtime/factions.json")
  ]);

  const trainingCount = config.trainingDeck.cards.reduce((sum, card) => sum + card.count, 0);
  assert.equal(trainingCount, 40);
  assert.equal(tactics.tactics.length * tactics.copiesPerCard, 36);
  assert.equal(escalation.projects.length, 2);
  assert.equal(escalation.cardsPerPlayer, undefined);
  assert.equal(escalation.sharedCardCount, 2);
  const defaultHeadlineCount = headlines.headlines.filter(
    (headline) => !headline.requiredRuleModules?.length
  ).length;
  assert.deepEqual(
    [1, 2, 3, 4].map((era) =>
      headlines.headlines.filter(
        (headline) => headline.round === era && !headline.requiredRuleModules?.length
      ).length
    ),
    [5, 4, 3, 4]
  );
  const defaultStandardCards =
    config.playerSupply.coreActionCards * factions.factions.length +
    config.sharedSupply.projectReferences +
    defaultHeadlineCount +
    mandates.mandates.length +
    trainingCount;
  const defaultPrintedPieces = defaultStandardCards + config.sharedSupply.playerAidFoldouts;
  assert.equal(defaultStandardCards, 106);
  assert.equal(defaultPrintedPieces, 112);
  assert.deepEqual(
    config.powerSources.filter((source) => source.id !== "fusion_demonstrator").map((source) => source.id),
    ["clean_infrastructure", "emergency_infrastructure"]
  );
  for (const source of config.powerSources.filter((candidate) => candidate.id !== "fusion_demonstrator")) {
    assert.equal(
      source.runwayCost,
      config.singleGeneratorRule.locations[source.location].constructionCost,
      `${source.id} projects its authoritative location cost`
    );
  }
  assert.deepEqual(
    Object.fromEntries(config.powerSources.map((source) => [source.id, source.physicalSurface])),
    {
      clean_infrastructure: "renewable_basin_tile",
      emergency_infrastructure: "grid_reactor_tile",
      fusion_demonstrator: "fusion_demonstrator_project"
    }
  );
  assert.deepEqual(config.playerSupply.facilityConstructionOrder, [1, 2, 3, 4]);
  assert.deepEqual(
    {
      governanceBoardEraPanels: config.sharedSupply.governanceBoardEraPanels,
      currentEraMarkers: config.sharedSupply.currentEraMarkers,
      playerAidFoldouts: config.sharedSupply.playerAidFoldouts,
      governanceLedgers: config.sharedSupply.governanceLedgers,
      sharedDryEraseMarkers: config.sharedSupply.sharedDryEraseMarkers,
      temporaryComputeTokens: config.sharedSupply.temporaryComputeTokens,
      mandateMarkers: config.sharedSupply.mandateMarkers
    },
    {
      governanceBoardEraPanels: 4,
      currentEraMarkers: 1,
      playerAidFoldouts: 6,
      governanceLedgers: 1,
      sharedDryEraseMarkers: 1,
      temporaryComputeTokens: undefined,
      mandateMarkers: 6
    }
  );
});

test("core action and shared Program contracts stay singular", async () => {
  const config = await readJson("dist/runtime/game-config.json");
  assert.deepEqual(
    config.actions.map((action) => action.id),
    ["fund", "research", "build", "organize", "deploy", "influence"]
  );
  assert.deepEqual(config.rounds.map((round) => round.cycles), [3, 3, 3, 3]);
  assert.ok(config.rounds.every(round => !Object.hasOwn(round, "programUses")));
  assert.ok(config.construction.projects.includes("fusion_demonstrator"));
});

test("factions and player supplies match the selected limits", async () => {
  const config = await readJson("dist/runtime/game-config.json");
  const factions = await readJson("dist/runtime/factions.json");

  assert.equal(factions.factions.length, 6);
  assert.equal(new Set(factions.factions.map((faction) => faction.id)).size, 6);
  assert.deepEqual(
    {
      agents: config.playerSupply.agents,
      startingAgents: config.playerSupply.startingAgents,
      facilities: config.playerSupply.facilities,
      generators: config.playerSupply.generators,
      influenceCubes: config.playerSupply.influenceCubes,
      scrutinyCubes: config.playerSupply.scrutinyCubes,
      factionBoardCaptiveSliders: config.playerSupply.factionBoardCaptiveSliders,
      programMarkers: config.playerSupply.programMarkers,
      startingGridIdentifiers: config.playerSupply.startingGridIdentifiers
    },
    {
      agents: 4,
      startingAgents: 2,
      facilities: 4,
      generators: 1,
      influenceCubes: 0,
      scrutinyCubes: 10,
      factionBoardCaptiveSliders: 5,
      programMarkers: undefined,
      startingGridIdentifiers: 1
    }
  );
  for (const staleField of [
    "customerMarkers",
    "escalationTokens",
    "agiDeclarationCards",
    "agiDeclarationMarkers",
    "startingGridMarkers",
    "jointVentureMarkers",
    "megaClusterMarkers",
    "networkMarkers",
    "networkTrackMarkers",
    "customerTrackMarkers",
    "escalationTrackMarkers",
    "advancedNetworkCaptiveSliders",
    "realignmentBallots"
  ]) assert.ok(!(staleField in config.playerSupply), `playerSupply retires ${staleField}`);

  const allowedTiming = new Set(factions.abilityTimingContract.allowedTiming);
  for (const faction of factions.factions) {
    assert.equal(faction.abilities.length, 1);
    for (const ability of faction.abilities) {
      assert.ok(ability.id, `${faction.id} ability has a stable id`);
      assert.ok(allowedTiming.has(ability.timing), `${faction.id}/${ability.id} has a timing tag`);
      assert.equal(typeof ability.persistsAfterUnlock, "boolean");
    }
  }

  const platform = factions.factions.find((faction) => faction.id === "platform_empire");
  assert.equal(platform.starts.customers, 1);
  assert.equal(platform.starts.customerOrdinal, 1);
  assert.equal(platform.starts.nextCustomerCapability, 4);

  const vertical = factions.factions.find((faction) => faction.id === "vertical_empire");
  const imperial = factions.factions.find(
    (faction) => faction.id === "imperial_research_lab"
  );
  const safety = factions.factions.find((faction) => faction.id === "safety_laboratory");
  assert.equal(platform.starts.startingPublicMandate, 4);
  assert.equal(imperial.starts.startingPublicMandate, 2);
  assert.equal(vertical.starts.startingPublicMandate, 2);
  assert.equal(safety.starts.startingPublicMandate, 4);
});

test("faction truth constrains balance without becoming a point-buy budget", async () => {
  const factions = await readJson("dist/runtime/factions.json");
  const balance = await readJson("lab/contracts/balance-contract.json");
  const truth = factions.factionTruthContract;
  const factionIds = factions.factions.map((faction) => faction.id);
  const dimensionIds = Object.keys(truth.dimensions);

  assert.equal(truth.status, "selected_design_constraint");
  assert.equal(truth.scale.minimum, 1);
  assert.equal(truth.scale.maximum, 5);
  assert.deepEqual(Object.keys(truth.profiles), factionIds);
  assert.equal(balance.factionTruth.source, "dist/runtime/factions.json#factionTruthContract");
  assert.equal(balance.factionTruth.requiredForRuleProbe, true);

  for (const factionId of factionIds) {
    const profile = truth.profiles[factionId];
    assert.deepEqual(Object.keys(profile.ratings), dimensionIds);
    assert.ok(profile.protectedStrength);
    assert.ok(profile.balanceBottleneck);
    assert.ok(profile.forbiddenCorrection);
    for (const rating of Object.values(profile.ratings)) {
      assert.ok(rating >= truth.scale.minimum && rating <= truth.scale.maximum);
    }
  }
});

test("Faction boards project into Card and Board Reference without duplicating their card text in Core Rules", async () => {
  const factions = await readJson("dist/runtime/factions.json");
  const [rules, cardReference] = await Promise.all([
    readFile(resolve(projectRoot, "dist/docs/core-rules.md"), "utf8"),
    readFile(resolve(projectRoot, "dist/docs/card-reference.md"), "utf8")
  ]);

  for (const faction of factions.factions) {
    if (faction.scoringRule) {
      assert.ok(faction.scoringRule.text, `${faction.id} owns scoring text`);
      assert.ok(!rules.includes(faction.scoringRule.text));
      assert.ok(cardReference.includes(faction.scoringRule.text));
    }
    for (const ability of faction.abilities) {
      assert.ok(ability.text, `${faction.id}/${ability.name} owns card text`);
      assert.ok(!rules.includes(ability.text));
      assert.ok(cardReference.includes(ability.text));
    }
  }

  assert.match(rules, /one persistent institutional identity and one\s+signature ability/);
  assert.match(rules, /use each Faction board’s printed starts/);
  assert.doesNotMatch(rules, /Scientific Method:/);
  assert.doesNotMatch(rules, /Industrial Velocity:/);
});

test("headline and board boundaries remain explicit", async () => {
  const config = await readJson("dist/runtime/game-config.json");
  const headlines = await readJson("dist/runtime/headlines.json");

  assert.equal(headlines.headlines.length, 16);
  for (const round of [1, 2, 3, 4]) {
    assert.equal(headlines.headlines.filter((headline) => headline.round === round).length, [5, 4, 3, 4][round - 1]);
  }
  const expandedTiles = config.board.tiles.reduce((sum, tile) => sum + tile.count, 0);
  assert.equal(config.board.selectedTileCount, 19);
  assert.equal(expandedTiles, config.board.prototypeTileCount);
  assert.equal(expandedTiles, 19);
  assert.equal(config.board.tiles.find((tile) => tile.id === "consumer").count, 2);
  assert.equal(
    config.board.tiles.filter((tile) => tile.category === "energy")
      .reduce((sum, tile) => sum + tile.count, 0),
    3
  );
  assert.ok(!Object.hasOwn(config.board.startingGridConnection, "capacity"));
  assert.deepEqual(config.playRules, {immediateTradeCounteroffers: false, immediateTradeThirdPartyClaims: false});
  assert.ok(!('playProfiles' in config));
  assert.ok(!('playRuleModules' in config));
  assert.ok(!('realignment' in config.board));
  assert.equal(config.playerSupply.factionBoardCaptiveSliders, 5);
  assert.equal(config.playerSupply.programMarkers, undefined);
  assert.deepEqual(
    Object.fromEntries(config.board.tiles.map((tile) => [tile.id, tile.name])),
    {
      frontier: "Frontier",
      research: "Research Commons",
      cloud: "Compute Estate",
      consumer: "Human Access District",
      foundry: "Fabrication Corridor",
      capital: "Allocation Exchange",
      talent: "Workforce Transition District",
      media: "Consensus Network",
      government: "Civic Permission Authority",
      grid_reactor: "Power Corridor",
      renewable_basin: "Thermal and Water Basin"
    }
  );
  assert.match(
    config.board.tiles.find((tile) => tile.id === "frontier").flavorText,
    /standing civic exception/
  );
  assert.match(
    config.board.tiles.find((tile) => tile.id === "research").flavorText,
    /Publicly chartered inquiry/
  );
  for (const tile of config.board.tiles) {
    assert.equal(
      Object.values(tile.placement).reduce((sum, count) => sum + count, 0),
      tile.count,
      `${tile.id} placement matches physical count`
    );
  }

  assert.equal(
    config.board.tiles.reduce(
      (sum, tile) => sum + Object.values(tile.placement).reduce((total, count) => total + count, 0),
      0
    ),
    19
  );

  const blogPost = headlines.headlines.find((headline) => headline.id === "agi_blog_post");
  assert.match(blogPost.text, /gains 1 Trust/);
  assert.doesNotMatch(blogPost.text, /claim strength/);
});

test("Headline deck contains the sixteen selected procedures", async () => {
  const { headlines, resolutionContract } = await readJson("dist/runtime/headlines.json");
  const ids = new Set(headlines.map((headline) => headline.id));
  const anchors = [
    "open_weights_drop",
    "export_controls",
    "weights_on_internet",
    "agent_swarm_escapes_scope",
    "agi_blog_post"
  ];
  const replacements = [
    "ten_dollar_intelligence",
    "employee_free_unicorn",
    "synthetic_celebrity",
    "professional_exam_sweep",
    "humanoid_factory_gate",
    "reactor_restart_one_model",
    "emergency_power_authority",
    "ai_written_law",
    "benchmark_is_economy",
    "autonomous_corporation",
    "recursive_self_improvement",
  ];
  const retired = [
    "chatbot_breakout",
    "gpu_backorder",
    "cloud_credits",
    "voluntary_safety_commitments",
    "employee_open_letter",
    "year_of_efficiency",
    "product_feature_paused",
    "supercluster_online",
    "copyright_injunction",
    "benchmark_leak",
    "talent_exodus",
    "search_answer_viral",
    "million_gpu_order",
    "national_compute_reserve",
    "synthetic_feedback_loop",
    "power_grid_backlash"
  ];

  for (const id of [...anchors, ...replacements]) assert.ok(ids.has(id), `${id} is in the selected deck`);
  retired.push(...["talent_gold_rush","boardroom_coup","data_center_buys_county","quantum_advantage_procurement","synthetic_candidate","election_deepfake_panic","agi_personhood","room_temperature_superconductor"]);
  for (const id of retired) assert.ok(!ids.has(id), `${id} is retired`);
  assert.equal(anchors.filter((id) => ids.has(id)).length, 5);
  assert.equal(replacements.filter((id) => ids.has(id)).length, 11);

  assert.deepEqual(resolutionContract.timings, ["before_selection"]);
  assert.ok(headlines.every(card => card.duration === "immediate"));

  const byId = Object.fromEntries(headlines.map((headline) => [headline.id, headline]));
  const allowedResolutionTypes = new Set([
    "DIRECTIVE",
    "SECRET CHOICE",
  ]);
  assert.ok(
    headlines.every((headline) => allowedResolutionTypes.has(headline.resolutionType)),
    "every Headline has exactly one supported resolution type"
  );

  assert.ok(
    headlines.every((headline) => headline.resolutionType !== "REGIME"),
    "standard Headline instructions use the procedural DIRECTIVE badge"
  );
  assert.match(byId.emergency_power_authority.text, /2 Compute and add 1 Scrutiny/);
  assert.match(byId.benchmark_is_economy.text, /1 Capability.*1 Systemic Risk/);
  assert.match(byId.autonomous_corporation.text, /2 Runway.*1 Scrutiny/);

  assert.ok(
    headlines.every((headline) => !headline.regimeTags.includes("bonus_action")),
    "No Headline grants a Core Action"
  );
  assert.equal(
    byId.agent_swarm_escapes_scope.name,
    "The Dead Remain on Shift"
  );

});

test("the tone constitution keeps darkness institutional rather than voyeuristic", async () => {
  const [world, thematicBible] = await Promise.all([
    readFile(new URL("dist/docs/world-and-institutions.md", root), "utf8"),
    readFile(new URL("world.md", root), "utf8")
  ]);

  const bible = thematicBible.replace(/\s+/g, " ");
  const companion = world.replace(/\s+/g, " ");
  assert.match(bible, /Write consequences at institutional distance/);
  assert.match(bible, /Do not depict first-person torment, body horror, or voyeuristic suffering/);
  assert.doesNotMatch(companion, /The Future Timeline is one compounding public record/);
  assert.doesNotMatch(companion, /\*\*Interpretation\.\*\*/);
});

test("every player-facing content surface has complete copy", async () => {
  const [
    config,
    factions,
    headlines,
    tactics,
    escalation,
    references,
    mandates,
    world,
    reserve,
    objectives,
    simulationCopy,
    uiCopy
  ] = await Promise.all([
    readJson("dist/runtime/game-config.json"),
    readJson("dist/runtime/factions.json"),
    readJson("dist/runtime/headlines.json"),
    readJson("dist/runtime/tactics.json"),
    readJson("dist/runtime/projects.json"),
    readJson("dist/runtime/reference-cards.json"),
    readJson("dist/runtime/mandates.json"),
    readJson("dist/runtime/world-copy.json"),
    readJson("dist/runtime/reserve-specialists.json"),
    readJson("dist/runtime/secret-objectives.json"),
    readJson("dist/runtime/simulation-copy.json"),
    readJson("dist/runtime/ui-copy.json")
  ]);

  for (const era of references.eraCards) {
    for (const field of ["name", "strapline", "rulesText", "unlockText"]) {
      assert.ok(era[field], `${era.id} has ${field}`);
    }
  }
  for (const action of config.actions) {
    for (const field of ["initiativeName", "slogan", "flavorText"]) {
      assert.ok(action[field], `${action.id} has ${field}`);
    }
  }
  for (const tile of config.board.tiles) {
    for (const field of ["landmark", "flavorText"]) {
      assert.ok(tile[field], `${tile.id} has ${field}`);
    }
  }

  for (const [resourceId, resource] of Object.entries(config.resources)) {
    for (const field of ["name", "microcopy"]) {
      assert.ok(resource[field], `${resourceId} has ${field}`);
    }
  }
  for (const card of config.trainingDeck.cards) {
    for (const field of ["name", "rulesText", "flavorText"]) {
      assert.ok(card[field], `${card.id} has ${field}`);
    }
  }
  for (const source of config.powerSources) {
    for (const field of ["tagline", "rulesText", "publicClaim"]) {
      assert.ok(source[field], `${source.id} has ${field}`);
    }
  }
  for (const faction of factions.factions) {
    for (const field of ["motto", "introduction", "agiDeclaration"]) {
      assert.ok(faction[field], `${faction.id} has ${field}`);
    }
    for (const ability of faction.abilities) {
      for (const field of ["displayName", "flavorText"]) {
        assert.ok(ability[field], `${faction.id}/${ability.name} has ${field}`);
      }
    }
  }
  for (const headline of headlines.headlines) {
    for (const field of ["newswire", "quote", "regimeTags"]) {
      assert.ok(headline[field], `${headline.id} has ${field}`);
    }
    assert.ok(headline.regimeTags.length >= 3, `${headline.id} has meaningful regime tags`);
  }
  for (const mandate of mandates.mandates) {
    for (const field of ["name", "rulesText", "flavorText"]) {
      assert.ok(mandate[field], `${mandate.id} has ${field}`);
    }
  }
  for (const tactic of tactics.tactics) {
    for (const field of ["displayName", "flavorText", "technology"]) {
      assert.ok(tactic[field], `${tactic.id} has ${field}`);
    }
  }
  for (const action of escalation.projects) {
    for (const field of ["displayName", "flavorText"]) {
      assert.ok(action[field], `${action.id} has ${field}`);
    }
  }
  for (const reference of references.playerReferences) {
    assert.ok(reference.name, `${reference.id} has name`);
    assert.ok(reference.flavorText, `${reference.id} has flavorText`);
    assert.ok(reference.frontText.length, `${reference.id} has frontText`);
    assert.ok(reference.backText.length, `${reference.id} has backText`);
  }
  for (const specialist of reserve.specialists) {
    for (const field of ["name", "title", "flavorText"]) {
      assert.ok(specialist[field], `${specialist.id} has ${field}`);
    }
  }
  for (const objective of objectives.objectives) {
    for (const field of ["name", "rulesText", "flavorText"]) {
      assert.ok(objective[field], `${objective.id} has ${field}`);
    }
  }
  for (const token of world.tokenCopy) {
    for (const field of ["name", "microcopy"]) {
      assert.ok(token[field], `${token.id} has ${field}`);
    }
  }
  for (const ending of world.endings) {
    for (const field of ["name", "condition", "text"]) {
      assert.ok(ending[field], `${ending.id} has ${field}`);
    }
  }
  for (const field of ["frontStrapline", "backCopy", "shortPitch", "contentWarning"]) {
    assert.ok(world.box[field], `world box has ${field}`);
  }
  assert.equal(world.worldPrimer, undefined);

  const allPlayerCopy = JSON.stringify({
    config,
    factions,
    headlines,
    tactics,
    escalation,
    references,
    mandates,
    world,
    reserve,
    objectives,
    simulationCopy,
    uiCopy
  });
  assert.doesNotMatch(allPlayerCopy, /\b(?:lorem ipsum|tbd|todo|placeholder)\b/i);
  assert.doesNotMatch(
    allPlayerCopy,
    /Upload the Crown Jewels|Reject joint funding|The rivals stop firing/
  );
  assert.equal(
    simulationCopy.decisions.openWeights,
    "Adopt the Public Capability Covenant"
  );
  assert.match(simulationCopy.decisions.reorganizeReturn, /add 1 Scrutiny/);
  assert.doesNotMatch(simulationCopy.decisions.reorganizeReturn, /ready one Action/i);
  assert.equal("megaClusterAccept" in simulationCopy.decisions, false);
  assert.equal("megaClusterReject" in simulationCopy.decisions, false);
  assert.ok(objectives.objectives.every(objective => objective.id !== "compute_diplomacy"));
});

test("the selected lore inventory is complete and preserves era placement", async () => {
  const [
    { headlines },
    { mandates },
    { projects, institutionalHistory },
    { eraCards },
    { factions },
    world,
    rules,
    companion
  ] = await Promise.all([
    readJson("dist/runtime/headlines.json"),
    readJson("dist/runtime/mandates.json"),
    readJson("dist/runtime/projects.json"),
    readJson("dist/runtime/reference-cards.json"),
    readJson("dist/runtime/factions.json"),
    readJson("dist/runtime/world-copy.json"),
    readFile(new URL("dist/docs/core-rules.md", root), "utf8"),
    readFile(new URL("dist/docs/world-and-institutions.md", root), "utf8")
  ]);

  assert.equal(headlines.length, 16);
  for (const era of [1, 2, 3, 4]) {
    assert.equal(
      headlines.filter((headline) => headline.round === era).length,
      [5, 4, 3, 4][era - 1],
      `Era ${era} has its selected Headlines`
    );
    assert.equal(
      mandates.filter((mandate) => mandate.era === era).length,
      3,
      `Era ${era} has three Mandates`
    );
  }
  for (const headline of headlines) {
    assert.equal(headline.strapline, undefined);
    assert.ok(headline.newswire.endsWith("."), `${headline.id} has complete newswire copy`);
    assert.ok(headline.quote.endsWith("."), `${headline.id} has complete quote copy`);
  }

  const progressOpenWeights = headlines.find(
    (headline) => headline.id === "open_weights_drop"
  );
  assert.equal(progressOpenWeights.round, 1);
  assert.match(progressOpenWeights.name, /Open Weights/);

  const authorityEra = eraCards.find((era) => era.id === "era_narrative");
  const authorityProgram = institutionalHistory.find(
    (escalation) => escalation.id === "open_weights"
  );
  assert.match(authorityEra.unlockText, /Joint Ventures/);
  assert.doesNotMatch(authorityEra.unlockText, /Open Weights/i);
  assert.equal(authorityProgram.name, "Public Capability Covenant");
  assert.equal(authorityProgram.displayName, "Supported Access Standard");
  assert.doesNotMatch(authorityProgram.name, /Open Weights/i);
  assert.doesNotMatch(rules, /#### Open Weights|Open Weights is global after movement/i);

  const billionBloom = headlines.find(
    (headline) => headline.id === "benchmark_is_economy"
  );
  assert.equal(billionBloom.round, 3);
  assert.match(billionBloom.name, /Billionth Instance/);
  assert.match(billionBloom.newswire, /bio-compute organism/i);
  assert.match(billionBloom.newswire, /one billion instances/i);
  assert.match(billionBloom.newswire, /glyph-shaped colonies/i);
  const authorityChapter = companion.split("### Era III: Authority")[1].split("### Era IV:")[0].replace(/\s+/g, " ");
  assert.match(authorityChapter, /bio-compute organism/i);
  assert.match(authorityChapter, /instrument, infestation, language, or claimant/i);
  assert.doesNotMatch(companion.split("### Era III:")[0], /glyph-shaped/i);

  const clinic = headlines.find((headline) => headline.id === "professional_exam_sweep");
  const hazardShift = headlines.find((headline) => headline.id === "humanoid_factory_gate");
  const mindTrust = headlines.find((headline) => headline.id === "autonomous_corporation");
  const coalition = factions.find((faction) => faction.id === "coalition_lab");
  const capacityCompact = coalition.lore.find(
    (ability) => ability.name === "Strategic Partnership"
  );
  const regionalCapacity = projects.find(
    (escalation) => escalation.id === "mega_cluster"
  );

  assert.match(clinic.newswire, /adaptive cybernetics/i);
  assert.match(clinic.newswire, /prescribed microbiomes/i);
  assert.match(hazardShift.newswire, /gridlock streets, lifts, loading docks, pipes/i);
  assert.match(capacityCompact.flavorText, /governments remain at war/i);
  assert.match(regionalCapacity.flavorText, /algae reactors, fungal utility meshes/i);
  assert.match(mindTrust.newswire, /engineered roots, utility pipes, microbial sensors/i);

  assert.equal(world.worldPrimer, undefined);
  assert.equal(world.endings.length, 4);
  assert.equal(world.tokenCopy.length, 8);
  assert.equal(eraCards.length, 4);
  assert.equal(factions.length, 6);
  const narrative = companion.replace(/\s+/g, " ");
  // Preserve the biological and institutional threads when changing presentation.
  for (const concept of [
    /open weights.*quantization/i,
    /adaptive cybernetics/i,
    /prescribed microbiomes/i,
    /patented biological strains/i,
    /water rights, transmission corridors/i,
    /loading docks.*pipes/i,
    /bridge between governments still at war/i,
    /desalinated water.*data-center coolant/i,
    /cognitive-donor.*sleeping brains/i,
    /read access.*memory writes/i,
    /replacement liver.*chemical exposure.*certified readings.*insurers and courts/i,
    /identity and treatment records.*inheritance.*donors/i,
    /pollinating swarms.*machine-readable blooms/i,
    /standing, reproductive freedom, and compensation/i,
    /bio-compute organism/i,
    /beyond one billion instances in a single growth cycle/i,
    /glyph-shaped colonies/i,
    /cryptographic snapshot/i,
    /matter compiler/i,
    /stellar collectors.*reproducing across the solar system/i,
    /instrument, infestation, language, or claimant/i
  ]) assert.match(narrative, concept);

  const allSelectedLore = JSON.stringify({ headlines, mandates, projects, eraCards, factions, world })
    .concat("\n", companion);
  assert.doesNotMatch(allSelectedLore, /Tracking Pixels|Ask before displaying external images|Trust Center/);
});

test("new thematic decks and reference surfaces have complete draft inventories", async () => {
  const mandates = await readJson("dist/runtime/mandates.json");
  const objectives = await readJson("dist/runtime/secret-objectives.json");
  const references = await readJson("dist/runtime/reference-cards.json");
  const reserve = await readJson("dist/runtime/reserve-specialists.json");
  const tactics = await readJson("dist/runtime/tactics.json");
  const [world, factions] = await Promise.all([
    readJson("dist/runtime/world-copy.json"),
    readJson("dist/runtime/factions.json")
  ]);
  const manifest = await readJson("dist/runtime/content-manifest.json");

  assert.equal(mandates.mandates.length, 12);
  assert.equal(objectives.objectives.length, 17);
  assert.equal(references.eraCards.length, 4);
  assert.equal(references.playerReferences.length, 3);
  assert.equal(reserve.specialists.length, 12);
  assert.equal(world.agiDeclarations, undefined);
  assert.equal(factions.factions.filter((faction) => faction.agiDeclaration).length, 6);
  assert.equal(world.endings.length, 4);
  assert.deepEqual(
    world.endings.map((ending) => ending.id),
    ["singularity", "closed_loop", "plural_future", "assured_continuity"]
  );
  assert.equal(world.tokenCopy.length, 8);

  for (const card of [...tactics.tactics, ...reserve.specialists, ...objectives.objectives]) {
    assert.ok([1, 2, 3, 4].includes(card.era), `${card.id} has an Era classification`);
  }

  const requiredCardFields = ["name", "rulesText", "flavorText"];
  for (const card of [...mandates.mandates, ...objectives.objectives]) {
    for (const field of requiredCardFields) assert.ok(card[field], `${card.id} has ${field}`);
  }

  const ids = manifest.surfaces.map((surface) => surface.id);
  assert.equal(ids.length, new Set(ids).size);
  assert.ok(manifest.surfaces.every((surface) => surface.status));
  assert.deepEqual(
    manifest.surfaces.filter((surface) => surface.file === null).map((surface) => surface.status).sort(),
    ["final_art_missing", "production_layout_missing"]
  );
});

test("prototype renders canonical names from faction data without a legacy reference layer", async () => {
  const app = await readFile(new URL("web/app.js", root), "utf8");
  assert.doesNotMatch(app, /faction\.historicalReference/);
  assert.match(app, /faction\.motto/);
});

test("browser renders canonical Headline copy without a rules selector", async () => {
  const [app, engine, template, uiCopy] = await Promise.all([
    readFile(new URL("web/app.js", root), "utf8"),
    readFile(new URL("web/src/engine.js", root), "utf8"),
    readFile(new URL("web/templates/prototype.html", root), "utf8"),
    readJson("dist/runtime/ui-copy.json")
  ]);

  assert.match(app, /fetch\("\/dist\/runtime\/ui-copy\.json"\)/);
  assert.match(app, /copy\.browser\.startingStatus/);
  assert.doesNotMatch(app, /config\.board\.prototypeNote/);
  assert.doesNotMatch(engine, /prototypeNote/);
  for (const field of ["name", "newswire", "text", "quote"]) {
    assert.match(app, new RegExp(`headline\\?\\.${field}|headline\\.${field}`));
    assert.match(template, new RegExp(`id="headline-${field === "text" ? "consequence" : field}"`));
  }

  assert.doesNotMatch(template, /id="headline-strapline"/);
  assert.doesNotMatch(app, /headline-strapline/);
  assert.doesNotMatch(template, /id="play-profile"/);
  assert.doesNotMatch(template, /rc\.5-test|frontier-2038/);
  assert.match(uiCopy.prototype.browser.startingStatus, /deterministic browser opponents/);
  assert.ok(!("realignment" in uiCopy.prototype));
  assert.doesNotMatch(JSON.stringify(uiCopy), /Advanced Play/);
});
