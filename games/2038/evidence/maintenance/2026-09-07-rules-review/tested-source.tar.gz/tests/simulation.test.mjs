import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import {
  captureSimulationLaunchIdentity,
  createSimulation,
  factionRosterForRun
} from "../lab/runtime/create-simulation.js";
import { loadPlayerProfiles, profileForPrompt } from "../lab/personas/player-profile.js";
import {
  CliBackedPlayerPolicy,
  WeightedPlayerPolicy
} from "../lab/policies/policy-factory.js";
import {
  compareStrategyEvaluations,
  mergeStrategyProfiles,
  mutateRulesVariant,
  mutateStrategy,
  opponentProfileWindows
} from "../lab/runner/optimization-runner.js";
import { runExperiment } from "../lab/runtime/run-experiment.js";
import { createInteractiveGame } from "../lab/runtime/create-interactive-game.js";
import {
  createBrowserInteractiveGame
} from "../lab/runtime/create-browser-interactive-game.js";
import { archiveSimulationReport } from "../lab/report-archive.js";
import {
  classifyReportComparison,
  normalizeSimulationReport
} from "../lab/contracts/report-migrations.js";
import {
  fingerprintObject,
  loadGameIdentity,
  mechanicsProjection
} from "../lab/versioning/game-identity.js";
import { buildDecisionPrompt } from "../lab/contracts/decision-contract.js";
import {
  immediateTradePacketCeiling
} from "../lab/environment/selected-rules-match.js";
import {
  legacyPrePromotionRulesOverlay
} from "../lab/environment/rules-variant.js";
import { loadBalanceContract } from "../lab/balance/balance-contract.js";
import { runBalanceAudit } from "../lab/runner/balance-audit-runner.js";
import {
  expandAgiDeclarationScenarioMatrix,
  expandCoalitionConversionMatrix,
  expandFactionIsolationMatrix,
  LlmConcurrencyBroker,
  runFactionSwapDiagnostic
} from "../lab/runner/faction-swap-runner.js";

const currentRelease = await (async () => {
  return JSON.parse(await readFile(new URL("../versions/current-release.json", import.meta.url), "utf8"));
})();

function fixturePolicy(select = () => null) {
  return {
    async decide(packet) {
      const selected = select(packet) || packet.legalDecisions[0];
      return {
        decision: {
          decisionId: selected.decisionId,
          rationale: "Deterministic fixture policy."
        },
        receipt: {
          provider: "fixture",
          profileId: "fixture",
          requestId: packet.requestId
        }
      };
    }
  };
}

test("player personas load as reusable provider-neutral strategy profiles", async () => {
  const profiles = await loadPlayerProfiles();
  assert.ok(profiles.length >= 4);
  assert.equal(new Set(profiles.map((profile) => profile.id)).size, profiles.length);
  const promptProfile = profileForPrompt(profiles[0]);
  assert.equal(promptProfile.id, profiles[0].id);
  assert.ok(promptProfile.persona.worldview.length > 0);
  assert.ok(promptProfile.objectives.length > 0);
  assert.ok(promptProfile.resourceValues.compute > 0);
});

test("World Ending crosses AGI emergence with both Open-continuity gates", async () => {
  const endingFor = async ({
    emerges,
    trustDeltaPerPlayer = 1,
    systemicRisk = 0
  }) => {
    const { match } = await createInteractiveGame(
      {
        playerCount: 3,
        factionId: "coalition_lab",
        seed: `world-ending-${emerges}-${trustDeltaPerPlayer}-${systemicRisk}`
      },
      () => {}
    );
    for (const player of match.players) {
      const faction = match.factions.find((entry) => entry.id === player.factionId);
      player.trust = faction.starts.trust + trustDeltaPerPlayer;
    }
    match.systemicRisk = systemicRisk;
    if (emerges) {
      match.players[0].agiDeclared = true;
    }
    return match.result().worldEnding;
  };

  assert.deepEqual(await endingFor({ emerges: true }), {
    id: "singularity",
    name: "The Singularity",
    agiEmerges: true,
    openContinuity: true,
    qualifyingDeclarers: 1,
    collectiveTrust: 11,
    requiredCollectiveTrust: 11,
    unresolvedSystemicRisk: 0,
    systemicRiskExclusiveCeiling: 3
  });
  assert.equal((await endingFor({
    emerges: true,
    trustDeltaPerPlayer: 0
  })).id, "closed_loop");
  assert.equal((await endingFor({
    emerges: false,
    systemicRisk: 2
  })).id, "plural_future");
  assert.equal((await endingFor({
    emerges: false,
    systemicRisk: 3
  })).id, "assured_continuity");
});

test("interactive snapshots expose canonical Headline copy without a rules selector", async () => {
  const options = {
    playerCount: 3,
    factionId: "coalition_lab",
    seed: "browser-headline-copy-contract"
  };
  const { match: defaultMatch } = await createInteractiveGame(options, () => {});
  const headline = defaultMatch.headlineDocument.headlines[0];
  defaultMatch.activeHeadline = headline;
  const defaultSnapshot = defaultMatch.snapshot();

  assert.ok(!("playProfileId" in defaultSnapshot));
  assert.deepEqual(defaultSnapshot.activeHeadline, {
    id: headline.id,
    name: headline.name,
    newswire: headline.newswire,
    text: headline.text,
    quote: headline.quote
  });

  await assert.rejects(createInteractiveGame({...options, rulesVariant: {playProfileId: "advanced-play"}}, () => {}), /Unsupported rules option/);
});

test("Scientific Method charges only when its protection is actually consumed", async () => {
  const researchDecision = {
    decisionId: "fixture-research",
    label: "Fixture Research",
    actionId: "research",
    parameters: {
      destinationCategory: "cloud",
      destinationId: "frontier",
      pieceId: "s0-agent-1",
      stopAt: 3
    }
  };
  const createImperialMatch = async (suffix) => {
    const { match } = await createInteractiveGame(
      {
        playerCount: 3,
        factionId: "imperial_research_lab",
        seed: `scientific-method-${suffix}`
      },
      () => {}
    );
    return match;
  };

  const used = await createImperialMatch("used");
  used.resolveTrainingRun = () => ({
    capability: 0,
    trust: 0,
    runwaySpent: 0,
    protection: "scientific_method",
    scrutiny: 0
  });
  used.applyResolution(0, researchDecision);
  assert.equal(used.players[0].runway, 2);
  assert.equal(used.players[0].roundMetrics.scientificMethodUsed, undefined);
  assert.ok(!Object.hasOwn(used.players[0], "researchProtection"));
  assert.deepEqual(
    used.players[0].metrics.factionAbilityValues.scientific_method,
    {
      uses: 1,
      runwaySpent: 1,
      duplicatesProtected: 1,
      capabilityPreserved: 0,
          }
  );

  const unused = await createImperialMatch("unused");
  unused.resolveTrainingRun = () => ({
    capability: 1,
    trust: 0,
    runwaySpent: 0,
    protection: null,
    scrutiny: 0
  });
  unused.applyResolution(0, researchDecision);
  assert.equal(unused.players[0].runway, 3);
  assert.ok(!unused.players[0].roundMetrics.scientificMethodUsed);


});

test("legal-decision adjustments do not mutate their generated decision", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "decision-adjustment-immutability"
    },
    () => {}
  );
  const decision = {
    decisionId: "fixture-fund",
    label: "Fixture Fund",
    actionId: "fund",
    parameters: {
      destinationCategory: "capital",
      mode: "conservative"
    },
    consequences: { runway: 2 }
  };
  const original = structuredClone(decision);
  const adjusted = match.adjustDecision(match.players[0], decision);

  assert.deepEqual(decision, original);
  assert.notStrictEqual(adjusted, decision);
  assert.notStrictEqual(adjusted.parameters, decision.parameters);
  assert.equal(adjusted.parameters.actualRunway, 3);
});








test("shared contract supplies cap construction and Joint Venture termination requires Facility presence", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "shared-contract-supply" },
    () => {}
  );
  match.round = 3;
  const player = match.players[0];
  const partner = match.players[1];
  match.contracts = Array.from(
    { length: match.config.sharedSupply.jointVenturePairs },
    (_, index) => ({
      id: index + 1,
      kind: "joint_venture",
      left: { seat: 0, facilityId: `left-${index}` },
      right: { seat: 1, facilityId: `right-${index}` }
    })
  );
  player.jointVentures = match.contracts.map((contract) => ({ contractId: contract.id }));
  partner.jointVentures = match.contracts.map((contract) => ({ contractId: contract.id }));
  player.facilities = [{
    id: "political-host",
    tileId: player.pieces[0].tileId,
    category: "frontier",
    powered: true
  }];

  const legal = match.legalResolutions(0, "influence");
  assert.equal(match.jointVentureSupplyAvailable(), false);
  assert.equal(legal.some((decision) => decision.parameters?.mode === "joint_venture"), false);
  const termination = legal.find((decision) =>
    decision.parameters?.mode === "terminate_joint_venture" &&
    decision.parameters.contractId === 1
  );
  assert.ok(termination);
  match.applyResolution(0, termination);
  assert.equal(match.contracts.length, match.config.sharedSupply.jointVenturePairs - 1);
  assert.equal(player.jointVentures.some((venture) => venture.contractId === 1), false);
  assert.equal(partner.jointVentures.some((venture) => venture.contractId === 1), false);

  match.megaClusters = Array.from(
    { length: match.config.sharedSupply.megaClusterPairs },
    (_, index) => ({ id: `mega-${index + 1}` })
  );
  assert.deepEqual(match.legalResolutions(0, "build").filter(choice => choice.parameters.project?.id === "mega_cluster"), []);
});

test("Foundry starting Compute is an explicit one-lever rules variant", async () => {
  const canonical = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "foundry",
      seed: "foundry-compute-canonical"
    },
    () => {}
  );
  const probe = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "foundry",
      seed: "foundry-compute-probe",
      rulesVariant: { foundryStartingCompute: 3 }
    },
    () => {}
  );
  assert.equal(canonical.match.players[0].compute, 4);
  assert.equal(probe.match.players[0].compute, 3);
  assert.ok(canonical.match.players[0].metrics.mandateEvents.some((event) =>
    event.source === "trust-2" && event.points === 2
  ));
  assert.equal(
    canonical.match.rulesVariant.foundryShovelsPerRound,
    undefined
  );
});

test("Safety setup probes derive Mandate from Trust without an Emergency Pause ability", async () => {
  const game = await createInteractiveGame({
    playerCount: 3,
    factionId: "safety_laboratory",
    seed: "safety-study-variants",
    rulesVariant: {
      safetyStartingTrust: 3
    }
  }, () => {});
  const safety = game.match.players[0];
  assert.equal(safety.trust, 3);
  assert.equal(safety.mandate, 2, "setup Mandate follows the Trust threshold");
  game.match.round = 4;
  safety.runway = 3;
  assert.equal(game.match.rulesVariant.safetyEmergencyPauseEnabled, undefined);
  assert.equal(game.match.hasFactionAbility(safety, "emergency_pause"), false);
});

test("late Capability Mandate is an explicit one-lever rules variant", async () => {
  const canonical = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "late-capability-canonical"
    },
    () => {}
  );
  const probe = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "late-capability-probe",
      rulesVariant: { lateCapabilityThresholdMandate: 1 }
    },
    () => {}
  );
  for (const game of [canonical.match, probe.match]) {
    game.players[0].capability = 12;
    game.synchronizePublicMandate(game.players[0], "fixture");
  }
  assert.equal(canonical.match.players[0].mandate, 10);
  assert.equal(probe.match.players[0].mandate, 8);
  assert.deepEqual(
    probe.match.players[0].mandateAwards
      .filter((award) => award.id.startsWith("capability-"))
      .map((award) => [award.id, award.points]),
    [
      ["capability-3", 2],
      ["capability-6", 2],
      ["capability-9", 1],
      ["capability-12", 1]
    ]
  );
});

test("uniform Capability Mandate is an explicit one-lever rules variant", async () => {
  const probe = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "uniform-capability-probe",
      rulesVariant: { capabilityThresholdMandate: 1 }
    },
    () => {}
  );
  probe.match.players[0].capability = 12;
  probe.match.synchronizePublicMandate(probe.match.players[0], "fixture");
  assert.equal(probe.match.players[0].mandate, 6);
  assert.deepEqual(
    probe.match.players[0].mandateAwards
      .filter((award) => award.id.startsWith("capability-"))
      .map((award) => [award.id, award.points]),
    [
      ["capability-3", 1],
      ["capability-6", 1],
      ["capability-9", 1],
      ["capability-12", 1]
    ]
  );
});

test("Customer Mandate is an explicit one-lever rules variant", async () => {
  const probe = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "platform_empire",
      seed: "customer-mandate-probe",
      rulesVariant: { customerMandate: 1 }
    },
    () => {}
  );
  assert.equal(probe.match.players[0].customers, 1);
  assert.equal(
    probe.match.players[0].mandateAwards.find((award) => award.id === "customer-1").points,
    1
  );
  assert.equal(probe.match.players[0].mandate, 3);
});

test("canonical Customer recognition diminishes only for the fourth and fifth Customer", async () => {
  const canonical = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "platform_empire",
      seed: "customer-mandate-schedule-canonical"
    },
    () => {}
  );
  canonical.match.players[0].customers = 5;
  canonical.match.synchronizePublicMandate(
    canonical.match.players[0],
    "fixture"
  );
  assert.deepEqual(
    canonical.match.players[0].mandateAwards
      .filter((award) => award.id.startsWith("customer-"))
      .map((award) => [award.id, award.points]),
    [
      ["customer-1", 2],
      ["customer-2", 2],
      ["customer-3", 2],
      ["customer-4", 1],
      ["customer-5", 1]
    ]
  );

  const legacy = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "platform_empire",
      seed: "customer-mandate-schedule-legacy",
      rulesVariant: legacyPrePromotionRulesOverlay
    },
    () => {}
  );
  legacy.match.players[0].customers = 5;
  legacy.match.synchronizePublicMandate(legacy.match.players[0], "fixture");
  assert.deepEqual(
    legacy.match.players[0].mandateAwards
      .filter((award) => award.id.startsWith("customer-"))
      .map((award) => [award.id, award.points]),
    [
      ["customer-1", 2],
      ["customer-2", 2],
      ["customer-3", 2],
      ["customer-4", 2],
      ["customer-5", 2]
    ]
  );
  assert.equal(canonical.match.players[0].customers, 5);
  assert.equal(canonical.match.players[0].runway, 4);
});

test("faction starting Compute probes are isolated rules variants", async () => {
  const imperial = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "imperial_research_lab",
      seed: "imperial-starting-compute-probe",
      rulesVariant: { imperialStartingCompute: 2 }
    },
    () => {}
  );
  const vertical = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "vertical_empire",
      seed: "vertical-starting-compute-probe",
      rulesVariant: { verticalStartingCompute: 4 }
    },
    () => {}
  );
  assert.equal(imperial.match.players[0].compute, 2);
  assert.equal(imperial.match.rulesVariant.verticalStartingCompute, null);
  assert.equal(vertical.match.players[0].compute, 4);
  assert.equal(vertical.match.rulesVariant.imperialStartingCompute, null);
});

test("faction mechanism probes remain isolated from canonical play", async () => {
  const coalition = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "coalition-starting-runway-probe",
      rulesVariant: { coalitionStartingRunway: 7 }
    },
    () => {}
  );
  assert.equal(coalition.match.players[0].runway, 7);
  await assert.rejects(createInteractiveGame({ playerCount: 3, rulesVariant: { verticalIndustrialVelocityBuildModes: ["facility", "generator"] } }, () => {}), /Unsupported rules option/);

});







test("offline Facility penalties cannot reduce final Mandate below zero", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "offline-score-floor"
    },
    () => {}
  );
  const player = match.players[0];
  const tile = match.board.find((candidate) => candidate.category !== "frontier");
  player.mandate = 0;
  player.facilities = [{
    id: "offline-facility",
    tileId: tile.instanceId,
    category: tile.category,
    powered: false
  }];
  player.facilities.unshift({id: "starter", tileId: tile.instanceId, category: tile.category});
  const standing = match.result().standings.find((entry) => entry.seat === 0);
  assert.equal(standing.offlinePenalty, 1);
  assert.equal(standing.score, 0);
});


test("Talent production reassigns one Agent anywhere without an Action, visit bonus, or payment", async () => {
  const { match } = await createInteractiveGame({ playerCount: 3, seed: "talent-production" }, () => {});
  const [player, rival] = match.players;
  const government = match.board.find(tile => tile.category === "government");
  const capital = match.board.find(tile => tile.category === "capital");
  player.pieces[0].tileId = government.instanceId;
  rival.pieces[0].tileId = capital.instanceId;
  const before = { runway: player.runway, compute: player.compute, capability: player.capability,
    trust: player.trust, actions: [...player.actionsUsed], cycle: match.cycle, other: structuredClone(player.pieces[1]) };
  let calls = 0;
  match.choose = async (_policies, seat, stage, choices) => {
    calls++;
    assert.equal(seat, player.seat);
    assert.equal(stage, "talent_assignment");
    assert.equal(choices.length, player.pieces.length * match.board.length);
    assert.ok(choices.some(choice => choice.parameters.pieceId === player.pieces[0].id &&
      choice.parameters.destinationId === government.instanceId), "staying is legal");
    return choices.find(choice => choice.parameters.pieceId === player.pieces[0].id &&
      choice.parameters.destinationId === capital.instanceId);
  };
  await match.produceFacility([], player, { id: "talent", category: "talent" });
  assert.equal(calls, 1);
  assert.equal(player.pieces[0].tileId, capital.instanceId);
  assert.equal(match.districtController(government.instanceId), null);
  assert.equal(match.districtController(capital.instanceId), null, "rival presence can coexist");
  assert.deepEqual({ runway: player.runway, compute: player.compute, capability: player.capability,
    trust: player.trust, actions: player.actionsUsed, cycle: match.cycle, other: player.pieces[1] }, before);
});

test("only connected Talent Facilities reassign Agents during Production", async () => {
  const { match } = await createInteractiveGame({ playerCount: 3, seed: "talent-power" }, () => {});
  const player = match.players[0];
  const talent = match.board.find(tile => tile.category === "talent");
  const cloud = match.board.find(tile => tile.category === "cloud");
  player.facilities = [
    { id: "facility-1", tileId: cloud.instanceId, category: "cloud" },
    { id: "facility-2", tileId: talent.instanceId, category: "talent" }
  ];
  match.choose = async () => { throw new Error("Offline Talent cannot reassign"); };
  await match.produceAll([]);
  player.facilities = [player.facilities[1]];
  let assignments = 0;
  match.choose = async (_policies, _seat, stage, choices) => {
    assert.equal(stage, "talent_assignment"); assignments++;
    return choices.find(choice => player.pieces.find(piece => piece.id === choice.parameters.pieceId)
      .tileId === choice.parameters.destinationId);
  };
  const before = structuredClone(player.pieces);
  await match.produceAll([]);
  assert.equal(assignments, 1);
  assert.deepEqual(player.pieces, before, "a player can leave the assignment unchanged");
});

test("LLM decision packets expose the public table without simulation-only state", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "private-visibility-contract" },
    () => {}
  );
  for (let index = 0; index < 9; index += 1) {
    match.recordEvent("headline_revealed", null, `Public event ${index}.`);
  }
  match.recordEvent("strategy_decision", 1, "A concealed simultaneous choice.");
  const packet = match.packet(0, "visibility_inspection", [{
    decisionId: "inspection_pass",
    label: "Pass inspection",
    actionId: "inspection"
  }]);
  const prompt = buildDecisionPrompt(packet);
  const opponent = packet.observation.opponents[0];
  const opponentCeo = match.players[opponent.seat].pieces.find((piece) => piece.kind === "agent");

  assert.equal(packet.policySeed, "private-visibility-contract");
  assert.equal(packet.seed, undefined);
  assert.doesNotMatch(prompt, /private-visibility-contract/);
  assert.doesNotMatch(prompt, /profileId/);
  assert.equal(opponent.profileId, undefined);
  assert.equal(packet.observation.publicTable.players[opponent.seat].objectiveId, undefined);
  assert.equal(packet.observation.publicTable.players[opponent.seat].tactics, undefined);
  assert.equal(
    opponent.researchProtection,
    match.players[opponent.seat].researchProtection
  );
  assert.deepEqual(opponent.pieces, match.players[opponent.seat].pieces);
  assert.ok(packet.observation.board.some((tile) =>
    tile.components.some((component) => component.id === opponentCeo.id)
  ));
  assert.deepEqual(
    packet.observation.publicTable.contracts,
    match.contracts
  );
  assert.ok(packet.publicHistory.length >= 10);
  assert.ok(packet.publicHistory.some((event) => event.summary === "Public event 0."));
  assert.ok(!packet.publicHistory.some((event) => event.type === "strategy_decision"));
});

test("Ownership Headline lets the affected player choose the producing Facility", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "ownership-facility-choice" },
    () => {}
  );
  match.round = 3;
  match.cycle = 1;
  const player = match.players[0];
  const cloud = match.board.find((tile) => tile.category === "cloud");
  const capital = match.board.find((tile) => tile.category === "capital");
  player.facilities = [
    {
      id: "cloud-fixture",
      tileId: cloud.instanceId,
      category: "cloud",
      powered: true
    },
    {
      id: "capital-fixture",
      tileId: capital.instanceId,
      category: "capital",
      powered: true
    }
  ];
  player.generators = [{id:"g",tileId:capital.instanceId,sourceId:"clean_infrastructure"}];
  player.capability = 0;
  match.players[1].capability = 4;
  const headline = match.headlineDocument.headlines.find(
    (candidate) => candidate.id === "weights_on_internet"
  );
  match.headlineDecks[3][0] = headline;
  let captured;
  match.choose = async (_policies, seat, stage, decisions) => {
    if (stage === "headline_weights_on_internet_facility") {
      captured = { seat, stage, decisions };
      return decisions.find(
        (decision) => decision.parameters.facilityId === "capital-fixture"
      );
    }
    return decisions[0];
  };
  const runwayBefore = player.runway;

  await match.prepareHeadline([]);

  assert.equal(captured.seat, 0);
  assert.ok(captured.decisions.length >= 2);
  assert.ok(captured.decisions.some(
    (decision) => decision.parameters.facilityId === "cloud-fixture"
  ));
  assert.ok(captured.decisions.some(
    (decision) => decision.parameters.facilityId === "capital-fixture"
  ));
  assert.equal(player.runway, runwayBefore + 2);
});

test("latest Production snapshot governs later powered and offline rules", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "production-snapshot-contract" },
    () => {}
  );
  const player = match.players[0];
  const first = match.board.find((tile) => tile.category === "cloud");
  const second = match.board.find((tile) => tile.category === "capital");
  player.facilities = [
    { id: "snapshot-powered", tileId: first.instanceId, category: "cloud", powered: false },
    { id: "snapshot-offline", tileId: second.instanceId, category: "capital", powered: true }
  ];
  player.latestProductionSnapshot = {
    round: 4,
    poweredFacilityIds: ["snapshot-powered"],
    offlineFacilityIds: ["snapshot-offline"],
    powerSupply: 1,
    powerDemandSatisfied: 1
  };

  assert.deepEqual(
    match.latestPoweredFacilities(player).map((facility) => facility.id),
    ["snapshot-powered"]
  );
  assert.deepEqual(
    match.latestOfflineFacilities(player).map((facility) => facility.id),
    ["snapshot-offline"]
  );
  assert.equal(match.finalMandate(player).offlinePenalty, 1);
});

test("powered Facility Mandate probe scores only the latest Production snapshot", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      seed: "powered-facility-mandate-probe",
      rulesVariant: { finalPoweredFacilityMandate: 1 }
    },
    () => {}
  );
  const player = match.players[0];
  const first = match.board.find((tile) => tile.category === "cloud");
  const second = match.board.find((tile) => tile.category === "capital");
  player.mandate = 5;
  player.facilities = [
    { id: "probe-powered", tileId: first.instanceId, category: "cloud", powered: false },
    { id: "probe-offline", tileId: second.instanceId, category: "capital", powered: true }
  ];
  player.latestProductionSnapshot = {
    round: 4,
    poweredFacilityIds: ["probe-powered"],
    offlineFacilityIds: ["probe-offline"],
    powerSupply: 1,
    powerDemandSatisfied: 1
  };

  assert.deepEqual(match.finalMandate(player), {
    score: 5,
    poweredFacilityMandate: 1,
    offlinePenalty: 1
  });
});


test("Frontier never contributes control to category Mandates", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "frontier-control-exception" },
    () => {}
  );
  assert.equal(match.controlledCategories(match.players[0]).has("frontier"), false);
});

test("immediate exchanges are exactly one-for-one across Runway and Compute", async () => {
  const runtime = await createInteractiveGame(
    { playerCount: 3, factionId: "coalition_lab", seed: "same-type-exchange" },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const match = runtime.match;
  const player = match.players[0];
  const partner = match.players[1];
  player.runway = 2;
  partner.runway = 1;
  partner.compute = 1;
  assert.ok(match.immediateTradeOffers(0, "before").every((offer) =>
    offer.giveResource !== offer.receiveResource &&
    offer.giveAmount === 1 &&
    offer.receiveAmount === 1
  ));
  assert.equal(match.completeImmediateTrade(player.seat, partner.seat, {
    timing: "before",
    partnerSeat: partner.seat,
    giveResource: "runway",
    giveAmount: 1,
    receiveResource: "runway",
    receiveAmount: 1
  }), false);
  assert.equal(player.runway, 2);
  assert.equal(partner.runway, 1);
  assert.equal(player.roundMetrics.dealFlowUsed, undefined);
  assert.equal(player.metrics.factionAbilityValues.deal_flow, undefined);
});


test("Influence Joint Venture proposals use the acting destination Facility", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "influence-destination-host" },
    () => {}
  );
  match.round = 3;
  const player = match.players[0];
  const rival = match.players[1];
  const destination = match.board.find((tile) => tile.category === "frontier");
  const adjacent = match.board.find((tile) =>
    tile.instanceId !== destination.instanceId && match.areAdjacent(destination.instanceId, tile.instanceId)
  );
  const elsewhere = match.board.find((tile) =>
    tile.category !== "frontier" && tile.instanceId !== adjacent.instanceId
  );
  player.facilities = [
    { id: "destination-host", tileId: destination.instanceId, category: "frontier", powered: false },
    { id: "elsewhere-host", tileId: elsewhere.instanceId, category: elsewhere.category, powered: false }
  ];
  rival.facilities = [
    { id: "rival-host", tileId: adjacent.instanceId, category: adjacent.category, powered: false }
  ];
  const proposals = match.legalResolutions(0, "influence")
    .filter((decision) => decision.parameters?.mode === "joint_venture");
  assert.ok(proposals.length > 0);
  assert.ok(proposals.every((decision) =>
    player.facilities.find((facility) => facility.id === decision.parameters.leftFacilityId)
      .tileId === decision.parameters.destinationId
  ));
});

test("removed Build discounts cannot create otherwise unaffordable Builds", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "optional-build-discount" },
    () => {}
  );
  const player = match.players[0];
  match.round = 2;
  player.runway = 0;

  const decisions = match.legalResolutions(0, "build");
  assert.ok(decisions.every((decision) => !Object.hasOwn(
    decision.parameters,
    "useBuildDiscount"
  )));
  assert.ok(decisions.every((decision) =>
    !decision.parameters.facility
  ));
});

test("removed Market Access cannot lower a Deploy requirement", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "optional-market-access" },
    () => {}
  );
  const player = match.players[0];
  player.compute = 10;
  player.customers = 0;
  player.capability = 1;

  const requiredDecisions = match.legalResolutions(0, "deploy");
  assert.equal(requiredDecisions.length, 0);

  player.capability = 2;
  const legal = match.legalResolutions(0, "deploy");
  assert.ok(legal.length > 0);
  assert.ok(legal.every((decision) => !Object.hasOwn(
    decision.parameters,
    "useMarketAccess"
  )));

  match.applyResolution(0, legal[0]);
  assert.equal(player.customers, 1);
});

test("Research Protection is never a tradable resource", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "safety_laboratory",
      seed: "receiver-safety-cap"
    },
    () => {}
  );
  const safetyLab = match.players[0];
  const ordinaryInstitution = match.players[1];
  safetyLab.runway = 1;
  safetyLab.compute = 1;
  ordinaryInstitution.runway = 1;
  ordinaryInstitution.compute = 1;
  assert.ok(!Object.hasOwn(match.config.resources, "researchProtection"));
  for (const [giver, receiver] of [
    [safetyLab, ordinaryInstitution],
    [ordinaryInstitution, safetyLab]
  ]) {
    assert.deepEqual(match.tradableResources(giver, receiver).sort(), ["compute", "runway"]);
  }
});

test("recruiting reuses the actual missing Team identity without duplicates", async () => {
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "team-identity-reuse" },
    () => {}
  );
  const player = match.players[0];
  const frontier = match.board.find((tile) => tile.category === "frontier");
  player.pieces = [
    { id: "s0-agent-4", kind: "agent", tileId: frontier.instanceId },
    { id: "s0-agent-1", kind: "agent", tileId: frontier.instanceId },
    { id: "s0-agent-3", kind: "agent", tileId: frontier.instanceId }
  ];
  player.agentsInSupply = 1;

  match.applyResolution(0, {
    decisionId: "recruit-missing-team",
    label: "Recruit the missing Team",
    actionId: "organize",
    parameters: {
      mode: "recruit",
      count: 1,
      cost: 0,
      pieceId: "s0-agent-1",
      destinationId: frontier.instanceId
    },
    consequences: { teams: 1 }
  });

  const agentIds = player.pieces
    .filter((piece) => piece.kind === "agent")
    .map((piece) => piece.id);
  assert.deepEqual(agentIds.sort(), [
    "s0-agent-1",
    "s0-agent-2",
    "s0-agent-3",
    "s0-agent-4"
  ]);
  assert.equal(new Set(agentIds).size, agentIds.length);
  assert.equal(player.agentsInSupply, 0);
});

test("AGI achievement readiness is pure, diagnostic, and UI-ready", async () => {
 const {match}=await createInteractiveGame({playerCount:3,seed:"agi-readiness"},()=>{});
 const player = match.players[0];
 const anchor = match.board.find(tile => tile.category === "energy");
 const neighbor = match.board.find(tile => match.areAdjacent(anchor.instanceId,tile.instanceId));
 player.facilities = [anchor,neighbor].map((tile,index)=>({id:`f${index}`,tileId:tile.instanceId,category:tile.category}));
 player.generators = [{id:"g",tileId:anchor.instanceId,sourceId:"clean_infrastructure"}];
 player.capability=9; player.trust=4; player.compute=3;
 const before=structuredClone(player);
 assert.deepEqual(match.declarationReadiness(player),{ready:true,failingRequirement:null,values:{capability:9,poweredFacilities:2,trust:4,compute:3},requirements:{capability:9,poweredFacilities:2,trust:4,compute:3},recognized:false});
 assert.deepEqual(player,before);
 player.compute=2; assert.equal(match.declarationReadiness(player).failingRequirement,"compute");
});

test("Public recognition reaches eligibility and declaration bookkeeping", async () => {
 const {match}=await createInteractiveGame({playerCount:3,seed:"agi-bookkeeping"},()=>{});
 const player = match.players[0];
 const anchor = match.board.find(tile => tile.category === "energy");
 const neighbor = match.board.find(tile => match.areAdjacent(anchor.instanceId,tile.instanceId));
 player.facilities = [anchor,neighbor].map((tile,index)=>({id:`f${index}`,tileId:tile.instanceId,category:tile.category}));
 player.generators = [{id:"g",tileId:anchor.instanceId,sourceId:"clean_infrastructure"}];
 player.capability=9; player.trust=4; player.compute=3;
 match.round=4;
 match.choose=async(_p,_s,_stage,choices)=>choices.find(choice=>choice.decisionId==="agi_declare");
 await match.declareAgiAchievements([]);
 assert.equal(player.metrics.earliestAgiEligibility.timing,"after_era_iv_production");
 assert.equal(player.agiDeclared,true); assert.equal(player.compute,0);
 assert.equal(match.matchMetrics.declarations,1);
});

test("Recognized AGI selects the World Ending while Mandate selects the winner", async () => {
 const {match}=await createInteractiveGame({playerCount:3,seed:"agi-no-override"},()=>{});
 match.players[0].mandate=18; match.players[1].mandate=15; match.players[2].mandate=12;
 match.players[1].agiDeclared=true;
 match.resolveAgiOutcome();
 assert.equal(match.matchMetrics.agiResolution.method,"scored-achievement");
 assert.deepEqual(match.matchMetrics.agiResolution.claimantSeats,[1]);
 assert.equal(match.matchMetrics.agiResolution.winnerOverridden,false);
 assert.deepEqual(match.result().winnerSeats,[0]);
 assert.equal(match.result().worldEnding.agiEmerges,true);
});

test("Production recalculates powered Facilities without persistent Grid-Ready state", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      seed: "grid-ready-lifecycle"
    },
    () => {}
  );
  match.round = 2;
  const player = match.players[0];
  player.capability = 9;
  player.customers = 3;
  player.trust = 4;
  player.compute = 4;
  const anchor = match.board.find((tile) => tile.category !== "frontier");
  const sites = [
    anchor,
    ...match.board.filter((tile) =>
      tile.category !== "frontier" &&
      tile.instanceId !== anchor.instanceId &&
      match.areAdjacent(anchor.instanceId, tile.instanceId)
    ).slice(0, 2)
  ];
  player.facilities = sites.map((tile, index) => ({
    id: `s0-facility-${index + 1}`,
    tileId: tile.instanceId,
    category: tile.category,
      powered: false
  }));
  player.generators = [{
    id: "s0-generator-1",
    tileId: sites[0].instanceId,
    sourceId: "clean_infrastructure",
    capacity: 2
  }];
  player.runway = 10;
  for (const rival of match.players.slice(1)) {
    rival.facilities = [];
    rival.generators = [];
  }

  const policies = match.players.map((candidate) => ({
    async decide(packet) {
      const decisions = packet.legalDecisions;
      const selected = [...decisions].sort((left, right) =>
        (right.consequences?.poweredFacilities || 0) -
          (left.consequences?.poweredFacilities || 0) ||
        (right.consequences?.power || 0) - (left.consequences?.power || 0)
      )[0];
      return {
        decision: {
          decisionId: selected.decisionId,
          rationale: "Maximize demonstrated operating capacity."
        },
        receipt: {
          provider: "test",
          profileId: candidate.profileId,
          requestId: packet.requestId
        }
      };
    }
  }));

  await match.produceAll(policies);
  assert.equal(player.latestProductionSnapshot.poweredFacilityIds.length, 3);
  assert.equal(player.facilities.filter((facility) => facility.powered).length, 3);
  assert.ok(player.facilities.every((facility) => !("gridReady" in facility)));
  assert.ok(match.matchMetrics.agiFunnel[0].coreRequirementsMet);

  const currentTile = match.board.find(
    (tile) => tile.instanceId === player.facilities[0].tileId
  );
  const destination = match.board.find(
    (tile) =>
      tile.instanceId !== currentTile.instanceId &&
      Math.max(
        Math.abs(tile.q - currentTile.q),
        Math.abs(tile.r - currentTile.r),
        Math.abs((-tile.q - tile.r) - (-currentTile.q - currentTile.r))
      ) === 1
  );
  match.applyResolution(0, {
    decisionId: "move-preserves-no-power-state",
    label: "Move the first Facility",
    actionId: "organize",
    parameters: {
      mode: "relocate",
      facilityId: player.facilities[0].id,
      pieceId: player.pieces[0].id,
      destinationId: player.facilities[0].tileId,
      destinationCategory: player.facilities[0].category,
      facilityDestinationId: destination.instanceId
    },
    consequences: { relocateFacility: true }
  });
  assert.equal(player.facilities[0].powered, true);
  assert.ok(!("gridReady" in player.facilities[0]));
});


test("pre-Act offers cannot make the selected action illegal", async () => {
  const runtime = await createInteractiveGame(
    { playerCount: 4, seed: "preserve-selected-action" },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const match = runtime.match;
  const player = match.players[0];
  const partner = match.players[1];

  player.selectedAction = "research";
  player.compute = 2;
  partner.compute = 0;
  assert.deepEqual(
    match.immediateTradeGiveAmounts(0, partner, "compute"),
    [1]
  );
  assert.ok(match.immediateTradeDecisions(0, "before")
    .filter((decision) => decision.parameters?.giveResource === "compute")
    .every((decision) => match.provisionalTradeResolvesSelection(
      0,
      decision.parameters,
      "research"
    )));
  player.compute = 1;
  assert.deepEqual(
    match.immediateTradeGiveAmounts(0, partner, "compute"),
    [1]
  );
  assert.ok(match.immediateTradeDecisions(0, "before")
    .filter((decision) => decision.parameters)
    .every((decision) => match.provisionalTradeResolvesSelection(
      0,
      decision.parameters,
      "research"
    )));
  partner.selectedAction = "research";
  partner.compute = 1;
  assert.deepEqual(
    match.immediateTradeReceiveAmounts(0, partner, "compute"),
    [1]
  );


});

test("immediate trades skip impossible turns and package each offer", async () => {
  const runtime = await createInteractiveGame(
    { playerCount: 4, seed: "packed-immediate-trade" },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const match = runtime.match;
  for (const player of match.players) {
    player.runway = 0;
    player.compute = 0;
  }
  const unavailablePolicies = match.players.map(() => ({
    async decide() {
      throw new Error("An impossible trade must not create a decision packet.");
    }
  }));
  assert.equal(await match.chooseImmediateTrade(unavailablePolicies, 0, "before"), null);

  const player = match.players[0];
  const partner = match.players[1];
  player.runway = 2;
  partner.compute = 1;
  const stages = [];
  const policies = match.players.map(() => ({
    async decide(packet) {
      const stage = packet.requestId.split(":").at(-2);
      stages.push(stage);
      const selected = stage === "immediate_trade_response"
        ? packet.legalDecisions.find((decision) => decision.decisionId === "trade_accept")
        : packet.legalDecisions.find((decision) =>
          decision.decisionId.startsWith("trade_offer_")
        );
      return {
        decision: { decisionId: selected.decisionId },
        receipt: { provider: "fixture" }
      };
    }
  }));
  const offer = await match.chooseImmediateTrade(policies, player.seat, "before");
  assert.deepEqual(stages, ["immediate_trade_before"]);
  assert.ok(offer);
  assert.equal(offer.partnerSeat, partner.seat);
  const resourcesBeforeTrade = match.players.map((candidate) => ({
    runway: candidate.runway,
    compute: candidate.compute
  }));
  assert.equal(await match.settleImmediateTrade(policies, player.seat, offer), true);
  assert.deepEqual(stages, ["immediate_trade_before", "immediate_trade_response"]);
  for (const resource of ["runway", "compute"]) {
    const dealFlowBonus = resource === "runway" && player.factionId === "coalition_lab" ? 1 : 0;
    assert.equal(
      player[resource],
      resourcesBeforeTrade[player.seat][resource]
        - (offer.giveResource === resource ? offer.giveAmount : 0)
        + (offer.receiveResource === resource ? offer.receiveAmount : 0)
        + dealFlowBonus
    );
    const partnerDealFlowBonus =
      resource === "runway" && partner.factionId === "coalition_lab" ? 1 : 0;
    assert.equal(
      partner[resource],
      resourcesBeforeTrade[partner.seat][resource]
        + (offer.giveResource === resource ? offer.giveAmount : 0)
        - (offer.receiveResource === resource ? offer.receiveAmount : 0)
        + partnerDealFlowBonus
    );
  }
});

test("Deal Flow can be paused without suppressing the underlying trade", async () => {
  const runtime = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "paused-deal-flow",
      rulesVariant: {
        pausedFactionAbilities: [{
          factionId: "coalition_lab",
          abilityId: "deal_flow"
        }]
      }
    },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const match = runtime.match;
  const coalition = match.players[0];
  const partner = match.players[1];
  coalition.runway = 2;
  coalition.compute = 0;
  partner.runway = 0;
  partner.compute = 1;

  assert.equal(match.completeImmediateTrade(coalition.seat, partner.seat, {
    timing: "before",
    partnerSeat: partner.seat,
    giveResource: "runway",
    giveAmount: 1,
    receiveResource: "compute",
    receiveAmount: 1
  }), true);
  assert.equal(coalition.runway, 1);
  assert.equal(coalition.compute, 1);
  assert.equal(partner.runway, 1);
  assert.equal(partner.compute, 0);
  assert.equal(coalition.roundMetrics.dealFlowUsed, undefined);
  assert.equal(coalition.metrics.factionAbilityValues.deal_flow, undefined);
});

test("immediate-trade packet ceiling is rule-derived and formal windows cannot repeat", async () => {
  assert.deepEqual(
    [2, 3, 4, 5, 6].map((playerCount) => immediateTradePacketCeiling(playerCount)),
    [48, 72, 96, 120, 144]
  );
  assert.throws(
    () => immediateTradePacketCeiling(4, { counteroffers: true }),
    /forbids counteroffers and claims/
  );
  assert.throws(
    () => immediateTradePacketCeiling(4, {
      counteroffers: true,
      thirdPartyClaims: true
    }),
    /forbids counteroffers and claims/
  );
  const { match } = await createInteractiveGame(
    { playerCount: 3, seed: "immediate-trade-window-ledger" },
    () => {}
  );
  match.activeImmediateTradeSeat = 0;
  match.registerImmediateTradeDecisionWindow(1, "immediate_trade_response");
  assert.throws(
    () => match.registerImmediateTradeDecisionWindow(1, "immediate_trade_response"),
    /formal window repeated/
  );
  assert.equal(match.immediateTradePackets, 1);
  assert.equal(match.immediateTradePacketCeiling, 72);
});

test("rejected immediate trades end without counteroffers or claims", async () => {
  const runtime = await createInteractiveGame(
    {
      playerCount: 4,
      seed: "open-counteroffer"
    },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const match = runtime.match;
  for (const player of match.players) {
    player.runway = 0;
    player.compute = 0;
  }
  const active = match.players[0];
  const counterMaker = match.players[1];
  active.runway = 2;
  counterMaker.compute = 1;
  const stages = [];
  const policies = match.players.map(() => ({
    async decide(packet) {
      const stage = packet.requestId.split(":").at(-2);
      stages.push(stage);
      const selected = stage === "immediate_trade_response"
        ? packet.legalDecisions.find((decision) => decision.decisionId === "trade_reject")
        : packet.legalDecisions.find((decision) =>
          decision.decisionId.startsWith("trade_offer_")
        );
      return {
        decision: { decisionId: selected.decisionId },
        receipt: { provider: "fixture" }
      };
    }
  }));
  const offer = await match.chooseImmediateTrade(policies, active.seat, "before");
  assert.ok(offer);
  assert.equal(await match.settleImmediateTrade(policies, active.seat, offer), false);
  assert.deepEqual(stages, [
    "immediate_trade_before",
    "immediate_trade_response"
  ]);
  assert.equal(active.runway, 2);
  assert.equal(active.compute, 0);
  assert.equal(counterMaker.runway, 0);
  assert.equal(counterMaker.compute, 1);
});

test("counteroffer and third-party-claim overlays fail closed", async () => {
  await assert.rejects(
    createInteractiveGame({
      playerCount: 2,
      seed: "forbidden-counteroffer",
      rulesVariant: { immediateTradeCounteroffers: true }
    }, () => {}),
    /forbids counteroffers and claims/
  );
  await assert.rejects(
    createInteractiveGame({
      playerCount: 2,
      seed: "forbidden-claims",
      rulesVariant: { immediateTradeThirdPartyClaims: true }
    }, () => {}),
    /forbids counteroffers and claims/
  );
});

test("interactive games accept mixed per-opponent personas and decision backends", async () => {
  const runtime = await createInteractiveGame(
    {
      playerCount: 4,
      seed: "mixed-interactive-backends",
      opponentProfileIds: [
        "power_broker",
        "trust_governor",
        "capability_rusher"
      ],
      opponentBackends: ["greedy", "claude", "hybrid-codex"],
      allowLlm: true,
      maxLlmDecisions: 7,
      model: "test-model"
    },
    () => {}
  );
  assert.deepEqual(
    runtime.opponents.map((opponent) => opponent.profile.id),
    ["power_broker", "trust_governor", "capability_rusher"]
  );
  assert.deepEqual(
    runtime.opponents.map((opponent) => opponent.backend),
    ["greedy", "claude", "hybrid-codex"]
  );
  assert.deepEqual(
    runtime.policies.map((policy) => policy.kind),
    ["human", "deterministic", "llm", "hybrid"]
  );
  assert.equal(runtime.opponents[0].decisionBudget, null);
  assert.equal(runtime.opponents[1].decisionBudget.remaining, 7);
  assert.equal(runtime.opponents[2].decisionBudget.remaining, 7);
  assert.notEqual(
    runtime.opponents[1].decisionBudget,
    runtime.opponents[2].decisionBudget
  );
  assert.equal(runtime.policies[2].caller.model, "test-model");
  assert.equal(runtime.policies[3].caller.model, "test-model");

  await assert.rejects(
    createInteractiveGame(
      {
        playerCount: 3,
        opponentBackends: ["weighted", "codex"],
        allowLlm: false
      },
      () => {}
    ),
    /explicit allowLlm authorization/
  );
  await assert.rejects(
    createInteractiveGame(
      {
        playerCount: 3,
        opponentBackends: ["weighted", "claude"],
        allowLlm: true,
        maxLlmDecisions: 25
      },
      () => {}
    ),
    /maxLlmDecisions must be an integer from 0 to 24/
  );
});

test("browser-native games use deterministic opponents without a server or LLM authorization", async () => {
  const runtime = await createBrowserInteractiveGame(
    {
      playerCount: 4,
      seed: "browser-native-deterministic",
      opponentProfileIds: [
        "power_broker",
        "trust_governor",
        "capability_rusher"
      ],
      opponentBackends: ["weighted", "greedy", "weighted"],
      allowLlm: false
    },
    () => {}
  );
  assert.deepEqual(
    runtime.opponents.map((opponent) => opponent.backend),
    ["weighted", "greedy", "weighted"]
  );
  assert.deepEqual(
    runtime.policies.map((policy) => policy.kind),
    ["human", "deterministic", "deterministic", "deterministic"]
  );
  let completingRuntime;
  completingRuntime = await createBrowserInteractiveGame(
    {
      playerCount: 3,
      seed: "browser-native-complete-match",
      opponentBackends: ["weighted", "greedy"]
    },
    (packet) => queueMicrotask(() => {
      completingRuntime.human.submit(packet.legalDecisions[0].decisionId);
    })
  );
  const result = await completingRuntime.match.play(completingRuntime.policies);
  assert.ok(result.worldEnding.name);
  assert.ok(completingRuntime.match.replay.length > 0);
  await assert.rejects(
    createBrowserInteractiveGame(
      {
        playerCount: 3,
        opponentBackends: ["weighted", "claude"],
        allowLlm: true
      },
      () => {}
    ),
    /requires the optional local bridge/
  );
});

test("deterministic policies preserve legal commitment while avoiding known dead actions", async () => {
  const profiles = await loadPlayerProfiles();
  const profile = profiles.find((candidate) => candidate.id === "capability_rusher");
  const policy = new WeightedPlayerPolicy(profile, { selection: "greedy" });
  const packet = {
    schemaVersion: 1,
    requestId: "known-dead-action",
    matchId: "match",
    seed: "known-dead-action",
    seat: 0,
    factionId: "imperial_research_lab",
    round: 1,
    cycle: 1,
    observation: { self: { compute: 0, canDeploy: false } },
    legalDecisions: [
      {
        decisionId: "select_research",
        label: "Select Research",
        actionId: "research",
        consequences: {
          stage: "action_selection",
          currentResolutionCount: 0,
          resolvableWithoutTrade: false
        }
      },
      {
        decisionId: "select_fund",
        label: "Select Fund",
        actionId: "fund",
        consequences: {
          stage: "action_selection",
          currentResolutionCount: 12,
          resolvableWithoutTrade: true
        }
      }
    ]
  };
  assert.equal((await policy.decide(packet)).decision.decisionId, "select_fund");
  assert.ok(
    policy.score(packet, packet.legalDecisions[0]) <
      policy.score(packet, packet.legalDecisions[1])
  );
});

test("greedy policy resolves equal utility without leaking lexicographic decision order", async () => {
  const profiles = await loadPlayerProfiles();
  const profile = profiles.find((candidate) => candidate.id === "infrastructure_compounder");
  const policy = new WeightedPlayerPolicy(profile, { selection: "greedy" });
  const decisions = [
    {
      decisionId: "agi_declare_benchmark_claim",
      label: "Commit",
      actionId: "agi",
      consequences: { agiClaim: 1, compute: -1, scrutiny: 1 }
    },
    {
      decisionId: "agi_pass_benchmark_claim",
      label: "Hedge",
      actionId: "agi",
      consequences: { agiClaim: 0 }
    }
  ];
  const selected = new Set();
  for (let index = 0; index < 64; index += 1) {
    const packet = {
      schemaVersion: 1,
      requestId: `dossier-tie-${index}`,
      matchId: "dossier-tie",
      seed: "dossier-tie",
      seat: 0,
      factionId: "coalition_lab",
      round: 1,
      cycle: 1,
      observation: { self: {} },
      legalDecisions: decisions
    };
    const first = await policy.decide(packet);
    const repeated = await policy.decide(packet);
    assert.equal(repeated.decision.decisionId, first.decision.decisionId);
    assert.equal(first.receipt.tiedTopCount, 2);
    selected.add(first.decision.decisionId);
  }
  assert.deepEqual(selected, new Set(decisions.map((decision) => decision.decisionId)));
});

test("Public AGI choice exposes one payment, reward, and Scrutiny consequence", async () => {
 const {match}=await createInteractiveGame({playerCount:3,seed:"agi-decision"},()=>{});
 const player = match.players[0];
 const anchor = match.board.find(tile => tile.category === "energy");
 const neighbor = match.board.find(tile => match.areAdjacent(anchor.instanceId,tile.instanceId));
 player.facilities = [anchor,neighbor].map((tile,index)=>({id:`f${index}`,tileId:tile.instanceId,category:tile.category}));
 player.generators = [{id:"g",tileId:anchor.instanceId,sourceId:"clean_infrastructure"}];
 player.capability=9; player.trust=4; player.compute=3;
 match.round=4; let captured;
 match.choose=async(_p,_s,stage,choices)=>{assert.equal(stage,"agi_achievement");captured=choices;return choices[0];};
 await match.declareAgiAchievements([]);
 assert.deepEqual(captured.map(choice=>choice.decisionId),["agi_pass","agi_declare"]);
 assert.deepEqual(captured[1].consequences,{compute:-3,mandate:4,scrutiny:2,agiDeclared:true});
 assert.equal(player.compute,3); assert.equal(player.agiDeclared,false);
});

test("AGI decisions only open for qualified institutions", async () => {
 const {match}=await createInteractiveGame({playerCount:3,seed:"agi-no-dead-claims"},()=>{});
 const player = match.players[0];
 const anchor = match.board.find(tile => tile.category === "energy");
 const neighbor = match.board.find(tile => match.areAdjacent(anchor.instanceId,tile.instanceId));
 player.facilities = [anchor,neighbor].map((tile,index)=>({id:`f${index}`,tileId:tile.instanceId,category:tile.category}));
 player.generators = [{id:"g",tileId:anchor.instanceId,sourceId:"clean_infrastructure"}];
 player.capability=9; player.trust=4; player.compute=3;
 match.round=4;player.compute=2;
 match.choose=async()=>{throw new Error("Unqualified institution has no declaration choice");};
 await match.declareAgiAchievements([]);assert.equal(match.matchMetrics.declarations,0);
});

test("deterministic personas execute partner, placement, and resource preferences", async () => {
  const profiles = await loadPlayerProfiles();
  const profile = profiles.find((candidate) => candidate.id === "agi_candidate");
  const policy = new WeightedPlayerPolicy(profile, {
    selection: "greedy",
    rosterProfileIds: ["agi_candidate", "power_broker", "balanced_operator"]
  });
  const packet = {
    observation: {
      self: { facilities: 0 },
      board: [
        {
          tileId: "target",
          q: 0,
          r: 0,
          components: [{ type: "piece", ownerSeat: 1 }]
        },
        { tileId: "near", q: 1, r: 0, components: [] },
        { tileId: "far", q: 3, r: 0, components: [] }
      ]
    }
  };
  const promiseCandidate = {
    decisionId: "negotiation_power_1",
    actionId: "negotiation",
    parameters: { targetSeat: 1 }
  };
  const ordinaryPromise = {
    decisionId: "negotiation_power_2",
    actionId: "negotiation",
    parameters: { targetSeat: 2 }
  };
  assert.equal(
    policy.score(packet, promiseCandidate),
    policy.score(packet, ordinaryPromise) * 12
  );

  const nearBuild = {
    decisionId: "build_facility_near",
    actionId: "build",
    parameters: { destinationId: "near" }
  };
  const farBuild = {
    decisionId: "build_facility_far",
    actionId: "build",
    parameters: { destinationId: "far" }
  };
  assert.equal(
    policy.score(packet, nearBuild),
    policy.score(packet, farBuild) * 12
  );

  const favorableComputeTrade = {
    decisionId: "trade_accept",
    actionId: "trade",
    parameters: {
      giveResource: "runway",
      giveAmount: 1,
      receiveResource: "compute",
      receiveAmount: 2
    }
  };
  const unfavorableComputeTrade = {
    ...favorableComputeTrade,
    parameters: {
      ...favorableComputeTrade.parameters,
      giveAmount: 2,
      receiveAmount: 1
    }
  };
  assert.ok(
    policy.score(packet, favorableComputeTrade) >
      policy.score(packet, unfavorableComputeTrade)
  );
});

test("Coalition conversion treatment prioritizes causally necessary Deal Flow spending", async () => {
  const profiles = await loadPlayerProfiles();
  const profile = profiles.find((candidate) => candidate.id === "balanced_operator");
  const baseline = new WeightedPlayerPolicy(profile, { selection: "greedy" });
  const treated = new WeightedPlayerPolicy(profile, {
    selection: "greedy",
    treatment: "coalition_conversion_v1"
  });
  const packet = {
    schemaVersion: 1,
    requestId: "coalition-conversion-treatment",
    matchId: "match",
    seed: "coalition-conversion-treatment",
    seat: 0,
    factionId: "coalition_lab",
    round: 2,
    cycle: 1,
    observation: {
      self: {
        runway: 1,
        dealFlowConversion: { unspentCredits: 1 }
      }
    },
    legalDecisions: [
      {
        decisionId: "build_facility_research_fixture",
        label: "Build Research Facility",
        actionId: "build",
        parameters: { buildMode: "facility", actualRunwayCost: 1 },
        consequences: { runway: -1, facility: "research" }
      },
      {
        decisionId: "influence_gain_trust_fixture",
        label: "Gain Trust",
        actionId: "influence",
        parameters: { mode: "trust" },
        consequences: { trust: 1 }
      }
    ]
  };
  const baselineBuild = baseline.score(packet, packet.legalDecisions[0]);
  const treatedBuild = treated.score(packet, packet.legalDecisions[0]);
  assert.equal(treatedBuild, baselineBuild * 4);
  assert.equal(
    treated.score(packet, packet.legalDecisions[1]),
    baseline.score(packet, packet.legalDecisions[1])
  );
  assert.throws(
    () => new WeightedPlayerPolicy(profile, { treatment: "unknown" }),
    /Unknown deterministic policy treatment/
  );
});

test("Deal Flow telemetry conservatively traces necessary spend into Mandate", async () => {
  const { match } = await createInteractiveGame(
    {
      playerCount: 3,
      factionId: "coalition_lab",
      seed: "deal-flow-conversion-telemetry"
    },
    () => {}
  );
  const player = match.players[0];
  player.runway = 2;
  assert.equal(match.grantDealFlowRunway(player, { fixture: true }), 1);
  match.beginRunwayConversionContext(player, {
    actionId: "build",
    decisionId: "fixture-build"
  });
  match.spendRunway(player, 2, {
    cause: "fixture_nonnecessary_build_spend",
    conversionEligible: true
  });
  assert.equal(player.metrics.dealFlowConversion.creditsSpent, 0);
  match.spendRunway(player, 1, {
    cause: "fixture_necessary_build_spend",
    conversionEligible: true
  });
  match.awardMandate(player, 2, "fixture_build_threshold");
  match.endRunwayConversionContext(player);
  assert.equal(player.metrics.dealFlowConversion.creditsGranted, 1);
  assert.equal(player.metrics.dealFlowConversion.creditsSpent, 1);
  assert.equal(
    player.metrics.dealFlowConversion.causallyNecessaryCreditsSpent,
    1
  );
  assert.equal(player.metrics.dealFlowConversion.mandateAttributed, 2);
  assert.deepEqual(
    player.metrics.dealFlowConversion.events.map((event) => ({
      decisionId: event.decisionId,
      necessary: event.causallyNecessaryCreditsSpent,
      mandate: event.mandateAttributed
    })),
    [{ decisionId: "fixture-build", necessary: 1, mandate: 2 }]
  );
});

test("ordinary successful Era I actions populate opening evidence exactly once", async () => {
  const runtime = await createInteractiveGame(
    { playerCount: 3, seed: "opening-evidence" },
    () => {}
  );
  await runtime.match.setup(runtime.policies);
  const player = runtime.match.players[0];
  const decision = runtime.match.legalResolutions(0, "fund")[0];
  runtime.match.applyResolution(0, decision);
  assert.deepEqual(player.metrics.openingActions, ["fund"]);
  assert.equal(player.metrics.actions.fund, 1);
});

test("mechanics fingerprints ignore faction and Headline presentation copy", () => {
  const firstPresentation = {
    factions: [{
      id: "coalition_lab",
      roleId: "faction-1",
      name: "Dovetalis Labs",
      motto: "Named wording",
      starts: { runway: 5 }
    }],
    headlines: [{
      id: "fixture_headline",
      name: "Named event",
      strapline: "INSTITUTIONAL FRAMING",
      newswire: "One account of the event.",
      quote: "A reassuring statement.",
      rulesLabel: "Regulatory",
      resolutionType: "DIRECTIVE"
    }]
  };
  const secondPresentation = {
    factions: [{
      id: "coalition_lab",
      roleId: "faction-1",
      name: "The Coalition Lab",
      motto: "Alias wording",
      starts: { runway: 5 }
    }],
    headlines: [{
      id: "fixture_headline",
      name: "Renamed event",
      strapline: "DIFFERENT INSTITUTIONAL FRAMING",
      newswire: "A different account of the event.",
      quote: "A different reassuring statement.",
      rulesLabel: "Directive",
      resolutionType: "DIRECTIVE"
    }]
  };
  assert.deepEqual(mechanicsProjection(firstPresentation), mechanicsProjection(secondPresentation));
});

test("four-player tournaments rotate through all six factions without duplicate seats", () => {
  const factions = ["a", "b", "c", "d", "e", "f"].map((id) => ({ id }));
  const appearances = new Set();
  const bySeat = Array.from({ length: 4 }, () => new Set());
  for (let run = 0; run < 24; run += 1) {
    const roster = factionRosterForRun(factions, 4, run);
    assert.equal(new Set(roster.map((faction) => faction.id)).size, 4);
    for (const [seat, faction] of roster.entries()) {
      appearances.add(faction.id);
      bySeat[seat].add(faction.id);
    }
  }
  assert.deepEqual([...appearances].sort(), ["a", "b", "c", "d", "e", "f"]);
  assert.ok(bySeat.every((ids) => ids.size === factions.length));
});

test("explicit faction rosters preserve paired diagnostic seats and identity", async () => {
  const factionIds = [
    "imperial_research_lab",
    "platform_empire",
    "safety_laboratory",
    "foundry"
  ];
  const report = await createSimulation({
    runs: 2,
    playerCount: 4,
    seed: "explicit-faction-roster",
    sampleReplays: 0,
    factionIds,
    rotateFactions: false,
    profileIds: [
      "capability_rusher",
      "balanced_operator",
      "trust_governor",
      "power_broker"
    ],
    backends: ["weighted"],
    includeObservations: true
  });
  assert.deepEqual(report.configuration.factionIds, factionIds);
  assert.deepEqual(
    report.observations[0].standings
      .sort((left, right) => left.seat - right.seat)
      .map((standing) => standing.factionId),
    factionIds
  );
  assert.match(report.experiment.configurationFingerprint, /^sha256:[a-f0-9]{64}$/);
});

test("paired faction diagnostics keep every non-focal input on common seeds", async () => {
  const report = await runFactionSwapDiagnostic({
    workers: 1,
    runsPerArm: 1,
    playerCount: 4,
    seed: "paired-faction-diagnostic",
    preRegistrationId: "paired-faction-diagnostic-test",
    mandateMode: "fixed",
    profileIds: [
      "capability_rusher",
      "balanced_operator",
      "trust_governor",
      "power_broker"
    ],
    backends: ["weighted", "weighted", "weighted", "weighted"],
    comparisons: [{
      id: "demis_vs_mark",
      focalSeat: 0,
      leftFactionIds: [
        "imperial_research_lab",
        "coalition_lab",
        "safety_laboratory",
        "foundry"
      ],
      rightFactionIds: [
        "platform_empire",
        "coalition_lab",
        "safety_laboratory",
        "foundry"
      ]
    }]
  });
  assert.equal(report.diagnosticKind, "paired_faction_swap");
  assert.equal(report.runs, 2);
  assert.equal(report.comparisons[0].paired.pairs, 1);
  assert.equal(report.balanceEvaluation.promotionGate.eligible, false);
  assert.match(report.preRegistration.fingerprint, /^sha256:[a-f0-9]{64}$/);
});

test("AGI claim scenarios create paired legal and one-Compute-short states", async () => {
  const common = {
    runs: 1,
    playerCount: 3,
    seed: "agi-declaration-scenario-contract",
    sampleReplays: 0,
    includeObservations: true,
    rotateProfiles: false,
    rotateFactions: false,
    profileIds: ["agi_candidate", "agi_candidate", "agi_candidate"],
    backends: ["greedy", "greedy", "greedy"],
    factionIds: [
      "coalition_lab",
      "vertical_empire",
      "foundry"
    ],
    experimentKind: "agi_declaration_scenario"
  };
  const eligible = await createSimulation({
    ...common,
    scenario: {
      id: "agi_recognition_window_v2",
      arm: "eligible",
      focalSeat: 0
    }
  });
  const blocked = await createSimulation({
    ...common,
    scenario: {
      id: "agi_recognition_window_v2",
      arm: "blocked_compute",
      focalSeat: 0
    }
  });

  assert.equal(
    eligible.observations[0].scenario.afterInjection.legalDeclaration,
    true
  );
  assert.equal(eligible.observations[0].scenario.claimed, true);
  assert.equal(
    blocked.observations[0].scenario.afterInjection.legalDeclaration,
    false
  );
  assert.equal(
    blocked.observations[0].scenario.afterInjection.failingRequirement,
    "compute"
  );
  assert.equal(blocked.observations[0].scenario.claimed, false);
  assert.notEqual(
    eligible.launchIdentity.fingerprint,
    blocked.launchIdentity.fingerprint
  );
  assert.deepEqual(eligible.configuration.scenario, {
    id: "agi_recognition_window_v2",
    arm: "eligible",
    focalSeat: 0
  });
});

test("AGI scenario matrices rotate faction, seat, backend, and opponent roster", () => {
  const comparisons = expandAgiDeclarationScenarioMatrix({
    playerCount: 3,
    factionIds: [
      "platform_empire",
      "imperial_research_lab",
      "vertical_empire",
      "coalition_lab",
      "safety_laboratory",
      "foundry"
    ],
    focalSeats: [0, 1, 2],
    backends: ["greedy", "weighted"],
    opponentRotations: 3,
    profileId: "agi_candidate"
  });
  assert.equal(comparisons.length, 108);
  assert.ok(comparisons.every((comparison) =>
    comparison.leftFactionIds[comparison.focalSeat] ===
      comparison.focalFactionId &&
    comparison.rightFactionIds[comparison.focalSeat] ===
      comparison.focalFactionId &&
    comparison.leftScenario.arm === "eligible" &&
    comparison.rightScenario.arm === "blocked_compute"
  ));
  assert.deepEqual(
    new Set(comparisons.map((comparison) => comparison.backend)),
    new Set(["greedy", "weighted"])
  );
});

test("paired diagnostics report AGI scenario coverage and declaration effects", async () => {
  const roster = ["coalition_lab", "vertical_empire", "foundry"];
  const report = await runFactionSwapDiagnostic({
    workers: 1,
    runsPerArm: 1,
    playerCount: 3,
    seed: "paired-agi-scenario-contract",
    preRegistrationId: "paired-agi-scenario-contract",
    diagnosticKind: "paired_agi_declaration_scenario",
    experimentKind: "agi_declaration_scenario",
    comparisons: [{
      id: "coalition_seat_0_greedy",
      focalSeat: 0,
      profileIds: ["agi_candidate", "agi_candidate", "agi_candidate"],
      backends: ["greedy", "greedy", "greedy"],
      leftFactionIds: roster,
      rightFactionIds: roster,
      leftScenario: {
        id: "agi_recognition_window_v2",
        arm: "eligible",
        focalSeat: 0
      },
      rightScenario: {
        id: "agi_recognition_window_v2",
        arm: "blocked_compute",
        focalSeat: 0
      }
    }]
  });
  const comparison = report.comparisons[0];
  assert.equal(report.diagnosticKind, "paired_agi_declaration_scenario");
  assert.equal(comparison.paired.leftLegalDeclarationRate, 1);
  assert.equal(comparison.paired.rightLegalDeclarationRate, 0);
  assert.equal(comparison.paired.leftClaimRate, 1);
  assert.equal(comparison.paired.rightClaimRate, 0);
  assert.equal(comparison.left.scenario.arm, "eligible");
  assert.equal(comparison.right.scenario.arm, "blocked_compute");
  assert.match(
    report.balanceEvaluation.promotionGate.reasons[0],
    /qualify a route endpoint/
  );
});

test("parallel faction diagnostics preserve sequential outcomes and fingerprints", async () => {
  const options = {
    runsPerArm: 2,
    playerCount: 4,
    seed: "parallel-faction-diagnostic",
    preRegistrationId: "parallel-faction-diagnostic-test",
    mandateMode: "fixed",
    profileIds: [
      "capability_rusher",
      "balanced_operator",
      "trust_governor",
      "power_broker"
    ],
    backends: ["weighted", "weighted", "weighted", "weighted"],
    comparisons: [{
      id: "orisonix_vs_corthaven",
      focalSeat: 2,
      leftFactionIds: [
        "imperial_research_lab",
        "coalition_lab",
        "safety_laboratory",
        "foundry"
      ],
      rightFactionIds: [
        "imperial_research_lab",
        "coalition_lab",
        "platform_empire",
        "foundry"
      ]
    }]
  };
  const sequential = await runFactionSwapDiagnostic({ ...options, workers: 1 });
  const parallel = await runFactionSwapDiagnostic({ ...options, workers: 2 });

  assert.equal(sequential.execution.scheduler, "inline");
  assert.equal(parallel.execution.scheduler, "worker_threads");
  assert.equal(parallel.execution.workers, 2);
  assert.deepEqual(parallel.comparisons, sequential.comparisons);
  assert.deepEqual(parallel.game, sequential.game);
  assert.deepEqual(parallel.engine, sequential.engine);
  assert.deepEqual(parallel.variant, sequential.variant);
  assert.deepEqual(parallel.strategies, sequential.strategies);
  assert.equal(
    parallel.preRegistration.fingerprint,
    sequential.preRegistration.fingerprint
  );
  assert.equal(parallel.experiment.fingerprint, sequential.experiment.fingerprint);
  assert.equal(parallel.launchIdentity.taskOrder, "comparison_then_arm_then_match");
  assert.equal(parallel.launchIdentity.tasks.length, 2);
  assert.ok(parallel.launchIdentity.study.fingerprint);
  assert.ok(parallel.launchIdentity.tasks.every((task) =>
    task.identity.fingerprint &&
    task.identity.provenance.sourceCommit === parallel.launchIdentity.study.provenance.sourceCommit
  ));
});

test("LLM concurrency broker enforces global and provider-specific caps", async () => {
  assert.throws(
    () => new LlmConcurrencyBroker({ concurrency: 17 }),
    /llmConcurrency must be an integer from 1 to 16/
  );
  assert.throws(
    () => new LlmConcurrencyBroker({
      providerConcurrency: { claude: 5 }
    }),
    /claude concurrency must be an integer from 1 to 4/
  );
  const active = { all: 0, claude: 0, codex: 0 };
  const peak = { all: 0, claude: 0, codex: 0 };
  const broker = new LlmConcurrencyBroker({
    concurrency: 3,
    providerConcurrency: { claude: 1, codex: 2 },
    generation: "broker-cap-test",
    callerFactory: ({ provider }) => ({
      async decide(packet) {
        active.all += 1;
        active[provider] += 1;
        peak.all = Math.max(peak.all, active.all);
        peak[provider] = Math.max(peak[provider], active[provider]);
        await new Promise((resolve) => setTimeout(resolve, 5));
        active.all -= 1;
        active[provider] -= 1;
        return {
          decision: { decisionId: packet.legalDecisions[0].decisionId },
          receipt: { provider: `${provider}-cli` }
        };
      }
    })
  });
  const providers = ["claude", "codex", "claude", "codex", "codex", "claude"];
  await Promise.all(providers.map((provider, taskIndex) => broker.request({
    studyGeneration: "broker-cap-test",
    taskGeneration: `broker-cap-test:${taskIndex}`,
    taskIndex,
    requestToken: `request-${taskIndex}`,
    provider,
    backend: provider,
    packet: {
      requestId: `packet-${taskIndex}`,
      legalDecisions: [{ decisionId: "fixture-choice" }]
    }
  })));
  assert.deepEqual(peak, { all: 3, claude: 1, codex: 2 });
  assert.equal(broker.summary().peakActiveLlmCalls, 3);
  assert.ok(broker.summary().throttledRequests > 0);
});

test("LLM concurrency broker rejects cancelled and stale-generation responses", async () => {
  let release;
  const broker = new LlmConcurrencyBroker({
    concurrency: 1,
    generation: "active-generation",
    callerFactory: () => ({
      async decide(packet) {
        await new Promise((resolve) => {
          release = resolve;
        });
        return {
          decision: { decisionId: packet.legalDecisions[0].decisionId },
          receipt: { provider: "codex-cli" }
        };
      }
    })
  });
  const pending = broker.request({
    studyGeneration: "active-generation",
    taskGeneration: "active-generation:0",
    taskIndex: 0,
    requestToken: "late-request",
    provider: "codex",
    backend: "codex",
    packet: {
      requestId: "late-packet",
      legalDecisions: [{ decisionId: "fixture-choice" }]
    }
  });
  await new Promise((resolve) => setImmediate(resolve));
  broker.cancel(new DOMException("Study replaced.", "AbortError"));
  await assert.rejects(pending, /Study replaced/);
  release();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(broker.summary().completedRequests, 0);
  assert.equal(broker.summary().cancelledRequests, 1);
  await assert.rejects(
    () => broker.request({
      studyGeneration: "replacement-generation",
      taskGeneration: "replacement-generation:0",
      taskIndex: 0,
      requestToken: "stale-request",
      provider: "codex",
      backend: "codex",
      packet: {
        requestId: "stale-packet",
        legalDecisions: [{ decisionId: "fixture-choice" }]
      }
    }),
    /cancelled/
  );
});

test("LLM-backed faction diagnostics require explicit authorization", async () => {
  await assert.rejects(
    () => runFactionSwapDiagnostic({
      runsPerArm: 1,
      playerCount: 4,
      backends: ["codex", "weighted", "weighted", "weighted"],
      comparisons: [{
        id: "llm-inline-default",
        focalSeat: 0,
        leftFactionIds: [
          "safety_laboratory",
          "coalition_lab",
          "imperial_research_lab",
          "foundry"
        ],
        rightFactionIds: [
          "platform_empire",
          "coalition_lab",
          "imperial_research_lab",
          "foundry"
        ]
      }]
    }),
    /explicit allowLlm authorization/
  );
});

test("parallel LLM faction diagnostics cap calls and quarantine failed pairs", async () => {
  let active = 0;
  let peak = 0;
  const report = await runFactionSwapDiagnostic({
    archiveLlmMatches: false,
    workers: 4,
    llmConcurrency: 2,
    llmRetries: 1,
    providerConcurrency: { codex: 2 },
    allowLlm: true,
    runsPerArm: 3,
    sampleReplays: 1,
    playerCount: 4,
    seed: "parallel-llm-faction-diagnostic",
    profileIds: [
      "capability_rusher",
      "balanced_operator",
      "trust_governor",
      "power_broker"
    ],
    backends: ["codex", "weighted", "weighted", "weighted"],
    model: "fixture-model",
    reasoningEffort: "low",
    llmCallerFactory: () => ({
      async decide(packet, { brokerContext }) {
        active += 1;
        peak = Math.max(peak, active);
        await new Promise((resolve) =>
          setTimeout(resolve, brokerContext.taskIndex % 2 ? 2 : 1)
        );
        active -= 1;
        if (brokerContext.taskIndex === 1) {
          const error = new Error("Fixture provider failure.");
          error.providerReceipt = {
            attemptedProvider: "codex-cli",
            attemptedModel: "fixture-model",
            attemptedReasoningEffort: "low",
            attemptedRequestId: packet.requestId
          };
          throw error;
        }
        const decision = packet.legalDecisions[0];
        return {
          decision: { decisionId: decision.decisionId },
          receipt: {
            provider: "codex-cli",
            model: "fixture-model",
            reasoningEffort: "low",
            requestId: packet.requestId,
            decisionId: decision.decisionId
          }
        };
      }
    }),
    comparisons: [{
      id: "strict-llm-pair",
      focalSeat: 0,
      leftFactionIds: [
        "safety_laboratory",
        "coalition_lab",
        "imperial_research_lab",
        "foundry"
      ],
      rightFactionIds: [
        "platform_empire",
        "coalition_lab",
        "imperial_research_lab",
        "foundry"
      ]
    }]
  });

  assert.equal(peak, 2);
  assert.equal(report.execution.scheduler, "worker_threads");
  assert.equal(report.execution.llmConcurrency, 2);
  assert.equal(report.execution.llm.peakActiveLlmCalls, 2);
  assert.equal(report.execution.llm.retries, 1);
  assert.equal(report.execution.quarantinedMatches, 1);
  assert.equal(report.comparisons[0].paired.pairs, 2);
  assert.equal(report.comparisons[0].paired.quarantinedPairs, 1);
  assert.deepEqual(
    report.comparisons[0].paired.rows.map((row) => row.matchIndex),
    [0, 2]
  );
  assert.deepEqual(
    report.llmEvidence.matches.map((match) => match.matchIndex),
    [0, 2]
  );
  assert.ok(report.llmEvidence.matches[0].left.replay);
  assert.ok(report.llmEvidence.matches[0].right.replay);
  assert.ok(report.llmEvidence.matches.every((match) =>
    [...match.left.receipts, ...match.right.receipts].every((receipt) =>
      receipt.provider === "codex-cli" &&
      receipt.model === "fixture-model" &&
      receipt.reasoningEffort === "low" &&
      receipt.fallback === false
    )
  ));
  assert.equal(
    report.quarantine.matches[0].left.providerReceipt.brokerAttempts,
    2
  );
});

test("each completed strict LLM faction match archives before aggregate reporting", async () => {
  const archiveProjectRoot = await mkdtemp(join(tmpdir(), "frontier-llm-archive-"));
  try {
    const report = await runFactionSwapDiagnostic({
      workers: 2,
      llmConcurrency: 1,
      allowLlm: true,
      runsPerArm: 1,
      playerCount: 3,
      seed: "strict-llm-immediate-archive",
      archiveProjectRoot,
      profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
      backends: ["codex", "weighted", "weighted"],
      model: "fixture-model",
      reasoningEffort: "low",
      llmCallerFactory: () => ({
        async decide(packet) {
          return {
            decision: { decisionId: packet.legalDecisions[0].decisionId },
            receipt: {
              provider: "codex-cli",
              model: "fixture-model",
              reasoningEffort: "low",
              requestId: packet.requestId,
              decisionId: packet.legalDecisions[0].decisionId
            }
          };
        }
      }),
      comparisons: [{
        id: "archive-each-llm-match",
        focalSeat: 0,
        leftFactionIds: ["coalition_lab", "platform_empire", "foundry"],
        rightFactionIds: ["safety_laboratory", "platform_empire", "foundry"]
      }]
    });
    const archives = report.execution.completedLlmArchives;
    assert.equal(archives.length, 2, JSON.stringify(report.quarantine));
    assert.deepEqual(archives.map((archive) => archive.arm), ["left", "right"]);
    for (const archive of archives) {
      const stored = JSON.parse(await readFile(join(archiveProjectRoot, archive.relativePath), "utf8"));
      assert.equal(stored.configuration.llmEvidenceMode, "strict_quarantine");
      assert.equal(stored.configuration.usedLlmDecisions > 0, true);
    }
  } finally {
    await rm(archiveProjectRoot, { recursive: true, force: true });
  }
});

test("parallel faction diagnostics fail closed when a worker game fails", async () => {
  await assert.rejects(
    () => runFactionSwapDiagnostic({
      workers: 2,
      runsPerArm: 1,
      playerCount: 4,
      backends: ["weighted", "weighted", "weighted", "weighted"],
      comparisons: [{
        id: "worker-failure",
        focalSeat: 0,
        leftFactionIds: [
          "missing_faction",
          "coalition_lab",
          "imperial_research_lab",
          "foundry"
        ],
        rightFactionIds: [
          "platform_empire",
          "coalition_lab",
          "imperial_research_lab",
          "foundry"
        ]
      }]
    }),
    /Unknown faction: missing_faction/
  );
});

test("weighted policies replay deterministically from packet seed and persona", async () => {
  const [profile] = await loadPlayerProfiles();
  const policy = new WeightedPlayerPolicy(profile);
  const packet = {
    schemaVersion: 1,
    requestId: "policy-replay",
    matchId: "match",
    seed: "same-seed",
    seat: 0,
    factionId: "coalition_lab",
    round: 1,
    cycle: 1,
    observation: {
      self: {
        runway: 2,
        unpoweredFacilities: 1,
        canDeploy: false
      }
    },
    legalDecisions: [
      {
        decisionId: "fund_conservative_s0",
        label: "Fund",
        actionId: "fund"
      },
      {
        decisionId: "build_generator_clean_infrastructure_s0",
        label: "Build grid",
        actionId: "build"
      }
    ]
  };
  assert.deepEqual(await policy.decide(packet), await policy.decide(packet));
  assert.ok(
    policy.score(packet, packet.legalDecisions[1]) >
    policy.score(packet, packet.legalDecisions[0])
  );
});

test("CLI-backed personas pass natural-language identity through the shared packet", async () => {
  const [profile] = await loadPlayerProfiles();
  let received;
  const caller = {
    async decide(packet) {
      received = packet;
      return {
        decision: { decisionId: packet.legalDecisions[0].decisionId },
        receipt: { provider: "fixture-cli", requestId: packet.requestId }
      };
    }
  };
  const fallback = new WeightedPlayerPolicy(profile);
  const policy = new CliBackedPlayerPolicy(profile, caller, { fallback });
  const packet = {
    schemaVersion: 1,
    requestId: "persona-call",
    matchId: "match",
    seed: "seed",
    seat: 0,
    factionId: "coalition_lab",
    round: 1,
    cycle: 1,
    observation: { self: {} },
    legalDecisions: [{
      decisionId: "select_fund",
      label: "Select Fund",
      actionId: "fund"
    }]
  };
  await policy.decide(packet);
  assert.equal(received.strategy.id, profile.id);
  assert.equal(received.strategy.persona.identity, profile.persona.identity);
});

test("Monte Carlo pipeline is deterministic and carries sampled replays", async () => {
  const options = {
    runs: 2,
    playerCount: 4,
    seed: "simulation-contract",
    sampleReplays: 1,
    profileIds: [
      "balanced_operator",
      "capability_rusher",
      "infrastructure_compounder",
      "market_maximalist"
    ],
    backends: ["weighted"]
  };
  const first = await createSimulation(options);
  const second = await createSimulation(options);
  assert.deepEqual(first.seats, second.seats);
  assert.deepEqual(first.samples, second.samples);
  assert.equal(first.scope.id, "react-agent-assignments-v1");
  assert.ok(first.scope.excluded.includes("the deferred Tactic module"));
  assert.equal(first.schemaVersion, 6);
  assert.equal(first.reportSchemaVersion, 6);
  assert.equal(first.replaySchemaVersion, 2);
  assert.equal(first.decisionSchemaVersion, 2);
  assert.equal(first.game.version, currentRelease.gameVersion);
  assert.match(first.game.rulesetFingerprint, /^sha256:[a-f0-9]{64}$/);
  assert.match(first.engine.fingerprint, /^sha256:[a-f0-9]{64}$/);
  assert.match(first.strategies.fingerprint, /^sha256:[a-f0-9]{64}$/);
  assert.match(first.experiment.fingerprint, /^sha256:[a-f0-9]{64}$/);
  assert.equal(first.variant.kind, "canonical");
  assert.ok(!("playProfileId" in first.variant.effective));
  assert.equal(first.rng.algorithm, "mulberry32");
  assert.ok(first.factions.length >= 4 && first.factions.length <= 6);
  assert.equal(first.profiles.length, 4);
  assert.match(first.balanceContract.fingerprint, /^sha256:[a-f0-9]{64}$/);
  assert.ok(first.balanceEvaluation.checks.length >= 10);
  assert.ok(first.diagnostics.openingDiversity.observed > 0);
  assert.ok(first.diagnostics.winningPathDiversity.observed > 0);
  assert.ok(Array.isArray(first.profileMatchups));
  assert.equal(first.balanceEvaluation.promotionGate.eligible, false);
  assert.equal(first.seats[0].profileIds.length, 2);
  assert.equal(typeof first.diagnostics.factionWinShareRange, "number");
  assert.equal(typeof first.diagnostics.actionDiversity, "number");
  assert.equal(first.samples[0].replay.filter((event) =>
    event.type === "headline_revealed"
  ).length, 12);
  assert.equal(first.samples[0].replay[0].state.board.length, 19);
  assert.equal(first.samples[0].replay.filter((event) =>
    event.type === "realignment_resolved"
  ).length, 0);
  assert.ok(!("realignments" in first.matchMetrics));
  assert.equal(
    first.matchMetrics.agiFunnel.playerOpportunities,
    options.runs * options.playerCount
  );
  assert.equal(typeof first.matchMetrics.agiFunnelRates.declared, "number");
  assert.equal(typeof first.matchMetrics.factionAbilityValues, "object");
  assert.equal(typeof first.matchMetrics.factionActionSelections, "object");
  assert.equal(typeof first.matchMetrics.profileActionSelections, "object");
  assert.equal(typeof first.matchMetrics.profileMandateSources, "object");
  assert.equal(first.samples[0].replay.at(-1).type, "round_settled");
  assert.equal(first.samples[0].replay.at(-1).round, 4);

  await assert.rejects(createSimulation({...options, runs: 1, rulesVariant: {playProfileId: "advanced-play"}}), /Unsupported rules option/);
});

test("simulation reports deterministic turn and round projections", async () => {
  const progress = [];
  await createSimulation({
    runs: 1,
    playerCount: 3,
    seed: "live-progress-contract",
    sampleReplays: 0,
    profileIds: ["capability_rusher", "power_broker", "trust_governor"],
    backends: ["weighted"],
    models: ["gpt-5.6-sol"],
    reasoningEfforts: ["medium"]
  }, (entry) => progress.push(entry));
  const turns = progress.filter((entry) => entry.kind === "turn");
  const cycles = progress.filter((entry) => entry.kind === "cycle");
  const rounds = progress.filter((entry) => entry.kind === "round");
  assert.equal(turns.length, 36);
  assert.equal(cycles.length, 12);
  assert.equal(rounds.length, 4);
  assert.deepEqual(turns.map((entry) => entry.turnNumber), Array.from({ length: 36 }, (_, index) => index + 1));
  assert.ok(turns.every((entry) => Number.isInteger(entry.completedSeat)));
  assert.ok(turns.every((entry) => entry.standings.every((standing) =>
    standing.model === null && standing.reasoningEffort === null
  )));
  for (const entry of [...turns, ...cycles, ...rounds]) {
    assert.equal(entry.phase, "match_progress");
    assert.equal(entry.run, 1);
    assert.equal(entry.runs, 1);
    assert.equal(entry.standings.length, 3);
    assert.equal(entry.projectedWinnerSeat, entry.standings[0].seat);
    assert.deepEqual(
      entry.standings.map((standing) => standing.score),
      [...entry.standings.map((standing) => standing.score)].sort((left, right) => right - left)
    );
  }
});

test("Monte Carlo refuses metered providers without explicit authorization", async () => {
  await assert.rejects(
    () => createSimulation({
      runs: 1,
      playerCount: 3,
      profileIds: ["balanced_operator", "capability_rusher"],
      backends: ["claude", "weighted"]
    }),
    /explicit allowLlm/
  );
});

test("LLM evidence modes make fallback policy explicit and leave call budgets uncapped by default", async () => {
  const report = await createSimulation({
    runs: 1,
    playerCount: 3,
    seed: "llm-evidence-mode-contract",
    sampleReplays: 0,
    profileIds: ["capability_rusher", "power_broker", "trust_governor"],
    backends: ["codex"],
    allowLlm: true,
    archiveLlmMatches: false,
    llmStages: ["not-a-decision-stage"]
  });
  assert.equal(report.configuration.llmEvidenceMode, "fallback_allowed");
  assert.equal(report.configuration.maxLlmDecisions, null);
  assert.equal(report.configuration.maxLlmDecisionsPerSeatCycle, null);
  await assert.rejects(
    () => createSimulation({
      runs: 1,
      playerCount: 3,
      backends: ["weighted"],
      requireLlm: true
    }),
    /requireLlm requires at least one LLM-backed policy/
  );
});

test("generic completed strict LLM matches archive before the tournament returns", async () => {
  const archiveProjectRoot = await mkdtemp(join(tmpdir(), "frontier-generic-llm-archive-"));
  try {
    const report = await createSimulation({
      runs: 1,
      playerCount: 3,
      seed: "generic-llm-archive-contract",
      sampleReplays: 0,
      allowLlm: true,
      requireLlm: true,
      strictLlmEvidence: true,
      archiveProjectRoot,
      profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
      backends: ["codex", "weighted", "weighted"],
      callerFactory: () => ({
        async decide(packet) {
          return {
            decision: { decisionId: packet.legalDecisions[0].decisionId },
            receipt: { provider: "fixture", requestId: packet.requestId }
          };
        }
      })
    });
    assert.equal(report.configuration.completedLlmArchives.length, 1);
    const archive = report.configuration.completedLlmArchives[0];
    const stored = JSON.parse(await readFile(join(archiveProjectRoot, archive.relativePath), "utf8"));
    assert.equal(stored.runs, 1);
    assert.equal(stored.configuration.llmEvidenceMode, "strict_quarantine");
    assert.equal(stored.standings.length, 3);
    assert.ok(stored.experiment);
    assert.ok(stored.rng);
    assert.ok(stored.provenance);
    assert.doesNotThrow(() => normalizeSimulationReport(stored));
  } finally {
    await rm(archiveProjectRoot, { recursive: true, force: true });
  }
});

test("LLM prompt treatments are explicit, fingerprinted, and delivered by seat", async () => {
  const guidance =
    "Before choosing, identify how this decision converts current resources into Mandate and fulfill any promise whose legal window is open.";
  const baseOptions = {
    runs: 1,
    playerCount: 3,
    seed: "prompt-treatment-contract",
    sampleReplays: 0,
    profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
    backends: ["codex", "weighted", "weighted"],
    model: "fixture-model",
    reasoningEffort: "medium"
  };
  const baselineIdentity = await captureSimulationLaunchIdentity(baseOptions);
  const treatedOptions = {
    ...baseOptions,
    promptAddenda: [guidance, null, null]
  };
  const treatedIdentity = await captureSimulationLaunchIdentity(treatedOptions);
  assert.notEqual(
    treatedIdentity.strategies.fingerprint,
    baselineIdentity.strategies.fingerprint
  );

  let treatedPackets = 0;
  await createSimulation({
    ...treatedOptions,
    allowLlm: true,
    requireLlm: true,
    strictLlmEvidence: true,
    archiveLlmMatches: false,
    callerFactory: () => ({
      async decide(packet) {
        assert.ok(packet.strategy.objectives.includes(
          `Experimental decision guidance: ${guidance}`
        ));
        treatedPackets += 1;
        return {
          decision: { decisionId: packet.legalDecisions[0].decisionId },
          receipt: { provider: "fixture", requestId: packet.requestId }
        };
      }
    })
  });
  assert.ok(treatedPackets > 0);
});

test("faction comparisons can share a registered seed across treatment cells", async () => {
  const comparison = {
    focalSeat: 0,
    seedGroup: "shared-treatment-cell",
    leftFactionIds: [
      "coalition_lab",
      "vertical_empire",
      "foundry"
    ],
    rightFactionIds: [
      "safety_laboratory",
      "vertical_empire",
      "foundry"
    ]
  };
  const report = await runFactionSwapDiagnostic({
    runsPerArm: 1,
    playerCount: 3,
    seed: "shared-treatment-root",
    profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
    backends: ["weighted", "weighted", "weighted"],
    comparisons: [
      { ...comparison, id: "control", promptTreatmentId: "control" },
      { ...comparison, id: "replicate", promptTreatmentId: "replicate" }
    ]
  });
  assert.equal(report.comparisons[0].seedGroup, "shared-treatment-cell");
  assert.equal(report.comparisons[1].seedGroup, "shared-treatment-cell");
  assert.deepEqual(
    report.comparisons[0].paired.rows,
    report.comparisons[1].paired.rows
  );
});

test("paired deterministic policy treatments are fingerprinted and reported by arm", async () => {
  const base = {
    runs: 1,
    playerCount: 3,
    seed: "deterministic-treatment-identity",
    sampleReplays: 0,
    profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
    backends: ["greedy", "greedy", "greedy"],
    factionIds: ["coalition_lab", "vertical_empire", "foundry"],
    rotateProfiles: false,
    rotateFactions: false
  };
  const baselineIdentity = await captureSimulationLaunchIdentity(base);
  const treatedIdentity = await captureSimulationLaunchIdentity({
    ...base,
    policyTreatments: ["coalition_conversion_v1", null, null]
  });
  assert.notEqual(treatedIdentity.fingerprint, baselineIdentity.fingerprint);

  const report = await runFactionSwapDiagnostic({
    workers: 1,
    runsPerArm: 1,
    playerCount: 3,
    seed: "paired-deterministic-treatment",
    preRegistrationId: "paired-deterministic-treatment-test",
    projection: "batch",
    comparisons: [{
      id: "coalition_conversion_seat_0_greedy",
      focalSeat: 0,
      profileIds: base.profileIds,
      backends: base.backends,
      leftFactionIds: base.factionIds,
      rightFactionIds: base.factionIds,
      leftPolicyTreatments: ["coalition_conversion_v1", null, null],
      rightPolicyTreatments: [null, null, null]
    }]
  });
  const comparison = report.comparisons[0];
  assert.deepEqual(comparison.left.policyTreatments, [
    "coalition_conversion_v1",
    null,
    null
  ]);
  assert.deepEqual(comparison.right.policyTreatments, [null, null, null]);
  assert.equal(typeof comparison.paired.meanCausallyNecessaryCreditDelta, "number");
  assert.equal(typeof comparison.paired.meanAttributedMandateDelta, "number");
  assert.equal(report.execution.simulationWorkersPerTask, 1);
  assert.notEqual(
    report.launchIdentity.tasks[0].identity.fingerprint,
    report.launchIdentity.tasks[1].identity.fingerprint
  );
});

test("Coalition conversion matrices cover every comparator, seat, and backend", () => {
  const comparisons = expandCoalitionConversionMatrix({
    playerCount: 3,
    focalFactionId: "coalition_lab",
    comparatorFactionIds: [
      "platform_empire",
      "imperial_research_lab",
      "vertical_empire",
      "safety_laboratory",
      "foundry"
    ],
    focalSeats: [0, 1, 2],
    backends: ["greedy", "weighted"],
    opponentFactionCycle: [
      "platform_empire",
      "imperial_research_lab",
      "vertical_empire",
      "safety_laboratory",
      "foundry"
    ],
    focalProfileId: "balanced_operator",
    opponentProfileIds: ["capability_rusher", "trust_governor"]
  });
  assert.equal(comparisons.length, 30);
  assert.deepEqual(
    new Set(comparisons.map((comparison) => comparison.focalSeat)),
    new Set([0, 1, 2])
  );
  assert.deepEqual(
    new Set(comparisons.flatMap((comparison) => comparison.backends)),
    new Set(["greedy", "weighted"])
  );
  assert.ok(comparisons.every((comparison) =>
    comparison.leftFactionIds[comparison.focalSeat] === "coalition_lab" &&
    comparison.rightFactionIds[comparison.focalSeat] === "coalition_lab" &&
    comparison.leftPolicyTreatments[comparison.focalSeat] ===
      "coalition_conversion_v1" &&
    comparison.rightPolicyTreatments.every((treatment) => treatment === null) &&
    comparison.leftFactionIds.includes(comparison.comparatorId)
  ));
});

test("faction isolation matrices rotate every comparator through every focal seat", () => {
  const comparisons = expandFactionIsolationMatrix({
    focalFactionId: "coalition_lab",
    comparatorFactionIds: [
      "platform_empire",
      "imperial_research_lab",
      "vertical_empire",
      "safety_laboratory",
      "foundry"
    ],
    focalSeats: [0, 1, 2],
    policyArms: [
      { id: "baseline", leftPromptId: "coalition_baseline" },
      { id: "follow_through", leftPromptId: "coalition_follow_through" }
    ],
    opponentFactionCycle: [
      "platform_empire",
      "imperial_research_lab",
      "vertical_empire",
      "safety_laboratory",
      "foundry"
    ],
    focalProfileId: "balanced_operator",
    opponentProfileIds: ["capability_rusher", "trust_governor"],
    rightPromptIdsByFaction: {
      platform_empire: "platform_objective",
      imperial_research_lab: "imperial_objective",
      vertical_empire: "vertical_objective",
      safety_laboratory: "safety_objective",
      foundry: "foundry_objective"
    }
  });
  assert.equal(comparisons.length, 30);
  for (const factionId of [
    "platform_empire",
    "imperial_research_lab",
    "vertical_empire",
    "safety_laboratory",
    "foundry"
  ]) {
    const cells = comparisons.filter((entry) => entry.comparatorId === factionId);
    assert.deepEqual(new Set(cells.map((entry) => entry.focalSeat)), new Set([0, 1, 2]));
    assert.deepEqual(
      new Set(cells.map((entry) => entry.promptTreatmentId)),
      new Set(["baseline", "follow_through"])
    );
  }
  assert.ok(comparisons.every((entry) =>
    entry.leftFactionIds[entry.focalSeat] === "coalition_lab" &&
    entry.rightFactionIds[entry.focalSeat] === entry.comparatorId &&
    entry.backends[entry.focalSeat] === "codex"
  ));
});

test("paired faction arms receive their registered canonical prompt treatment", async () => {
  const seen = new Map();
  const promptLibrary = {
    coalition: "Use Coalition's canonical trading abilities.",
    safety: "Use Safety's canonical governance abilities."
  };
  const report = await runFactionSwapDiagnostic({
    archiveLlmMatches: false,
    workers: 2,
    llmConcurrency: 2,
    providerConcurrency: { codex: 2 },
    allowLlm: true,
    runsPerArm: 1,
    playerCount: 3,
    seed: "arm-prompt-treatment",
    promptLibrary,
    llmCallerFactory: () => ({
      async decide(packet) {
        const objectives = packet.strategy.objectives.join("\n");
        const expected = packet.factionId === "coalition_lab"
          ? promptLibrary.coalition
          : promptLibrary.safety;
        assert.match(objectives, new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
        seen.set(packet.factionId, (seen.get(packet.factionId) || 0) + 1);
        return {
          decision: { decisionId: packet.legalDecisions[0].decisionId },
          receipt: { provider: "fixture", requestId: packet.requestId }
        };
      }
    }),
    comparisons: [{
      id: "arm-specific-prompts",
      focalSeat: 0,
      profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
      backends: ["codex", "weighted", "weighted"],
      leftPromptIds: ["coalition", null, null],
      rightPromptIds: ["safety", null, null],
      leftFactionIds: ["coalition_lab", "vertical_empire", "foundry"],
      rightFactionIds: ["safety_laboratory", "vertical_empire", "foundry"]
    }]
  });
  assert.ok(seen.get("coalition_lab") > 0);
  assert.ok(seen.get("safety_laboratory") > 0);
  assert.equal(report.comparisons[0].paired.pairs, 1, JSON.stringify(report.quarantine));
  assert.notEqual(
    report.comparisons[0].left.strategiesFingerprint,
    report.comparisons[0].right.strategiesFingerprint
  );
});

test("simulation records two-player games as exploratory and rejects six-player requests", async () => {
  await assert.rejects(createSimulation({ runs: 1, playerCount: 6 }), /playerCount must be an integer from 2 to 5/);
  await assert.rejects(createInteractiveGame({ playerCount: 6 }), /playerCount must be one of 2, 3, 4, 5/);
  for (const playerCount of [2]) {
    const report = await createSimulation({
      runs: 1,
      playerCount,
      sampleReplays: 0,
      seed: `exploratory-${playerCount}`
    });
    assert.equal(report.playerCount, playerCount);
    assert.equal(report.configuration.playerCountStatus, "exploratory_nonpromotional");
    assert.match(report.scope.id, new RegExp(`exploratory-${playerCount}p$`));
    assert.match(report.scope.verdictBoundary, /non-promotional diagnostic/);
  }
});

test("aggregate-only Monte Carlo runs do not require replay samples", async () => {
  const report = await createSimulation({
    runs: 2,
    playerCount: 3,
    seed: "aggregate-only",
    sampleReplays: 0,
    profileIds: ["balanced_operator", "capability_rusher"],
    backends: ["greedy"]
  });
  assert.equal(report.samples.length, 0);
  assert.equal(report.scope.id, "react-agent-assignments-v1");
  assert.equal(report.seats.length, 3);
});

test("blocked Core Actions exhaust without corrupting state or winner resolution", async () => {
  const report = await createSimulation({
    runs: 8,
    playerCount: 4,
    seed: "blocked-actions-remain-finite",
    sampleReplays: 1
  });
  assert.ok(report.samples[0].winnerSeats.length > 0);
  for (const standing of report.samples[0].standings) {
    for (const key of ["score", "trust", "customers", "compute", "capability"]) {
      assert.ok(Number.isFinite(standing[key]), `${key} remains finite`);
    }
  }
});

test("strategy and rule mutations are deterministic, bounded, and do not edit source profiles", async () => {
  const [profile] = await loadPlayerProfiles();
  const before = structuredClone(profile);
  const first = mutateStrategy(profile, "mutation-contract");
  const second = mutateStrategy(profile, "mutation-contract");
  assert.deepEqual(first, second);
  assert.deepEqual(profile, before);
  assert.notDeepEqual(first.strategy.actionWeights, profile.strategy.actionWeights);

  const highWeightProfile = structuredClone(profile);
  highWeightProfile.strategy.actionWeights.agi = 60;
  const highWeightMutation = mutateStrategy(
    highWeightProfile,
    "high-weight-mutation-contract"
  );
  assert.ok(highWeightMutation.strategy.actionWeights.agi > 20);
  assert.ok(highWeightMutation.strategy.actionWeights.agi <= 60);

  const rules = mutateRulesVariant({}, "rule-contract", { mutations: 3 });
  assert.deepEqual(rules, mutateRulesVariant({}, "rule-contract", { mutations: 3 }));
  assert.ok(rules.changed.length >= 1);
});

test("strategy evolution and rule search return inspectable recommendations", async () => {
  const exactOpponent = structuredClone(
    (await loadPlayerProfiles()).find((profile) => profile.id === "trust_governor")
  );
  exactOpponent.strategy.actionWeights.influence = 8.75;
  exactOpponent.provenance = {
    kind: "test_evolution_ecology_override",
    parentId: exactOpponent.id,
    seed: "evolution-contract"
  };
  const evolution = await runExperiment({
    mode: "strategy-evolution",
    targetProfileId: "balanced_operator",
    generations: 1,
    population: 2,
    runsPerSeat: 6,
    playerCount: 3,
    backendId: "greedy",
    targetWinShare: 1 / 3,
    profileOverrides: [exactOpponent],
    profileOverrideSources: [{
      path: "fixture/trust.json",
      profileId: exactOpponent.id,
      sha256: "a".repeat(64)
    }],
    seed: "evolution-contract"
  });
  assert.equal(evolution.reportType, "strategy_evolution");
  assert.equal(evolution.history.length, 1);
  assert.equal(evolution.championProfile.id, "balanced_operator");
  assert.equal(evolution.backendId, "greedy");
  assert.equal(evolution.targetWinShare, 1 / 3);
  assert.equal(evolution.opponentCoverage, "all_windows");
  assert.equal(evolution.evaluatedMatchesPerCandidate, 18);
  assert.equal(
    evolution.ecologyProfiles.find((profile) => profile.id === exactOpponent.id)
      .strategy.actionWeights.influence,
    8.75
  );
  assert.equal(evolution.profileOverrideSources[0].sha256, "a".repeat(64));
  assert.equal(
    evolution.history[0].candidates[0].evaluation
      .playerCountEvaluations[3].opponentWindows.length,
    6
  );
  assert.equal(typeof evolution.history[0].champion.targetDistance, "number");
  assert.equal(
    evolution.history[0].evaluationSeed,
    "evolution-contract:g:0:common"
  );

  const search = await runExperiment({
    mode: "rule-search",
    iterations: 2,
    runs: 1,
    playerCount: 3,
    seed: "rule-search-contract"
  });
  assert.equal(search.reportType, "rule_search");
  assert.equal(search.evaluations.length, 2);
  assert.ok(search.recommendation.variant);
  assert.match(search.scope.verdictBoundary, /never changed automatically/i);
});

test("strategy evolution covers every opponent and fails closed on incomplete coverage", async () => {
  const profiles = await loadPlayerProfiles();
  for (const playerCount of [3, 4, 5]) {
    const windows = opponentProfileWindows({
      profiles,
      targetProfileId: "agi_candidate",
      playerCount
    });
    assert.equal(windows.length, 6);
    const appearances = new Map();
    for (const profileId of windows.flat()) {
      appearances.set(profileId, (appearances.get(profileId) || 0) + 1);
    }
    assert.equal(appearances.size, 6);
    assert.deepEqual(
      [...appearances.values()],
      Array.from({ length: 6 }, () => playerCount - 1)
    );
  }

  await assert.rejects(
    runExperiment({
      mode: "strategy-evolution",
      targetProfileId: "agi_candidate",
      generations: 1,
      population: 2,
      runsPerSeat: 5,
      playerCounts: [3, 4, 5],
      targetWinShare: "neutral"
    }),
    /runsPerSeat must be at least 6/
  );
});

test("strategy evolution merges exact opponent artifacts without mutating authored profiles", async () => {
  const profiles = await loadPlayerProfiles();
  const authored = structuredClone(profiles);
  const override = structuredClone(
    profiles.find((profile) => profile.id === "trust_governor")
  );
  override.strategy.actionWeights.influence = 9.125;
  override.provenance = {
    kind: "test_exact_ecology_override",
    parentId: override.id,
    seed: "exact-ecology-fixture"
  };
  const merged = mergeStrategyProfiles(profiles, [override]);
  assert.deepEqual(profiles, authored);
  assert.equal(
    merged.find((profile) => profile.id === override.id)
      .strategy.actionWeights.influence,
    9.125
  );
  assert.equal(
    merged.find((profile) => profile.id === override.id).provenance.kind,
    "test_exact_ecology_override"
  );
  assert.throws(
    () => mergeStrategyProfiles(profiles, [override, override]),
    /repeats profile id/
  );
  const unknown = structuredClone(override);
  unknown.id = "unknown_ecology_profile";
  assert.throws(
    () => mergeStrategyProfiles(profiles, [unknown]),
    /unknown profile id/
  );
});

test("neutral strategy calibration ranks worst count, then mean miss, then fitness", () => {
  const candidate = (targetDistance, meanTargetDistance, fitness) => ({
    profile: { strategy: { actionWeights: { fund: fitness } } },
    evaluation: { targetDistance, meanTargetDistance, fitness }
  });
  assert.ok(compareStrategyEvaluations(
    candidate(0.1, 0.08, 100),
    candidate(0.11, 0.01, 200),
    "neutral"
  ) < 0);
  assert.ok(compareStrategyEvaluations(
    candidate(0.1, 0.03, 100),
    candidate(0.1, 0.04, 200),
    "neutral"
  ) < 0);
  assert.ok(compareStrategyEvaluations(
    candidate(0.1, 0.03, 200),
    candidate(0.1, 0.03, 100),
    "neutral"
  ) < 0);
});

test("multi-count neutral strategy calibration records count-specific targets", async () => {
  const evolution = await runExperiment({
    mode: "strategy-evolution",
    targetProfileId: "balanced_operator",
    generations: 1,
    population: 2,
    runsPerSeat: 1,
    playerCounts: "3,4,5",
    backendId: "greedy",
    targetWinShare: "neutral",
    opponentCoverage: "fixed_window",
    seed: "neutral-ecology-contract"
  });
  assert.deepEqual(evolution.playerCounts, [3, 4, 5]);
  assert.deepEqual(evolution.targetWinShares, {
    3: 1 / 3,
    4: 1 / 4,
    5: 1 / 5
  });
  assert.equal(evolution.evaluatedMatchesPerCandidate, 12);
  for (const candidate of evolution.history[0].candidates) {
    const evaluations = Object.values(candidate.evaluation.playerCountEvaluations);
    const distances = evaluations.map((entry) => entry.targetDistance);
    assert.equal(candidate.evaluation.targetDistance, Math.max(...distances));
    assert.equal(
      candidate.evaluation.meanTargetDistance,
      distances.reduce((sum, value) => sum + value, 0) / distances.length
    );
  }
});

test("completed simulation reports archive under the central studies directory", async () => {
  const projectRoot = await mkdtemp(join(tmpdir(), "frontier-archive-"));
  try {
    const report = {
      schemaVersion: 3,
      reportSchemaVersion: 3,
      reportType: "tournament",
      evidenceLabel: "simulation",
      evidenceType: "simulation",
      generatedAt: "2026-07-26T13:03:25.621Z",
      seed: "archive contract",
      runs: 100,
      playerCount: 4,
      game: {
        version: "0.1.0",
        rulesetFingerprint: `sha256:${"a".repeat(64)}`
      }
    };
    const archive = await archiveSimulationReport(report, {
      projectRoot,
      jobId: "job-123"
    });
    assert.match(
      archive.relativePath,
      /^evidence\/studies\/simulation\/20260726T130325621Z-tournament-0-1-0-aaaaaaaaaaaa-archive-contract-100x4-job-123-[0-9a-f-]{36}\.json$/
    );
    assert.deepEqual(
      JSON.parse(await readFile(join(projectRoot, archive.relativePath), "utf8")),
      report
    );
  } finally {
    await rm(projectRoot, { recursive: true, force: true });
  }
});

test("concurrent archive writes with identical timestamp and job labels preserve every report", async () => {
  const projectRoot = await mkdtemp(join(tmpdir(), "frontier-archive-collision-"));
  try {
    const reports = Array.from({ length: 16 }, (_, index) => ({
      evidenceLabel: "simulation", reportType: "tournament",
      generatedAt: "2026-09-06T12:00:00.000Z", seed: "common-seed",
      runs: 1, playerCount: 4, arm: index
    }));
    const archives = await Promise.all(reports.map(report =>
      archiveSimulationReport(report, { projectRoot, jobId: "llm-match-0" })));
    assert.equal(new Set(archives.map(archive => archive.relativePath)).size, reports.length);
    for (const [index, archive] of archives.entries()) {
      assert.deepEqual(JSON.parse(await readFile(join(projectRoot, archive.relativePath), "utf8")), reports[index]);
    }
  } finally {
    await rm(projectRoot, { recursive: true, force: true });
  }
});

test("game identity fingerprints exact rules, engine, variants, and strategies", async () => {
  const profiles = await loadPlayerProfiles();
  const first = await loadGameIdentity({
    profiles: profiles.slice(0, 2),
    backends: ["weighted", "greedy"]
  });
  const second = await loadGameIdentity({
    profiles: profiles.slice(0, 2),
    backends: ["weighted", "greedy"]
  });
  assert.equal(first.game.version, currentRelease.gameVersion);
  assert.ok(!Object.hasOwn(first.game.files, "dist/docs/core-rules.md"));
  assert.equal(first.game.rulesetFingerprint, second.game.rulesetFingerprint);
  assert.equal(first.engine.fingerprint, second.engine.fingerprint);
  assert.equal(first.strategies.fingerprint, second.strategies.fingerprint);
  assert.notEqual(
    first.variant.fingerprint,
    fingerprintObject({ auditMultiplier: 0.8 })
  );
  const lowReasoning = await loadGameIdentity({
    profiles: profiles.slice(0, 2),
    backends: ["codex", "codex"],
    model: ["fixture-model", "fixture-model"],
    reasoningEffort: ["low", "low"]
  });
  const mediumReasoning = await loadGameIdentity({
    profiles: profiles.slice(0, 2),
    backends: ["codex", "codex"],
    model: ["fixture-model", "fixture-model"],
    reasoningEffort: ["medium", "medium"]
  });
  assert.notEqual(
    lowReasoning.strategies.fingerprint,
    mediumReasoning.strategies.fingerprint
  );
});

test("simulations validate a frozen launch identity before they run", async () => {
  const options = {
    runs: 1,
    playerCount: 3,
    seed: "launch-identity-contract",
    sampleReplays: 0,
    profileIds: ["balanced_operator", "balanced_operator", "balanced_operator"],
    backends: ["weighted", "weighted", "weighted"]
  };
  const launchIdentity = await captureSimulationLaunchIdentity(options);
  const report = await createSimulation({ ...options, launchIdentity });
  assert.deepEqual(report.launchIdentity, launchIdentity);

  const incompatible = structuredClone(launchIdentity);
  incompatible.strategies.backends = ["greedy", "greedy", "greedy"];
  const payload = structuredClone(incompatible);
  delete payload.fingerprint;
  incompatible.fingerprint = fingerprintObject(payload);
  await assert.rejects(
    () => createSimulation({ ...options, launchIdentity: incompatible }),
    (error) => error.code === "launch_identity_mismatch"
  );
});

test("batch projection exactly matches rich deterministic outcomes at three through five players", async () => {
  for (const playerCount of [3, 4, 5]) {
    const options = {
      runs: 2,
      playerCount,
      seed: `batch-parity-${playerCount}p`,
      sampleReplays: 2,
      includeObservations: true,
      profileIds: [
        "balanced_operator",
        "capability_rusher",
        "trust_governor",
        "power_broker",
        "agi_candidate"
      ],
      backends: ["weighted", "weighted", "weighted", "weighted", "weighted"],
      simulateNegotiation: true
    };
    const rich = await createSimulation({ ...options, projection: "rich" });
    const batch = await createSimulation({ ...options, projection: "batch" });
    for (const field of [
      "seats",
      "factions",
      "profiles",
      "backends",
      "factionStrategies",
      "factionBackends",
      "strategyBackends",
      "profileMatchups",
      "diagnostics",
      "matchMetrics",
      "samples",
      "observations"
    ]) {
      assert.deepEqual(batch[field], rich[field], `${playerCount}p ${field}`);
    }
    assert.equal(batch.configuration.projection, "batch");
    assert.notEqual(batch.launchIdentity.fingerprint, rich.launchIdentity.fingerprint);
  }
  await assert.rejects(
    () => createSimulation({
      runs: 1,
      playerCount: 3,
      projection: "batch",
      backends: ["codex", "weighted", "weighted"],
      allowLlm: true
    }),
    /Batch projection supports deterministic policies only/,
    "batch must not silently alter an LLM packet"
  );
});

test("parallel deterministic chunks restore batch outcomes in global run order", async () => {
  const options = {
    runs: 10,
    playerCount: 3,
    seed: "parallel-batch-parity",
    sampleReplays: 2,
    includeObservations: true,
    projection: "batch",
    chunkSize: 5,
    profileIds: ["balanced_operator", "capability_rusher", "trust_governor"],
    backends: ["weighted", "weighted", "weighted"],
    simulateNegotiation: true
  };
  const parallel = await createSimulation({ ...options, workers: 2 });
  const inline = await createSimulation({ ...options, workers: 1 });
  for (const field of [
    "seats",
    "factions",
    "profiles",
    "backends",
    "factionStrategies",
    "factionBackends",
    "strategyBackends",
    "profileMatchups",
    "diagnostics",
    "matchMetrics",
    "samples",
    "observations"
  ]) {
    assert.deepEqual(parallel[field], inline[field], field);
  }
  assert.deepEqual(parallel.configuration.execution, {
    scheduler: "worker_threads",
    requestedWorkers: 2,
    workers: 2,
    chunkSize: 5,
    chunks: 2
  });
});

test("legacy reports migrate for viewing without gaining false attribution", () => {
  const legacy = {
    schemaVersion: 2,
    reportType: "tournament",
    evidenceLabel: "simulation",
    generatedAt: "2026-07-26T13:03:25.621Z",
    seed: "legacy",
    playerCount: 4,
    scope: { id: "react-agent-assignments-v1" }
  };
  const before = structuredClone(legacy);
  const migrated = normalizeSimulationReport(legacy);
  assert.deepEqual(legacy, before);
  assert.equal(migrated.reportSchemaVersion, 6);
  assert.equal(migrated.game.version, "unknown");
  assert.equal(migrated.migration.attribution, "legacy_unattributed");
  assert.equal(
    classifyReportComparison(migrated, migrated).classification,
    "incompatible"
  );
});

test("incomplete schema-six match archives migrate from their recorded launch identity", () => {
  const archive = {
    schemaVersion: 6,
    reportSchemaVersion: 6,
    reportType: "tournament",
    evidenceLabel: "simulation",
    evidenceType: "simulation",
    generatedAt: "2026-08-01T00:00:00.000Z",
    seed: "historical-immediate-match",
    runs: 1,
    playerCount: 4,
    scope: { id: "selected-rules" },
    game: {},
    engine: {},
    variant: {},
    strategies: {},
    launchIdentity: {
      rng: { algorithm: "mulberry32", version: 1 },
      provenance: { sourceCommit: "recorded", sourceDirty: false }
    }
  };
  const migrated = normalizeSimulationReport(archive);
  assert.equal(migrated.experiment.fingerprint, null);
  assert.equal(migrated.rng.algorithm, "mulberry32");
  assert.equal(migrated.provenance.sourceCommit, "recorded");
  assert.equal(
    migrated.migration.attribution,
    "launch_identity_preserved_experiment_backfilled"
  );
  assert.equal(classifyReportComparison(migrated, migrated).classification, "incompatible");
});

test("balance audit covers every persona pair and never auto-promotes", async () => {
  const profiles = await loadPlayerProfiles();
  const contract = await loadBalanceContract();
  const report = await runBalanceAudit({
    runsPerMatchup: 1,
    generations: 1,
    population: 2,
    seed: "balance-audit-contract-test"
  });
  assert.equal(report.reportType, "balance_audit");
  assert.equal(report.league.coverage, 1);
  assert.equal(
    report.design.observedPairs,
    profiles.length * (profiles.length - 1) / 2
  );
  assert.equal(report.adversarial.profiles.length, profiles.length);
  assert.equal(report.balanceContract.id, contract.id);
  assert.equal(report.balanceEvaluation.promotionGate.eligible, false);
  assert.equal(report.balanceEvaluation.promotionGate.humanApproval, false);
});

test("report comparison separates exact, controlled-rules, and descriptive evidence", async () => {
  const baseline = await createSimulation({
    runs: 1,
    playerCount: 3,
    seed: "comparison-contract",
    sampleReplays: 0,
    profileIds: ["balanced_operator", "capability_rusher"],
    backends: ["weighted"]
  });
  assert.equal(
    classifyReportComparison(baseline, structuredClone(baseline)).classification,
    "exact"
  );

  const rulesCandidate = structuredClone(baseline);
  rulesCandidate.variant.fingerprint = `sha256:${"b".repeat(64)}`;
  assert.equal(
    classifyReportComparison(baseline, rulesCandidate).classification,
    "controlled_rules"
  );

  const mixed = structuredClone(rulesCandidate);
  mixed.seed = "another-seed";
  mixed.experiment.fingerprint = `sha256:${"d".repeat(64)}`;
  mixed.strategies.fingerprint = `sha256:${"c".repeat(64)}`;
  assert.equal(
    classifyReportComparison(baseline, mixed).classification,
    "descriptive_historical"
  );
});
