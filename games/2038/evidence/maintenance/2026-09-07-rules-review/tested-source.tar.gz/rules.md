# ${content.worldCopy.title}
## A strategy game about institutions turning reliable AI capability into contested public authority as they build, deploy, regulate, and make rival claims on ${terms.systems.agi}

**Players:** ${game.playerRange} · **Suggested player count:** ${game.suggestedPlayerRange}

Use the browser **First Game Guide** for a guided introduction.

The separately printed [**World and Institutions**](/docs/world-and-institutions.html) companion contains setting
and ending narratives.

## How to Play

The game lasts four Eras. The institution with the most
${terms.playerTracks.mandate} wins. Every qualifying institution may score the public
${terms.systems.agi} achievement before the final Audit. Resolve
the institutional winner and shared World Ending separately. Follow the
numbered sections in order.

## 1. Setup

1. Unfold the Governance Board. Build the nineteen-tile map in its wells as described in **Modular hex board**:
   ${terms.locations.frontier} in the center, the shuffled six-tile operational ring around it,
   and the shuffled twelve-tile public ring around the complete outer edge.
2. Separate the sixteen ${terms.systems.headline} cards by Era. Shuffle
   each deck into its printed Era panel's Headline well. Each Era uses three
   ${terms.systems.headlines}. Place the Current Era marker in its Start bay.
3. Shuffle the Training deck. Separate the twelve Era ${terms.playerTracks.mandate} cards into
   four three-card Era decks. Shuffle each deck and place it beside its Era
   panel.
4. Place the two infrastructure project references face up beside the Governance Board and
   stage the remaining shared supplies. Ordinary
   ${terms.infrastructure.power} contracts are printed on the Energy tiles;
   Fusion's is on its project reference.
5. Each player takes one prepacked Faction tray and foldout aid. Set its captive
   sliders to their printed starts. Premark the Trust award checkboxes at or below
   starting Trust; these awards are already included in starting Mandate.
6. Place two Agents per player at ${terms.locations.frontier}. Keep the other two Agents in
   supply. Keep all four Facilities and the Generator in supply; no Facility
   begins on the board. Facilities must be constructed in printed number order:
   Facility 1 first, then 2, 3, and 4. Facility 1 carries that Faction's
   integrated starting-grid identifier. Set each Faction’s ${terms.resources.runway}, ${terms.resources.compute}, ${terms.playerTracks.capability}, ${terms.playerTracks.customers}, ${terms.playerTracks.trust}. Set each to its printed starting value.
7. Place each Faction’s already-earned public ${terms.playerTracks.mandate} on the shared track as
   printed on its Faction board. Put every player’s ten ${terms.playerTracks.scrutiny}
   cubes outside the bag; the bag begins empty.
8. Add every Faction’s printed starting ${terms.playerTracks.trust} and record the result as
   **Setup Collective ${terms.playerTracks.trust}** in the Governance Board ledger. This fixed value is used
   during the World Ending.
9. Choose Initiative randomly and give that player the Initiative marker.
   Begin Era I.

### Modular hex board

The board is one jurisdiction whose districts represent physical and
institutional dependencies rather than ordinary distance. The shuffled map
remains fixed for all four Eras. Rival pieces coexist; there is no combat
or player elimination.

The detailed setup, district effects, and control procedure print in the
[**Map Reference**](/docs/map-reference.html).

<!-- map:start -->
### Build the jurisdiction

Use nineteen tiles in a complete radius-two hexagon:

- One ${terms.locations.frontier}
- Three ${terms.locations.research}
- Three ${terms.locations.cloud}
- Two each of ${terms.locations.consumer}, ${terms.locations.media},
  ${terms.locations.government}, and ${terms.locations.renewable}
- One each of ${terms.locations.chip}, ${terms.locations.capital},
  ${terms.locations.talent}, and ${terms.locations.grid}

Place ${terms.locations.frontier} at the center. Six operational districts form
the complete inner ring. Twelve public districts form the complete outer ring.
Every outer district touches its two outer neighbors and either one or two
inner districts according to the printed wells. Adjacency governs infrastructure;
Agent assignments do not trace paths.

Shuffle this operational ring around ${terms.locations.frontier}:

- One ${terms.locations.research}
- One ${terms.locations.cloud}
- One ${terms.locations.chip}
- One ${terms.locations.capital}
- One ${terms.locations.talent}
- The ${terms.locations.grid}

Shuffle this public ring among the twelve outer positions:

- Two ${terms.locations.research}
- Two ${terms.locations.cloud}
- Two ${terms.locations.consumer}
- Two ${terms.locations.media}
- Two ${terms.locations.government}
- Two ${terms.locations.renewable}

These ring pools are fixed; shuffle tiles only within their listed ring.
All copies of one named district are mechanically identical. Names, art, and
flavor may distinguish copies, but visit effects, production, Facility spaces,
and contract icons must remain identical.

Every piece placed on the board during setup begins at ${terms.locations.frontier}, the jurisdiction’s
standing civic exception rather than property to be controlled. Agents may be reassigned directly to any district.

Every non-${terms.locations.frontier} hex has a visit bonus, two Facility spaces, Facility
production, and a control value used by Headlines and Mandates. ${terms.locations.frontier} has
no Facility spaces and is never controlled. It is not a category for the hex-category
Mandate. Once pieces leave it, positioning, Agents, local Power, and negotiated adjacency
matter.

### Presence and control

- Agent or Facility: one presence

The player with the most presence controls each non-${terms.locations.frontier} hex. Ties mean
nobody controls it. ${terms.locations.frontier} has no controller regardless of presence.

### District effects

| Location | Visit bonus | Facility production | Contract icon |
| --- | --- | --- | --- |
| ${content.gameConfig.board.tiles.0.name} | ${content.gameConfig.board.tiles.0.visit} | ${content.gameConfig.board.tiles.0.production} | None |
| ${content.gameConfig.board.tiles.1.name} | ${content.gameConfig.board.tiles.1.visit} | ${content.gameConfig.board.tiles.1.production} | ${terms.resources.compute} |
| ${content.gameConfig.board.tiles.2.name} | ${content.gameConfig.board.tiles.2.visit} | ${content.gameConfig.board.tiles.2.production} | ${terms.resources.compute} |
| ${content.gameConfig.board.tiles.3.name} | ${content.gameConfig.board.tiles.3.visit} | ${content.gameConfig.board.tiles.3.production} | ${terms.resources.runway} |
| ${content.gameConfig.board.tiles.4.name} | ${content.gameConfig.board.tiles.4.visit} | ${content.gameConfig.board.tiles.4.production} | ${terms.resources.compute} |
| ${content.gameConfig.board.tiles.5.name} | ${content.gameConfig.board.tiles.5.visit} | ${content.gameConfig.board.tiles.5.production} | ${terms.resources.runway} |
| ${content.gameConfig.board.tiles.6.name} | ${content.gameConfig.board.tiles.6.visit} | ${content.gameConfig.board.tiles.6.production} | ${terms.resources.runway} |
| ${content.gameConfig.board.tiles.7.name} | ${content.gameConfig.board.tiles.7.visit} | ${content.gameConfig.board.tiles.7.production} | ${terms.resources.runway} |
| ${content.gameConfig.board.tiles.8.name} | ${content.gameConfig.board.tiles.8.visit} | ${content.gameConfig.board.tiles.8.production} | ${terms.resources.runway} |
| ${content.gameConfig.board.tiles.9.name} | ${content.gameConfig.board.tiles.9.visit} | ${content.gameConfig.board.tiles.9.production} | ${terms.resources.compute} |
| ${content.gameConfig.board.tiles.10.name} | ${content.gameConfig.board.tiles.10.visit} | ${content.gameConfig.board.tiles.10.production} | ${terms.resources.runway} |

Resolve ${terms.locations.frontier}’s optional ${terms.resources.runway} after the Action, once per acting player
assigned there. It does not modify the Action or create production
or ${terms.playerTracks.mandate}.

The two Energy-tile visit boxes are the complete ordinary Generator contracts.
No separate Power Source reference cards are used. Each player may construct
only one ordinary Generator; the full Fusion contract is printed on its Era IV
project reference.
<!-- map:end -->

## 2. Resources

### ${terms.resources.runway}, ${terms.resources.compute}, and ${terms.playerTracks.capability}

- **${terms.resources.runway}:** money available to your institution.
- **${terms.resources.compute}:** processing capacity spent on Research, Deployment, and projects.
- **${terms.infrastructure.power}:** electricity supply that keeps Facilities operating; it is a local connection condition, never currency.
- **${terms.playerTracks.capability}:** permanent model quality that unlocks Deployments and
  ${terms.systems.agi}; spend it only when instructed.

### ${terms.playerTracks.customers}

Each ${terms.playerTracks.customer} produces one ${terms.resources.runway} during Production. Customers #1–3 immediately score two public ${terms.playerTracks.mandate}; Customers #4–5 score one each. Customers also increase public exposure.

### ${terms.playerTracks.trust}

A zero-to-six track affecting regulation, Joint Ventures, safety, and whether
the shared World Ending is Open. Zero ${terms.playerTracks.trust} does not
eliminate a player.

**${terms.playerTracks.mandate}** is the score used to determine the winner (victory points).
It is the public authority you have gained to define outcomes.
It represents the recognized right to shape the future: credibility in Progress,
capacity in Capacity, authority in Authority, and historical legitimacy in
Continuity.

${terms.playerTracks.mandate} is normally scored immediately on one public track:

- Two when ${terms.playerTracks.customer} #1, #2, or #3 is gained; one when #4 or #5 is gained.
- Two the first time ${terms.playerTracks.capability} reaches three, six, nine, and twelve.
- Two the first time ${terms.playerTracks.trust} reaches two, four, and six.
- Printed ${terms.playerTracks.mandate} from ${terms.systems.headlines}, Era Mandates, Fusion, and faction abilities.

Threshold awards are permanent; later losses do not reverse them. Beside the
Trust slider, mark the matching two, four, or six checkbox when its award is
first scored. Keep all three marks for the whole game, even when Trust falls
or the Era ledger is erased. Returning to a marked threshold scores nothing.

There is no hidden or deferred conversion of Facilities, controlled hexes,
stored resources, or unused cards into ${terms.playerTracks.mandate}. If an effect scores ${terms.playerTracks.mandate}, move
the public marker when that effect resolves.

### Universal costs and caps

Apply resource caps immediately after any gain or trade:

- ${terms.resources.runway}: twelve
- ${terms.resources.compute}: ten

Return excess. A trade cannot move resources through a player above a cap.

When effects change a cost, apply replacements and waivers first, then
surcharges, then discounts. The final cost cannot fall below zero.

## 3. Central loop

Each player has six Core Action cards but takes only three turns per Era.
Once played, a Core Action remains exhausted until the next Era:

- ${terms.actions.fund}
- ${terms.actions.research}
- ${terms.actions.build}
- ${terms.actions.organize}
- ${terms.actions.deploy}
- ${terms.actions.influence}

Choose three of six Actions each Era, in any order. The other three remain
unused until the next Era.

### The complete ordinary turn: ReAct — Reason → Act → Observe

1. Reveal one ${terms.systems.headline} and finish all its instructions and choices before selection.
2. **Reason:** everyone secretly selects an available, unlocked Core Action. Check card availability and
   Era unlocks only; costs and targets need not be legal yet.
3. Reveal selections simultaneously and resolve clockwise from Initiative.
4. **Act:** after the optional permitted trade, assign one of your Agents to
   any district, or leave it where it is. Choose the selected Action's mode,
   target, and payment using the current board, and resolve it there.
5. **Observe:** apply and inspect the consequences, then exhaust the Core Action. After all players resolve, pass Initiative
   clockwise and begin the next cycle using the changed world.

Observe adds no event draw, award, negotiation window, speech, or extra phase.
ReAct means reasoning and acting with feedback from the world.

### Agents as persistent assignments

An Agent is an operation carrying out your institution's instructions. Its marker
shows where you commit attention and influence. Each contributes one presence
and remains until reassigned. Rival Agents may coexist. Agents have no paths,
movement allowance, intermediate districts, or exhaustion rule. Any Agent can
act again on a later turn. Recruiting expands persistent presence, never turns.

Each faction starts with two Agents and has four in total. The CEO is a character
on the faction board, with no separate playing piece or executive powers.
Facilities and Generators cannot act. Their geography remains physical: placement,
space limits, local connections, and partnership adjacency still apply.

### Effect precedence

The Era panel states which systems are unlocked. Resolve the Headline completely
before selection. During an action, apply its effect, the destination bonus, and
your faction's single permanent ability when applicable. No effect readies or
resolves another Core Action. Build's two construction steps are one action.

### What an Era teaches

Systems are inactive before their printed Era panel lists them under **New this Era**.
Read that strip aloud before revealing the Mandate. All Era panels, project references,
and Faction abilities are open information.

Progress teaches ordinary institutional work;
Capacity unlocks Generators and Mega-Clusters; Authority unlocks Joint Ventures;
Continuity unlocks optional public AGI recognition and Fusion. Later Eras retain previously unlocked systems
unless a printed effect says otherwise.

### Universal tie rule

Whenever an effect targets the player with the lowest, highest, or most of
something and multiple players tie, target the tied player nearest Initiative
clockwise. An effect that explicitly applies to everyone, or explicitly awards
all tied players, overrides this rule.

Initiative is an order, not a resource. Passing it after each cycle changes who
resolves first and who wins unresolved ties; it cannot be traded or retained.

### A committed Action that becomes blocked

Selection commits only the Action. At resolution, choose a legal Agent,
district, mode, target, and payment after the optional pre-resolution trade.
The selected card cannot be replaced. An earlier player may consume the space,
contract pair, or other target you expected to use; adapt within the same Action.

If no legal effect remains, assign an Agent normally and exhaust the Action
without effect or compensation. A speculative selection
may therefore become only an assignment; it still consumes one of the Era's
three action selections.

## 4. Core Actions

### ${terms.actions.fund}

Choose:

- **Conservative funding:** gain two ${terms.resources.runway}.
- **Venture funding:** gain four ${terms.resources.runway} and add two ${terms.playerTracks.scrutiny}.

${terms.locations.capital} provides one additional ${terms.resources.runway}.

### ${terms.actions.research}

Spend one ${terms.resources.compute} and conduct a ${terms.systems.trainingRun}.

The Training deck contains seven data domains:

- Code
- Science
- Web
- Books
- Images
- Video
- Synthetic

${terms.playerTracks.capability} earned during ${terms.actions.research} is **provisional until banked**:

1. Begin with zero provisional ${terms.playerTracks.capability} and no revealed domains.
2. Draw and fully resolve one card at a time.
3. The first card from each ordinary domain adds one provisional ${terms.playerTracks.capability}.
4. After resolving any non-duplicate card, either stop and bank or continue.
5. Banking adds all provisional ${terms.playerTracks.capability} to the player’s permanent
   ${terms.playerTracks.capability} track and ends the run.
6. A duplicate crashes the run. Lose all provisional ${terms.playerTracks.capability},
   add one ${terms.playerTracks.scrutiny}, and end the run.

${terms.playerTracks.scrutiny}, ${terms.playerTracks.trust}, and ${terms.resources.runway} changes resolved before a crash are not reversed.
All revealed cards enter the discard pile after the run.

A duplicate loses the provisional Capability, adds one Scrutiny, and ends the
run.
Mirevanta's printed Scientific Method may pay Runway to bank a duplicate instead;
charge only when that exception is used. Orisonix retains one revealed provisional
Capability on a crash. A Research district grants one additional Capability on a
successful bank, including Human Evaluation or Scientific Method banking; it
grants none on a crash.

Special cards:

- **Curated Corpus:** choose one ordinary domain not yet revealed this run. It
  counts as that domain and adds one provisional ${terms.playerTracks.capability}. If every ordinary
  domain is already present, it is a duplicate.
- **Benchmark Leak:** add two provisional ${terms.playerTracks.capability} and one ${terms.playerTracks.scrutiny}. It is
  not a domain. Its ${terms.playerTracks.capability} is lost if the run later crashes.
- **Human Evaluation:** gain one ${terms.playerTracks.trust}, immediately bank all provisional
  ${terms.playerTracks.capability}, and end the run.

When a Mandate, Faction ability, or Headline counts **unique domains**, count
only the seven ordinary domains listed above that were banked successfully.
Benchmark Leak and Human Evaluation never count unless an effect names them
explicitly.

### ${terms.actions.build}

<!-- construction:start -->
Construct up to one Facility, then up to one unlocked infrastructure project,
paying each cost. Both use the acting Agent's district. A project is an ordinary
Generator, Mega-Cluster, or Fusion. Recheck requirements after placing the
Facility. You may omit either step; resolve at least one construction if able.
Exhaust Build once after completing both steps. There is no extra action,
assignment, trade, or destination bonus between them.

Facility spaces, Generator slots, numbered Facility order, unlocked Eras,
adjacent connected hosts, and shared component supply still apply. Choose a
plan you can fully afford on the current board when Build resolves. Facility 2
and its Generator can be built together in Era II; an existing pair can receive
a Mega-Cluster in Era III, leaving Era IV's Build available for Fusion.
<!-- construction:end -->

#### ${terms.infrastructure.power} connections

Facility 1 is always powered, including after relocation. Every other Facility
is powered when it shares a district with, or is adjacent to, one of its owner's
Generators. This condition is checked on the current board whenever an effect
uses “powered” or “connected.” Other players' Generators do not connect yours.
Facilities never transmit Power onward. No Power is assigned, spent, or marked.

A Generator has no numeric capacity. A cheap emergency Generator adds its
printed recurring Scrutiny during Production when it serves a Facility. A clean
Generator costs more and grants its printed Trust on construction.

#### ${terms.infrastructure.power} delivery

Use the same current-board connection rule for Production, Headlines, Mandates,
Joint Ventures, Mega-Clusters, AGI recognition, and final offline penalties.
A Facility can become connected or offline immediately after infrastructure
moves or is built. No prior Production allocation remains authoritative.

A Mega-Cluster operates only while its two host Facilities remain adjacent and
connected. It has no additional Power demand. Joint Ventures retain their printed
host, range, and resource requirements; both hosts must currently be connected.

#### Construct a Facility

Pay two ${terms.resources.runway} and place your lowest-numbered unbuilt Facility on the acting
piece’s hex. Facility 1 must be built first, followed by Facilities 2, 3, and 4.
It produces while connected by the local Power rule. Each non-${terms.locations.frontier} hex has only two Facility spaces;
${terms.locations.frontier} has none and is never a legal Facility destination. Facilities cannot
be destroyed by rivals.

#### Construct a Generator

The acting piece must be on an Energy hex. Each player may construct one
ordinary Generator. On ${terms.locations.grid}, pay one ${terms.resources.runway} and place it as
${terms.technology.emergencyInfrastructure}. On ${terms.locations.renewable}, pay two
${terms.resources.runway} and place it as ${terms.technology.cleanInfrastructure}. The Energy
location determines the source; there is no separate source choice. This mode unlocks in Era II.
Each Energy hex has three Generator slots shared by all players. A Generator
does not use a Facility space, but it cannot be built when all three Generator
slots on that Energy hex are occupied.

<!-- power-contracts:start -->
The two ordinary contracts are printed at their point of use. The
${terms.locations.grid} tile always constructs
${terms.technology.emergencyInfrastructure}; the ${terms.locations.renewable}
tile always constructs ${terms.technology.cleanInfrastructure}. Fusion's full
contract is printed on its Era IV project reference. No separate Power Source
cards are used. Each player has one ordinary Generator, and each Energy hex
still has three shared slots.
<!-- power-contracts:end -->

An ordinary Generator connects your Facilities on its own or adjacent hexes.
Power has no numeric capacity and is never allocated. An emergency Generator
adds its operating penalty only when it serves at least one of your Facilities
at Production, including a first Facility already supplied by the starting grid.

##### ${terms.technology.cleanInfrastructure}

- Location: ${terms.locations.renewable}
- Cost: two ${terms.resources.runway}
- Connection: your Facilities on this hex or an adjacent hex
- Gain one ${terms.playerTracks.trust} when constructed
- No recurring penalty

##### ${terms.technology.emergencyInfrastructure}

- Location: ${terms.locations.grid}
- Cost: one ${terms.resources.runway}
- Connection: your Facilities on this hex or an adjacent hex
- Add one ${terms.playerTracks.scrutiny} at Production only when serving at least one of your Facilities

#### Construct a ${terms.technology.megaCluster} (Era II onward)

Spend three ${terms.resources.runway} and two ${terms.resources.compute} to place a
matched Mega-Cluster pair on two adjacent connected Facilities you own. Assign
the acting Agent to either host's district. Add two ${terms.playerTracks.scrutiny}.
Each Facility may host only one Mega-Cluster. Recheck both unclaimed hosts, local
connection, adjacency, and the shared pair supply at resolution; no reservation
survives an earlier player's use of a required component.

The project produces three ${terms.resources.compute} during Production while
both hosts remain adjacent and connected. No additional Power is assigned.

#### Construct ${terms.technology.advancedGeneration} (Era IV)

The acting piece must be assigned to the ${terms.locations.grid}. Spend
${facts.shared.advancedGeneration.runwayCostWord} ${terms.resources.runway} and construct ${terms.technology.advancedGenerationShort} there. It uses a dedicated ${terms.technology.advancedGenerationShort} marker,
occupies one of that tile’s three Generator slots, provides local ${terms.infrastructure.power}, scores
${facts.shared.advancedGeneration.mandateWord} ${terms.playerTracks.mandate}, and adds ${facts.shared.advancedGeneration.scrutinyWord} ${terms.playerTracks.scrutiny}. ${terms.technology.advancedGenerationShort} counts as an owned Generator for
local Power connections. It does not count
against the owner’s one ordinary Generator-piece limit. If all three Grid
Generator slots are occupied, ${terms.technology.advancedGenerationShort} cannot be constructed. A full ${terms.locations.grid}
blocks construction.

There is one shared ${terms.technology.advancedGenerationShort} marker and one
Fusion project in the game. Once any player constructs it, no other player may
select or construct Fusion.

### ${terms.actions.organize}

After assigning an Agent, choose one mode:

- **Recruit:** pay two Runway to deploy one Agent from supply to the acting
  Agent's district. Recruiting in Talent costs one less Runway. You may have no
  more than four deployed Agents. Recruitment grants no extra action or assignment.
- **Relocate:** move one of your Facilities from the acting Agent's district to
  an adjacent non-Frontier district with a legal open Facility space. It keeps
  its attachments and starting-grid designation. Recheck connections and contracts
  immediately. This mode costs no Runway.

Agents have no additional movement procedure.

### ${terms.actions.deploy}

The next ${terms.playerTracks.customer} requires:

| ${terms.playerTracks.customer} | ${terms.playerTracks.capability} required |
| ---: | ---: |
| 1 | 2 |
| 2 | 4 |
| 3 | 6 |
| 4 | 8 |
| 5 | 10 |

Spend one ${terms.resources.compute} and gain one ${terms.playerTracks.customer}. ${terms.locations.consumer} waives the ${terms.resources.compute} cost.
Every ${terms.actions.deploy} adds one ${terms.playerTracks.scrutiny}.

### ${terms.actions.influence}

Assign an Agent, then choose one legal effect:

- On ${terms.locations.media}, ${terms.locations.government}, or ${terms.locations.capital}, gain one
  ${terms.playerTracks.trust} or remove one ${terms.playerTracks.scrutiny}. ${terms.locations.media}
  removes one additional ${terms.playerTracks.scrutiny}; ${terms.locations.government} gains one
  additional ${terms.playerTracks.trust}.
- At one of your Facilities, create a Joint Venture using that Facility and an
  eligible rival Facility, or terminate one named Joint Venture you share.

Political control uses Agents and Facilities already on the board.
The ${terms.actions.influence} Action creates no separate presence piece.


#### Contract hosts

Joint Ventures and Mega-Clusters use shared, matched token pairs. A Mega-Cluster
is always owned by one player. Create one
only while its pair is available; place one numbered half on each host.

Each Facility may host only one Mega-Cluster. It may also host any number of
Joint Ventures, including several with the same rival Facility. Each venture
requires its own Influence action, fresh consent, and available matched pair;
each active contract produces separately. A Facility may host Joint Ventures
and a Mega-Cluster at the same time. The shared supplies limit the number of
contracts; neither player can reserve unused pairs.

A contract remains owned but is active only while its fixed hosts meet its
requirements. Tokens travel with their Facilities.

Every cross-player contract or jointly funded project requires the explicit
consent of every participant. Facilities sharing one hex are **co-located**.
Adjacent host Facilities occupy hexes that share an edge.

Consent applies to the named project only. It does not grant control of a host,
create a general trading right, or authorize another contract. A contract’s
matched number preserves its identity when a host moves.

#### Joint Venture

${terms.actions.influence} may create a Joint Venture between two adjacent Facilities owned by
different players, unless a Faction ability explicitly changes that range.
Both host Facilities must be powered during Production for the contract to
produce.

Each partner gains the resource shown by the **contract icon on the other
host tile**. Do not copy full tile production or multiply it with Facility
effects.

During ${terms.actions.influence}, make one complete proposal naming both eligible hosts and
the partner. Acceptance creates it. Rejection, pass, or no response uses that
effect; do not choose another partner or ${terms.actions.influence} effect.

Either participant may instead use ${terms.actions.influence} to terminate one shared Joint
Venture. Return its pair. Termination cannot be combined with another
${terms.actions.influence} effect.

## 5. Era sequence

### A. Begin the quarter

- Move the Current Era marker to Era I; in later Eras, advance one panel.
- Read that Era’s **New this Era** strip aloud. Those systems are now active.
- Reveal one ${terms.playerTracks.mandate} from the current Era’s three-card deck. Return the other
  two cards in that deck to the box unseen.
- Clear the Current Mandate ledger and write the revealed criterion and
  minimum. Start this-Era values at zero; evaluate current-state values when
  scored.
- Ready all six Core Actions.

### B. Three action cycles

At the beginning of each cycle:

1. Reveal a ${terms.systems.headline}, resolve all its instructions and choices, and place it in the current Era’s ${terms.systems.futureTimeline} row. Its effect is finished.
2. **Reason:** everyone secretly selects one available, unlocked Core Action. Reveal simultaneously.
3. **Act:** resolve clockwise from Initiative. After the optional immediate trade, assign one Agent to any district or leave it in place. Choose legal targets and pay costs using the current board, then resolve the selected action.
4. **Observe:** apply the consequences and exhaust the action, even if no legal effect was possible. Observation adds no separate decision or reward.
5. After everyone has acted, pass Initiative clockwise.

#### Immediate resource trade

Immediately before resolving the selected Action, the active player may make
one offer to one rival: give exactly one ${terms.resources.runway} for one
${terms.resources.compute}, or one ${terms.resources.compute} for one
${terms.resources.runway}. The named rival accepts or rejects. Gifts, bundles,
same-resource exchanges, unequal amounts, counteroffers, redirects, and
third-party claims are not legal. Adjust both players' captive sliders
immediately after acceptance.

The selected Action remains committed whether the offer is accepted or rejected.
Check affordability and targets after the trade; a successful trade may make a speculative selection resolvable. There is no post-action trade window.

Immediate resource trades require no ${terms.actions.influence} Action. Only ${terms.actions.influence} creates
persistent Joint Ventures, lobbying effects, or ${terms.playerTracks.trust} manipulation.

### Negotiation and paced play

Discussion creates no game state, obligation, or Action. Promises about later
turns remain non-binding. Apply formal choices only in their printed windows;
missing responses are rejection or pass.

**Paced Play** is an optional table rule. Before play, the group may assign one
shared sand timer to each negotiation window. When it expires, discussion ends
and the normal rejection or pass fallback applies. Expiry never
creates consent or forces a deal.

### C. Production

Apply any permanent faction Production ability first.
Use the current board's visible connections; no allocation choices or Power cubes
are needed. Resolve each step for all players before continuing, in Initiative
order unless specified otherwise:

1. Apply recurring Scrutiny for each emergency Generator serving at least one
   Facility.
2. Produce each connected Facility, then Customer income, then active
   Mega-Clusters. Apply caps after each gain.
3. Produce active Joint Ventures in ascending contract-number order.

An Era Mandate counting Compute produced counts printed output before the cap,
including Facilities, Mega-Clusters, and Joint Ventures. Immediate Facility
production outside this sequence does not count toward that Production total.

When Talent produces, reassign one of your Agents using the normal assignment
rule: choose any district or leave it in place. Update presence immediately.
This resolves no Action or visit bonus and exhausts nothing. A Joint Venture
still grants only its host's printed contract icon, not that host's full production.

### D. Optional AGI recognition, Era IV only

Offer the public qualification and payment described under **Recognized AGI** to
every institution. Add declaration Scrutiny before the final Audit. In Eras I–III,
continue directly to the Audit; there is no end-of-Era AGI bookkeeping.

### E. ${terms.systems.publicAudit}

Risky actions add player-colored ${terms.playerTracks.scrutiny} to the opaque Audit bag. Each
player has ten cubes. For each required cube when all ten are already in the
bag, immediately lose one ${terms.resources.runway}; if none remains, lose one
${terms.playerTracks.trust}. If neither remains, suffer no further loss. A depleted supply
never makes a risky action free.

The four-player base draws are two, three, four, and five. For other player
counts, calculate each Era’s draw count as:

> round(base draws × player count ÷ 4), minimum one

Round halves upward. The resulting Audit profiles are:

| Era | 2 players | 3 players | 4 players | 5 players |
| --- | ---: | ---: | ---: | ---: |
| I | 1 | 2 | 2 | 3 |
| II | 2 | 2 | 3 | 4 |
| III | 2 | 3 | 4 | 5 |
| IV | 3 | 4 | 5 | 6 |

Draw the listed number of cubes or stop when the bag is empty.

In every Era, each colored cube makes its owner lose one
${terms.resources.runway}; if none remains, lose one ${terms.playerTracks.trust}.
If neither remains, suffer no further loss. This is automatic, not a choice.

Drawn player-colored cubes return to the owner’s supply; undrawn cubes remain
in the bag.

${terms.locations.media} Facilities may remove cubes before the draw. A drawn black Systemic
Risk cube gives every player with at least three ${terms.playerTracks.customers} the current Era’s
penalty, then returns to supply. Black cubes
remaining at game end are unresolved Systemic Risk.

### F. Score the ${terms.playerTracks.mandate}

<!-- mandate-scoring:start -->
Each Era ${terms.playerTracks.mandate} has a minimum qualification. If nobody qualifies, nobody
scores it. Otherwise the qualifying leader scores two ${terms.playerTracks.mandate}; tied qualifying
leaders score one ${terms.playerTracks.mandate} each.

Compare only the revealed Mandate’s printed criterion. Resources, control, and
public score do not break its tie. Leave the scored card beside its Era as part
of the table’s public history. The ledger is a counting aid; clear
it when the next Mandate is revealed.

The revealed Mandate card is the exact qualification and scoring authority.
<!-- mandate-scoring:end -->

## 6. Four-Era progression

### Era I — ${terms.eras.demo}

- Three turns per player
- Only Core Actions
- Beneficial or mildly disruptive ${terms.systems.headlines}

Era I activates Agent assignment, Core Actions, Training, the starting grid,
Facilities, Customers, and Scrutiny.

### Era II — ${terms.eras.scale}

Build now also permits:

- Generators
- Mega-Clusters

### Era III — ${terms.eras.narrative}

Joint Ventures now enter play. Previously unlocked infrastructure remains available.

### Era IV — ${terms.eras.claim}

Build may construct Fusion. Public AGI recognition is offered after Production.
All factions retain the same permanent ability they had at setup.

#### Recognized ${terms.systems.agi}

After Era IV Production, before the final Audit, each institution with at least
${content.gameConfig.agiAchievement.capability} Capability,
${content.gameConfig.agiAchievement.poweredFacilities} currently powered Facilities,
and ${content.gameConfig.agiAchievement.trust} Trust may pay
${content.gameConfig.agiAchievement.computeCost} Compute to declare recognized AGI.
It immediately gains ${content.gameConfig.agiAchievement.mandate} Mandate and adds
${content.gameConfig.agiAchievement.scrutiny} Scrutiny before the Audit.

Every qualifying institution may declare once, in Initiative order, or decline.
This uses no Action and creates no deferred payment. Recognition remains recorded
if the subsequent Audit reduces Trust. The fixed award does not vary by Headline.

“Recognized AGI” means the world accepts an institutional claim under the game's
public criteria. It does not decide whether general intelligence metaphysically
exists. Recognition sets one axis of the separate World Ending.

## 7. Final scoring

Earned Mandate, including any AGI award, is already on the public track. Do not
score it again. After the final Audit and Era Mandate:

1. Read the twelve Headlines in the Future Timeline, Era by Era.
2. Lose one Mandate per currently offline Facility, to a minimum score of zero.
3. The institution with the most final Mandate wins. Break ties by higher Trust,
   then more Customers, then more Compute. A complete tie is a joint victory.
4. Determine and read the separate shared World Ending.

There is no second winner procedure. Facilities and control give no additional
endgame score unless a printed effect already awarded it.

### The shared World Ending

Use two independent public results:

- **Recognized AGI:** at least one institution paid for AGI recognition after
  Era IV Production. Audit losses do not revoke it.
- **Open continuity:** final Collective Trust is at least Setup Collective Trust
  plus the player count, and unresolved Systemic Risk after the final Audit is
  strictly lower than the player count. Both conditions must hold.

If either continuity condition fails, the ending is Closed. Recognition does
not itself make continuity Open. The four endings describe accepted claims and
institutional continuity, not a hidden verdict on whether intelligence exists.

| | Open | Closed |
| --- | --- | --- |
| AGI recognized | **The Singularity** | **The Closed Loop** |
| No AGI recognized | **The Plural Future** | **Assured Continuity** |

Read the narrative in [World and Institutions](/docs/world-and-institutions.html).
The institutional winner and the civilization's outcome are distinct.

Find validation limits in [Balance and Exploitability](/docs/balance-and-exploitability.html)
and human observation protocols in [Playtesting and Evidence](/docs/playtesting-and-evidence.html).

## Rules Reference

## 8. Printed card authorities

<!-- card-authority:start -->
Faction boards, Governance Board Era panels, map-tile Power contracts, Core
Action cards, project references, Mandate cards, Training cards, player aids, and
Headline cards are rules components. The [**Card and Board Reference**](/docs/card-reference.html)
projects every authored face in one document; resolve that text or the matching
physical surface. Printed text changes only the field or timing it
names; it does not create an unprinted phase or additional Action.
Each Faction has one permanent ability available from setup.
<!-- card-authority:end -->

All Factions and CEOs are fictional and imply no real-world claim or
endorsement. Every Faction has one persistent institutional identity and one
signature ability. It modifies one familiar action or Production. It requires
no separate use marker, frequency record, or refresh. Every faction uses the
same public Mandate scoring.

During setup, use each Faction board’s printed starts and place its already
earned public ${terms.playerTracks.mandate}. Award that ${terms.playerTracks.mandate} once; never score it
again. The Faction board is authoritative if a summary elsewhere differs.

A Headline is revealed before secret action selection. Finish every printed
instruction and choice, including any immediate production, before selecting
actions. Resolve choices in Initiative order unless the card says otherwise.
Then leave it face up in its Era row as history, with no continuing rules effect.
Three per Era form the twelve-card **${terms.systems.futureTimeline}**.

When a Headline resolves a Facility's printed production, resolve only that
currently connected Facility. Talent uses its normal immediate Agent reassignment.
Do not produce Customers, Generators, Mega-Clusters, Joint Ventures, or faction
Production income unless explicitly instructed. No Core Action resolves.

<!-- era-panels:start -->
These four panels are printed on the Governance Board. Move the Current Era
marker between them; no separate Era cards are used. The board prints the
Era name, epigraph, rules, and unlock text.
<!-- era-panels:end -->

<!-- player-aids:start -->
Each player receives one foldout containing the following three panels: the turn sequence, local Power, and public Mandate.
<!-- player-aids:end -->

<!-- headline-selection:start -->
Use all sixteen Headlines in their printed Era decks. Resolve the listed procedure and rules text.
<!-- headline-selection:end -->

## 9. Map and component reference

Use the [**Component Reference**](/docs/component-reference.html) for the
supported inventory, deck contracts, and component states. The
[**Card and Board Reference**](/docs/card-reference.html) prints exact effects
from component records. Keep these references beside the Core Rules during play.

<!-- components:start -->
<!-- inventory:start -->
Pack the components in the labelled trays and Era packets described below.

### Shared Governance Board

The box includes one rigid folding Governance Board. It is the public table
organizer and modular-map frame, not a fixed printed map.

It provides:

- one center well, six inner-ring wells, and twelve outer-ring wells for the
  nineteen district tiles;
- four printed Era panels, Headline wells, Mandate wells, a Current Era path,
  and twelve Future Timeline positions;
- a shared Mandate track, Initiative position, and writable Current Mandate
  ledger with one row per faction;
- Setup and final Collective Trust, unresolved Systemic Risk, AGI recognition,
  winner, and World Ending fields;
- two infrastructure project reference positions;
- six numbered Joint Venture pair bays, six numbered Mega-Cluster pair bays,
  and one Fusion position; and
- staging for the Audit bag, Scrutiny, Systemic Risk, and unused contract pairs.

The Grid and Renewable tiles print ordinary Power contracts. Fusion's contract
is printed on its project reference. Tile wells retain pieces but create no
extra rules state.

### One prepacked faction tray per player

Each of the six trays contains:

- 1 faction board with five captive sliders: Runway, Compute, Capability,
  Customers, and Trust; three permanent-for-the-game Trust award checkboxes
- ${content.gameConfig.playerSupply.agents} Agents
- ${content.gameConfig.playerSupply.facilities} Facilities, numbered 1–${content.gameConfig.playerSupply.facilities}
- ${content.gameConfig.playerSupply.generators} Generator
- ${content.gameConfig.playerSupply.startingGridIdentifiers} integrated starting-grid identifier on Facility 1; Facilities are
  constructed in number order
- ${content.gameConfig.playerSupply.scrutinyCubes} ${terms.playerTracks.scrutiny} cubes
- 1 Mandate marker
- ${content.gameConfig.playerSupply.coreActionCards} Core Action cards
- 1 three-panel foldout player aid

Generators do not count against the Facility limit.

### Shared components

- ${content.gameConfig.sharedSupply.governanceBoards} Governance Board
- ${content.gameConfig.board.selectedTileCount} district tiles: Frontier, six operational, and twelve public
- ${content.gameConfig.sharedSupply.projectReferences} project references
- ${content.gameConfig.sharedSupply.currentEraMarkers} Current Era marker
- ${content.gameConfig.sharedSupply.sharedDryEraseMarkers} shared fine-tip dry-erase marker
- 16 Headline cards; reveal 12 per game
- 12 Mandate cards; reveal 4 per game
- 40 Training cards
- ${content.gameConfig.sharedSupply.jointVenturePairs} matched Joint Venture pairs
- ${content.gameConfig.sharedSupply.megaClusterPairs} matched Mega-Cluster pairs
- 1 Fusion Demonstrator marker
- 18 Systemic Risk pieces, tactually identical to Scrutiny while concealed
- 1 opaque Audit bag
- 1 Initiative marker

The six faction trays supply six Mandate markers and six player aids.
Choose two through five factions for a game; leave every unchosen tray in the box.

Fusion is a single shared project; its dedicated marker leaves the supply once
constructed. Unused contract tokens cannot be reserved; create a Joint Venture
or Mega-Cluster only while a matched pair is available.

### Setup packaging

The insert provides six labelled faction trays, four labelled Era packets, one
project-reference well, one Training well, and one contract/power well. Era packets
contain `5 / 4 / 3 / 4` Headlines plus three Mandates each.

### Exact printed-paper count

The game contains 106 standard cards plus 6 foldout player aids:

- 36 Core Actions
- 2 infrastructure project references
- 16 Headlines
- 12 Mandates
- 40 Training cards
- 6 foldout player aids

Printed Era panels and Power contracts are part of the Governance
Board, tiles, and project references.

### Excluded deferred content

The supported box does not require Tactics, Secret Objectives, Specialists, or
Patrons.

### Production form

Power is read directly from Generator adjacency and Facility 1's integrated
starting-grid identifier. No Power cube or allocation surface is supplied.
Board dimensions, fold pattern, material, writable finish, and retention
tolerances remain manufacturing decisions.

<!-- inventory:end -->

### Deck contracts

#### Training deck: 40 cards

- Four copies of each of seven domains: 28
- Four Curated Corpus
- Four Benchmark Leak
- Four Human Evaluation

Discard every revealed card after a run. If the deck empties, resolve the
current card, shuffle the discard, and continue.

#### Headline decks

Each Era deck contains every card for that Era. Reveal three each Era. Leave every resolved card face
up in its Era row to form the twelve-card ${terms.systems.futureTimeline}.

#### Infrastructure project references

Place both project references face up. They show Mega-Cluster and Fusion
construction costs and operation. Build constructs these projects; the references
are never selected, exhausted, or marked with use history.

### Defined markers and effects

- **Remove Scrutiny:** return up to the stated number of your cubes from the Audit bag.
- **Connected/powered:** Facility 1, or an own Generator on the same or an adjacent district, evaluated on the current board.
- **Current Mandate ledger:** record the revealed criterion and minimum. Keep only the per-faction value that this card needs; reset this-Era values and evaluate current-state criteria when scored.
- **Recognized AGI:** record every paid declaration on the final public ledger. Recognition persists through the Audit.
- **Offline recovery:** an infrastructure change can immediately reconnect a Facility. Facilities never flip.

<!-- components:end -->

## Document record

**Rules version:** ${game.rulesVersion}
**Design-baseline date:** July 26, 2026
**Status:** Controlled playtest candidate; synchronized with executable game ${game.executableVersion}
**Provisional time:** ${game.physicalTestDuration} at four players; three- and five-player durations require their own blind tests
**Standard game:** ${facts.shared.roundsWord | capitalize} Eras, ${facts.shared.cyclesPerRoundWord} turns per player per Era
