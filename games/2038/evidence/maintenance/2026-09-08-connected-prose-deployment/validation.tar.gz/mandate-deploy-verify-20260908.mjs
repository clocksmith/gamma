import assert from 'node:assert/strict';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { chromium } from '/Users/xyz/deco/reploid/node_modules/playwright/index.mjs';

const base = process.argv[2];
assert.ok(base && /^https?:\/\//.test(base));
const root = '/Users/xyz/deco/gamma/games/2038/dist/firebase/public';
const manifest = JSON.parse(await readFile(`${root}/site-manifest.json`, 'utf8'));
const files = (await readdir(root, { recursive: true, withFileTypes: true }))
  .filter(entry => entry.isFile()).map(entry => `${entry.parentPath}/${entry.name}`.slice(root.length + 1));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
for (let offset = 0; offset < files.length; offset += 8) {
  await Promise.all(files.slice(offset, offset + 8).map(async file => {
    const response = await fetch(`${base}/${file}`, { cache: 'no-store' });
    assert.equal(response.status, 200, file);
    assert.equal(hash(Buffer.from(await response.arrayBuffer())), hash(await readFile(`${root}/${file}`)), file);
  }));
}
const privatePaths = ['/world.md', '/sources/world.md', '/lab.html', '/review/docs/content-provenance.html'];
for (const file of privatePaths) assert.equal((await fetch(`${base}${file}`)).status, 404, file);
const result = { base, manifest, matchingFiles: files.length, privatePaths, browsers: [] };
const browser = await chromium.launch({ channel: 'chrome', headless: true });
try {
  for (const [width, count] of [[1440, 2], [390, 5]]) {
    const page = await browser.newPage({ viewport: { width, height: 900 }, acceptDownloads: true });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(base, { waitUntil: 'networkidle' });
    assert.equal(await page.locator('#sources-title').textContent(), 'Sources');
    const links = await page.locator('main a').evaluateAll(anchors => anchors.map(a => a.href));
    for (const link of links.filter(link => link.startsWith(base))) {
      assert.equal((await fetch(link)).status, 200, link);
    }
    await page.goto(`${base}/docs/world-and-institutions.html`, { waitUntil: 'networkidle' });
    assert.ok((await page.locator('body').innerText()).length > 1000);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.goto(`${base}/web/index.html`, { waitUntil: 'networkidle' });
    await page.waitForFunction(() => document.querySelector('#faction')?.options.length === 6);
    assert.deepEqual(await page.locator('#player-count option').evaluateAll(xs => xs.map(x => x.value)), ['2', '3', '4', '5']);
    await page.selectOption('#player-count', String(count));
    await page.click('#start-game');
    await page.waitForFunction(n => document.querySelector('#players')?.children.length === n, count);
    await page.locator('#decisions button').first().waitFor({ timeout: 30000 });
    const before = await page.locator('#log').innerText();
    await page.locator('#decisions button').first().click();
    await page.waitForFunction(previous => document.querySelector('#log').innerText !== previous, before);
    const pendingDownload = page.waitForEvent('download');
    await page.click('#export');
    const receipt = JSON.parse(await readFile(await (await pendingDownload).path(), 'utf8'));
    assert.ok(receipt && typeof receipt === 'object');
    assert.deepEqual(errors, []);
    result.browsers.push({ width, count, links: links.length, receiptKeys: Object.keys(receipt), errors });
    await page.close();
  }
} finally { await browser.close(); }
await writeFile('/tmp/mandate-deploy-live-20260908.json', `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ matchingFiles: result.matchingFiles, browsers: result.browsers }));
